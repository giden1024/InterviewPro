#!/usr/bin/env python3
"""
Test detailed parsing of .doc file content
"""
import os
import re
from app.services.resume_parser import ResumeParser

def test_detailed_parsing():
    """详细测试信息提取"""
    
    # 查找.doc文件
    uploads_dir = "uploads"
    doc_file = None
    
    if os.path.exists(uploads_dir):
        for root, dirs, files in os.walk(uploads_dir):
            for file in files:
                if file.endswith('.doc'):
                    doc_file = os.path.join(root, file)
                    break
            if doc_file:
                break
    
    if not doc_file:
        print("No .doc file found")
        return
    
    parser = ResumeParser()
    
    # 1. 提取原始文本
    raw_text = parser._extract_text(doc_file, 'doc')
    print(f"Raw text length: {len(raw_text)}")
    print(f"First 500 chars:\n{raw_text[:500]}")
    print("\n" + "="*50)
    
    # 2. 测试各个提取函数
    print("\n=== Testing Name Extraction ===")
    name = parser._extract_name(raw_text)
    print(f"Extracted name: {name}")
    
    print("\n=== Testing Email Extraction ===")
    email = parser._extract_email(raw_text)
    print(f"Extracted email: {email}")
    
    print("\n=== Testing Phone Extraction ===")
    phone = parser._extract_phone(raw_text)
    print(f"Extracted phone: {phone}")
    
    print("\n=== Testing Skills Extraction ===")
    skills = parser._extract_skills(raw_text)
    print(f"Extracted skills ({len(skills)}): {skills}")
    
    print("\n=== Testing Experience Extraction ===")
    experience = parser._extract_experience(raw_text)
    print(f"Extracted experiences ({len(experience)}):")
    for i, exp in enumerate(experience):
        print(f"  {i+1}. {exp}")
    
    print("\n=== Testing Education Extraction ===")
    education = parser._extract_education(raw_text)
    print(f"Extracted education ({len(education)}):")
    for i, edu in enumerate(education):
        print(f"  {i+1}. {edu}")

    # 3. 手动检查关键信息
    print("\n=== Manual Pattern Check ===")
    # 邮箱模式
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    emails = re.findall(email_pattern, raw_text)
    print(f"Manual email search: {emails}")
    
    # 电话模式
    phone_patterns = [
        r'\b\d{3}-\d{4}-\d{4}\b',  # 188-1029-7728
        r'\b\d{11}\b',  # 连续11位数字
        r'\b\d{3}\s\d{4}\s\d{4}\b'  # 空格分隔
    ]
    for pattern in phone_patterns:
        phones = re.findall(pattern, raw_text)
        if phones:
            print(f"Manual phone search ({pattern}): {phones}")

if __name__ == "__main__":
    test_detailed_parsing() 