#!/usr/bin/env python3
"""
测试JWT错误处理器注册
"""

from app import create_app
from flask_jwt_extended import JWTManager

def test_jwt_handlers():
    """测试JWT错误处理器注册"""
    
    print("🔍 测试JWT错误处理器注册...")
    
    # 创建应用
    app = create_app()
    
    # 检查JWT错误处理器是否注册
    with app.app_context():
        jwt = JWTManager()
        jwt.init_app(app)
        
        # 检查错误处理器
        handlers = {
            'expired_token_loader': jwt.expired_token_loader,
            'invalid_token_loader': jwt.invalid_token_loader,
            'unauthorized_loader': jwt.unauthorized_loader,
        }
        
        for handler_name, handler in handlers.items():
            if handler:
                print(f"✅ {handler_name} 已注册")
            else:
                print(f"❌ {handler_name} 未注册")
    
    print("✅ JWT错误处理器测试完成！")

if __name__ == "__main__":
    test_jwt_handlers() 