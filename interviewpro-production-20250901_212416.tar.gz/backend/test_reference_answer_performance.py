#!/usr/bin/env python3
"""
AI参考答案生成性能测试脚本
用于测试优化前后的性能差异
"""

import time
import json
import requests
from datetime import datetime

# 测试配置
BASE_URL = "http://localhost:5001"
TEST_QUESTION_ID = 353  # 使用实际的问题ID
HEADERS = {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_JWT_TOKEN"  # 需要替换为实际的JWT token
}

def test_reference_answer_generation():
    """测试AI参考答案生成性能"""
    print("🚀 开始AI参考答案生成性能测试")
    print("=" * 50)
    
    # 测试参数
    test_cases = [
        {
            "name": "首次生成（无缓存）",
            "clear_cache": True,
            "expected_improvement": "首次生成应该比之前40秒快"
        },
        {
            "name": "缓存命中测试",
            "clear_cache": False,
            "expected_improvement": "应该从缓存返回，<1秒"
        },
        {
            "name": "重复生成测试",
            "clear_cache": False,
            "expected_improvement": "应该从缓存返回，<1秒"
        }
    ]
    
    results = []
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n📋 测试 {i}: {test_case['name']}")
        print(f"预期改进: {test_case['expected_improvement']}")
        
        # 如果需要清除缓存
        if test_case['clear_cache']:
            try:
                response = requests.post(
                    f"{BASE_URL}/api/v1/questions/reference-cache/clear",
                    headers=HEADERS
                )
                if response.status_code == 200:
                    print("✅ 缓存已清除")
                else:
                    print(f"⚠️ 清除缓存失败: {response.status_code}")
            except Exception as e:
                print(f"⚠️ 清除缓存出错: {e}")
        
        # 测试参考答案生成
        start_time = time.time()
        try:
            response = requests.post(
                f"{BASE_URL}/api/v1/questions/{TEST_QUESTION_ID}/generate-reference",
                headers=HEADERS,
                json={"user_context": {"test": True}}
            )
            
            end_time = time.time()
            execution_time = end_time - start_time
            
            if response.status_code == 200:
                result_data = response.json()
                print(f"✅ 成功生成参考答案")
                print(f"⏱️ 执行时间: {execution_time:.2f}秒")
                print(f"📊 响应大小: {len(json.dumps(result_data))} 字符")
                
                # 检查是否包含sample_answer
                if 'data' in result_data and 'ai_reference_answer' in result_data['data']:
                    sample_answer = result_data['data']['ai_reference_answer']
                    if isinstance(sample_answer, dict) and 'sample_answer' in sample_answer:
                        print(f"📝 参考答案长度: {len(sample_answer['sample_answer'])} 字符")
                    else:
                        print("⚠️ 参考答案格式异常")
                else:
                    print("⚠️ 响应中未找到参考答案")
                
            else:
                print(f"❌ 请求失败: {response.status_code}")
                print(f"错误信息: {response.text}")
                execution_time = -1
            
        except Exception as e:
            print(f"❌ 请求异常: {e}")
            execution_time = -1
        
        # 记录结果
        test_result = {
            "test_name": test_case['name'],
            "execution_time": execution_time,
            "status": "success" if execution_time > 0 else "failed",
            "timestamp": datetime.now().isoformat()
        }
        results.append(test_result)
        
        # 等待一下再进行下一个测试
        time.sleep(2)
    
    # 输出测试总结
    print("\n" + "=" * 50)
    print("📊 性能测试总结")
    print("=" * 50)
    
    successful_tests = [r for r in results if r['status'] == 'success']
    if successful_tests:
        avg_time = sum(r['execution_time'] for r in successful_tests) / len(successful_tests)
        min_time = min(r['execution_time'] for r in successful_tests)
        max_time = max(r['execution_time'] for r in successful_tests)
        
        print(f"✅ 成功测试数: {len(successful_tests)}/{len(test_cases)}")
        print(f"⏱️ 平均执行时间: {avg_time:.2f}秒")
        print(f"⏱️ 最短执行时间: {min_time:.2f}秒")
        print(f"⏱️ 最长执行时间: {max_time:.2f}秒")
        
        # 性能改进分析
        if max_time < 40:
            improvement = (40 - max_time) / 40 * 100
            print(f"🚀 相比之前40秒，性能提升: {improvement:.1f}%")
        
        if min_time < 1:
            print("🎯 缓存机制工作正常，缓存命中时响应时间 < 1秒")
    
    # 保存测试结果
    with open(f"reference_answer_performance_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\n📄 测试结果已保存到JSON文件")

def test_cache_stats():
    """测试缓存统计功能"""
    print("\n📊 测试缓存统计功能")
    print("-" * 30)
    
    try:
        response = requests.get(
            f"{BASE_URL}/api/v1/questions/reference-cache/stats",
            headers=HEADERS
        )
        
        if response.status_code == 200:
            stats = response.json()
            print("✅ 缓存统计信息:")
            print(f"   - 缓存答案总数: {stats['data']['total_cached_answers']}")
            print(f"   - 缓存大小: {stats['data']['cache_size']}")
            print(f"   - 预估命中率: {stats['data']['estimated_hit_rate']:.1f}%")
            
            if stats['data']['cache_keys']:
                print(f"   - 缓存键示例: {stats['data']['cache_keys'][:3]}")
        else:
            print(f"❌ 获取缓存统计失败: {response.status_code}")
            
    except Exception as e:
        print(f"❌ 缓存统计测试异常: {e}")

if __name__ == "__main__":
    print("🔧 AI参考答案生成性能测试工具")
    print("请确保:")
    print("1. 后端服务正在运行 (http://localhost:5001)")
    print("2. 已更新HEADERS中的JWT token")
    print("3. TEST_QUESTION_ID设置为有效的问题ID")
    print()
    
    # 测试缓存统计
    test_cache_stats()
    
    # 测试参考答案生成性能
    test_reference_answer_generation()
    
    print("\n✨ 测试完成！") 