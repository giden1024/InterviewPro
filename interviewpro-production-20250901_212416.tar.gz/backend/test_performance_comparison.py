#!/usr/bin/env python3
"""
性能对比测试 - 验证AI参考答案生成优化效果
"""

import sys
import os
import time
import json

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app.models.question import Question
from app.models.resume import Resume
from app.services.ai_question_generator import AIQuestionGenerator

def test_performance_comparison():
    """性能对比测试"""
    print("=" * 60)
    print("🚀 AI参考答案生成性能对比测试")
    print("=" * 60)
    
    # 创建Flask应用上下文
    app = create_app()
    
    with app.app_context():
        # 获取测试数据
        question = Question.query.first()
        resume = Resume.query.first()
        
        if not question or not resume:
            print("❌ 没有找到测试数据，请先创建一些问题和简历")
            return
        
        print(f"📋 测试问题: {question.question_text[:50]}...")
        print(f"📄 测试简历: {resume.filename}")
        
        # 初始化AI生成器
        generator = AIQuestionGenerator()
        
        # 测试多次生成，模拟缓存效果
        print("\n🔄 开始性能测试...")
        
        times = []
        for i in range(3):
            print(f"\n📊 第 {i+1} 次测试:")
            
            start_time = time.time()
            
            try:
                reference_answer = generator.generate_reference_answer(
                    question=question,
                    resume=resume,
                    user_context={}
                )
                
                end_time = time.time()
                response_time = end_time - start_time
                times.append(response_time)
                
                print(f"✅ 生成成功!")
                print(f"⏱️  响应时间: {response_time:.2f} 秒")
                print(f"📝 答案长度: {len(reference_answer.get('sample_answer', ''))} 字符")
                
                # 检查是否使用了缓存
                if i > 0 and response_time < 1:
                    print("🎉 缓存命中!")
                elif i > 0 and response_time < 5:
                    print("✅ 缓存部分生效")
                else:
                    print("🔄 首次生成或缓存未命中")
                    
            except Exception as e:
                print(f"❌ 生成失败: {e}")
                times.append(0)
        
        # 性能分析
        print("\n" + "=" * 60)
        print("📊 性能分析结果")
        print("=" * 60)
        
        if len(times) > 0:
            avg_time = sum(times) / len(times)
            min_time = min(times)
            max_time = max(times)
            
            print(f"📈 平均响应时间: {avg_time:.2f} 秒")
            print(f"⚡ 最快响应时间: {min_time:.2f} 秒")
            print(f"🐌 最慢响应时间: {max_time:.2f} 秒")
            
            # 性能评估
            print(f"\n🎯 性能评估:")
            if avg_time < 15:
                print("🎉 性能优秀! 平均响应时间 < 15秒")
            elif avg_time < 25:
                print("✅ 性能良好! 平均响应时间 < 25秒")
            elif avg_time < 35:
                print("⚠️  性能一般! 平均响应时间 < 35秒")
            else:
                print("❌ 性能需要优化! 平均响应时间 > 35秒")
            
            # 优化效果对比
            print(f"\n📊 优化效果对比:")
            print(f"🔴 优化前 (预估): 40-45 秒")
            print(f"🟢 优化后 (实测): {avg_time:.2f} 秒")
            
            improvement = ((40 - avg_time) / 40) * 100
            print(f"📈 性能提升: {improvement:.1f}%")
            
            if improvement > 50:
                print("🎉 优化效果显著!")
            elif improvement > 30:
                print("✅ 优化效果良好!")
            elif improvement > 10:
                print("⚠️  优化效果一般")
            else:
                print("❌ 优化效果不明显")
        
        print("\n" + "=" * 60)
        print("✅ 性能测试完成!")
        print("=" * 60)

def main():
    """主函数"""
    test_performance_comparison()

if __name__ == "__main__":
    main() 