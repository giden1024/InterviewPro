#!/usr/bin/env python3
"""
JWT认证调试脚本
"""

import requests
import json

def test_jwt_auth():
    """测试JWT认证"""
    
    base_url = "http://localhost:5001"
    
    print("🔍 开始JWT认证调试...")
    
    # 1. 测试无token访问
    print("\n1. 测试无token访问 /api/v1/resumes")
    try:
        response = requests.get(f"{base_url}/api/v1/resumes?page=1&per_page=50")
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.text[:200]}...")
    except Exception as e:
        print(f"请求失败: {e}")
    
    # 2. 测试无效token访问
    print("\n2. 测试无效token访问 /api/v1/resumes")
    try:
        headers = {"Authorization": "Bearer invalid_token"}
        response = requests.get(f"{base_url}/api/v1/resumes?page=1&per_page=50", headers=headers)
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.text[:200]}...")
    except Exception as e:
        print(f"请求失败: {e}")
    
    # 3. 测试登录获取token
    print("\n3. 测试登录获取token")
    try:
        login_data = {
            "email": "test@example.com",
            "password": "password123"
        }
        response = requests.post(f"{base_url}/api/v1/auth/login", json=login_data)
        print(f"登录状态码: {response.status_code}")
        print(f"登录响应: {response.text[:200]}...")
        
        if response.status_code == 200:
            token_data = response.json()
            token = token_data.get('data', {}).get('access_token')
            if token:
                print(f"✅ 获取到token: {token[:20]}...")
                
                # 4. 使用有效token访问
                print("\n4. 使用有效token访问 /api/v1/resumes")
                headers = {"Authorization": f"Bearer {token}"}
                response = requests.get(f"{base_url}/api/v1/resumes?page=1&per_page=50", headers=headers)
                print(f"状态码: {response.status_code}")
                print(f"响应: {response.text[:200]}...")
            else:
                print("❌ 登录响应中没有找到token")
        else:
            print("❌ 登录失败")
            
    except Exception as e:
        print(f"登录请求失败: {e}")
    
    # 5. 测试注册新用户
    print("\n5. 测试注册新用户")
    try:
        register_data = {
            "email": "debug@example.com",
            "password": "debug123456",
            "username": "Debug User"
        }
        response = requests.post(f"{base_url}/api/v1/auth/register", json=register_data)
        print(f"注册状态码: {response.status_code}")
        print(f"注册响应: {response.text[:200]}...")
        
        if response.status_code == 200:
            token_data = response.json()
            token = token_data.get('data', {}).get('access_token')
            if token:
                print(f"✅ 注册成功，获取到token: {token[:20]}...")
                
                # 6. 使用新用户token访问
                print("\n6. 使用新用户token访问 /api/v1/resumes")
                headers = {"Authorization": f"Bearer {token}"}
                response = requests.get(f"{base_url}/api/v1/resumes?page=1&per_page=50", headers=headers)
                print(f"状态码: {response.status_code}")
                print(f"响应: {response.text[:200]}...")
            else:
                print("❌ 注册响应中没有找到token")
        else:
            print("❌ 注册失败")
            
    except Exception as e:
        print(f"注册请求失败: {e}")

def test_health_endpoint():
    """测试健康检查端点"""
    print("\n🔍 测试健康检查端点")
    try:
        response = requests.get("http://localhost:5001/api/v1/health")
        print(f"健康检查状态码: {response.status_code}")
        print(f"健康检查响应: {response.text}")
    except Exception as e:
        print(f"健康检查失败: {e}")

if __name__ == "__main__":
    print("🚀 开始JWT认证调试...")
    
    # 先测试健康检查
    test_health_endpoint()
    
    # 测试JWT认证
    test_jwt_auth()
    
    print("\n✅ JWT认证调试完成！") 