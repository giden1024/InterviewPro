#!/usr/bin/env python3
"""
AI API连接测试脚本
测试DeepSeek API的基本连接和响应
"""

import sys
import os
import time
import openai

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app

def test_ai_connection():
    """测试AI API连接"""
    print("🚀 开始测试AI API连接...")
    
    # 创建Flask应用上下文
    app = create_app()
    
    with app.app_context():
        try:
            # 获取API密钥
            api_key = app.config.get('DEEPSEEK_API_KEY')
            if not api_key:
                print("❌ DEEPSEEK_API_KEY 未配置")
                return
            
            print(f"✅ API密钥已配置: {api_key[:10]}...")
            
            # 初始化OpenAI客户端
            client = openai.OpenAI(
                api_key=api_key,
                base_url="https://api.deepseek.com"
            )
            
            print("✅ OpenAI客户端初始化成功")
            
            # 测试简单请求
            print("\n🔄 测试简单AI请求...")
            start_time = time.time()
            
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": "Say 'Hello, AI test successful!' in one sentence."}
                ],
                max_tokens=50,
                temperature=0.1,
                timeout=10
            )
            
            end_time = time.time()
            request_time = end_time - start_time
            
            print(f"✅ AI请求成功!")
            print(f"⏱️  请求时间: {request_time:.2f} 秒")
            
            if response and response.choices and len(response.choices) > 0:
                content = response.choices[0].message.content.strip()
                print(f"📝 AI响应: {content}")
                print(f"📊 响应长度: {len(content)} 字符")
                
                if "successful" in content.lower():
                    print("🎉 AI连接测试成功!")
                else:
                    print("⚠️  AI响应内容不符合预期")
            else:
                print("❌ AI响应为空或无效")
            
        except Exception as e:
            print(f"❌ AI连接测试失败: {e}")
            import traceback
            traceback.print_exc()

def test_ai_reference_generation():
    """测试AI参考答案生成"""
    print("\n🔄 开始测试AI参考答案生成...")
    
    app = create_app()
    
    with app.app_context():
        try:
            from app.services.ai_question_generator import AIQuestionGenerator
            from app.models.question import Question
            from app.models.resume import Resume
            from app.extensions import db
            
            # 初始化AI生成器
            generator = AIQuestionGenerator()
            
            # 获取测试数据
            test_question = db.session.query(Question).first()
            test_resume = db.session.query(Resume).first()
            
            if not test_question or not test_resume:
                print("❌ 未找到测试数据")
                return
            
            print(f"📋 测试问题: {test_question.question_text[:50]}...")
            print(f"📄 测试简历: {test_resume.original_filename}")
            
            # 测试参考答案生成
            start_time = time.time()
            result = generator.generate_reference_answer(
                question=test_question,
                resume=test_resume
            )
            end_time = time.time()
            
            generation_time = end_time - start_time
            
            print(f"✅ 参考答案生成完成!")
            print(f"⏱️  生成时间: {generation_time:.2f} 秒")
            print(f"🤖 生成方式: {result.get('generated_by', 'unknown')}")
            
            if 'sample_answer' in result:
                sample_answer = result['sample_answer']
                print(f"📝 参考答案长度: {len(sample_answer)} 字符")
                print(f"📋 参考答案预览: {sample_answer[:100]}...")
            
            # 性能评估
            if generation_time < 30:
                print("🎉 性能优秀! 生成时间 < 30秒")
            elif generation_time < 40:
                print("✅ 性能良好! 生成时间 < 40秒")
            else:
                print("⚠️  性能需要优化! 生成时间 > 40秒")
            
        except Exception as e:
            print(f"❌ AI参考答案生成测试失败: {e}")
            import traceback
            traceback.print_exc()

def main():
    """主函数"""
    print("=" * 60)
    print("🤖 AI API连接测试")
    print("=" * 60)
    
    # 测试基本连接
    test_ai_connection()
    
    # 测试参考答案生成
    test_ai_reference_generation()
    
    print("\n" + "=" * 60)
    print("✅ 测试完成!")
    print("=" * 60)

if __name__ == "__main__":
    main() 