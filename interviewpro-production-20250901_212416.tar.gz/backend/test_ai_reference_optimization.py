#!/usr/bin/env python3
"""
AI参考答案生成优化测试脚本
测试优化前后的性能差异
"""

import sys
import os
import time
import json
from datetime import datetime

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app.models.question import Question, QuestionType, QuestionDifficulty
from app.models.resume import Resume
from app.services.ai_question_generator import AIQuestionGenerator
from app.extensions import db

def test_ai_reference_answer_performance():
    """测试AI参考答案生成性能"""
    print("🚀 开始AI参考答案生成性能测试...")
    
    # 创建Flask应用上下文
    app = create_app()
    
    with app.app_context():
        try:
            # 初始化AI生成器
            generator = AIQuestionGenerator()
            
            # 获取测试数据
            test_question = db.session.query(Question).first()
            test_resume = db.session.query(Resume).first()
            
            if not test_question or not test_resume:
                print("❌ 未找到测试数据，请确保数据库中有问题和简历数据")
                return
            
            print(f"📋 测试问题: {test_question.question_text[:50]}...")
            print(f"📄 测试简历: {test_resume.original_filename}")
            
            # 测试优化后的参考答案生成
            print("\n🔄 开始测试优化后的参考答案生成...")
            
            start_time = time.time()
            result = generator.generate_reference_answer(
                question=test_question,
                resume=test_resume
            )
            end_time = time.time()
            
            generation_time = end_time - start_time
            
            print(f"✅ 参考答案生成完成!")
            print(f"⏱️  生成时间: {generation_time:.2f} 秒")
            print(f"📝 生成结果: {result.get('sample_answer', '')[:100]}...")
            
            # 性能评估
            if generation_time < 30:
                print("🎉 性能优秀! 生成时间 < 30秒")
            elif generation_time < 40:
                print("✅ 性能良好! 生成时间 < 40秒")
            else:
                print("⚠️  性能需要进一步优化! 生成时间 > 40秒")
            
            # 测试缓存机制
            print("\n🔄 测试缓存机制...")
            cache_start_time = time.time()
            cached_result = generator.generate_reference_answer(
                question=test_question,
                resume=test_resume
            )
            cache_end_time = time.time()
            
            cache_time = cache_end_time - cache_start_time
            print(f"⏱️  缓存访问时间: {cache_time:.2f} 秒")
            
            if cache_time < 1:
                print("🎉 缓存机制工作正常!")
            else:
                print("⚠️  缓存机制可能需要优化")
            
            # 测试提示优化效果
            print("\n🔄 测试提示优化效果...")
            
            # 测试简历上下文准备
            context_start = time.time()
            resume_context = generator._prepare_resume_context_optimized(test_resume)
            context_end = time.time()
            
            context_time = context_end - context_start
            print(f"⏱️  简历上下文准备时间: {context_time:.3f} 秒")
            print(f"📊 上下文数据: {json.dumps(resume_context, ensure_ascii=False, indent=2)}")
            
            # 测试提示构建
            prompt_start = time.time()
            prompt = generator._build_reference_answer_prompt_optimized(
                question=test_question,
                resume_context=resume_context,
                user_context={}
            )
            prompt_end = time.time()
            
            prompt_time = prompt_end - prompt_start
            print(f"⏱️  提示构建时间: {prompt_time:.3f} 秒")
            print(f"📝 优化后提示长度: {len(prompt)} 字符")
            
            # 性能总结
            print("\n📊 性能测试总结:")
            print(f"   • AI生成时间: {generation_time:.2f} 秒")
            print(f"   • 缓存访问时间: {cache_time:.2f} 秒")
            print(f"   • 上下文准备时间: {context_time:.3f} 秒")
            print(f"   • 提示构建时间: {prompt_time:.3f} 秒")
            print(f"   • 总优化时间: {context_time + prompt_time:.3f} 秒")
            
            # 与原始40秒对比
            if generation_time < 40:
                improvement = ((40 - generation_time) / 40) * 100
                print(f"🎯 相比原始40秒，性能提升了 {improvement:.1f}%")
            
        except Exception as e:
            print(f"❌ 测试过程中出现错误: {e}")
            import traceback
            traceback.print_exc()

def test_multiple_questions():
    """测试多个问题的参考答案生成"""
    print("\n🔄 开始多问题测试...")
    
    app = create_app()
    
    with app.app_context():
        try:
            generator = AIQuestionGenerator()
            
            # 获取多个测试问题
            questions = db.session.query(Question).limit(3).all()
            test_resume = db.session.query(Resume).first()
            
            if not questions or not test_resume:
                print("❌ 未找到足够的测试数据")
                return
            
            total_time = 0
            success_count = 0
            
            for i, question in enumerate(questions, 1):
                print(f"\n📝 测试问题 {i}: {question.question_text[:50]}...")
                
                start_time = time.time()
                try:
                    result = generator.generate_reference_answer(
                        question=question,
                        resume=test_resume
                    )
                    end_time = time.time()
                    
                    generation_time = end_time - start_time
                    total_time += generation_time
                    success_count += 1
                    
                    print(f"   ✅ 成功生成，耗时: {generation_time:.2f} 秒")
                    
                except Exception as e:
                    print(f"   ❌ 生成失败: {e}")
            
            if success_count > 0:
                avg_time = total_time / success_count
                print(f"\n📊 多问题测试总结:")
                print(f"   • 成功生成: {success_count}/{len(questions)}")
                print(f"   • 平均生成时间: {avg_time:.2f} 秒")
                print(f"   • 总耗时: {total_time:.2f} 秒")
                
                if avg_time < 30:
                    print("🎉 多问题测试性能优秀!")
                elif avg_time < 40:
                    print("✅ 多问题测试性能良好!")
                else:
                    print("⚠️  多问题测试性能需要优化!")
            
        except Exception as e:
            print(f"❌ 多问题测试失败: {e}")

def main():
    """主函数"""
    print("=" * 60)
    print("🤖 AI参考答案生成优化测试")
    print("=" * 60)
    print(f"⏰ 测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 测试单个问题性能
    test_ai_reference_answer_performance()
    
    # 测试多个问题性能
    test_multiple_questions()
    
    print("\n" + "=" * 60)
    print("✅ 测试完成!")
    print("=" * 60)

if __name__ == "__main__":
    main() 