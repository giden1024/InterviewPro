#!/usr/bin/env python3
"""
测试Celery初始化情况
"""
from app import create_app

def test_celery():
    app = create_app()
    
    print("=== 检查Celery初始化 ===")
    print(f"Celery对象: {app.celery}")
    print(f"Celery类型: {type(app.celery)}")
    
    try:
        # 测试Celery连接
        print("\n=== 测试Celery连接 ===")
        result = app.celery.control.inspect().active()
        print(f"Celery连接测试: {result}")
    except Exception as e:
        print(f"Celery连接失败: {e}")
    
    try:
        # 测试发送任务
        print("\n=== 测试发送任务 ===")
        task = app.celery.send_task('app.tasks.question_tasks.generate_questions_async', args=[])
        print(f"任务ID: {task.id}")
        print(f"任务状态: {task.state}")
    except Exception as e:
        print(f"发送任务失败: {e}")

if __name__ == "__main__":
    test_celery() 