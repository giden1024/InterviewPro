#!/usr/bin/env python3
"""
测试HomePage功能的脚本
验证：
1. 获取所有问题（包括没有答案的）
2. 生成新问题
3. 问题编辑功能
"""

import sys
import os
import requests
import json

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_get_all_questions():
    """测试获取所有问题（包括没有答案的）"""
    print("🔍 测试获取所有问题...")
    
    url = "http://localhost:5001/api/v1/questions/with-answers"
    headers = {
        'Authorization': 'Bearer your-test-token',  # 需要有效的token
        'Content-Type': 'application/json'
    }
    
    try:
        # 测试不传has_answers参数，应该返回所有问题
        response = requests.get(url, headers=headers, params={'page': 1, 'per_page': 10})
        
        print(f"📊 状态码: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            questions = data.get('data', {}).get('questions', [])
            total = data.get('data', {}).get('pagination', {}).get('total', 0)
            
            print(f"✅ 成功获取 {len(questions)} 个问题，总计 {total} 个")
            
            # 检查是否有没有答案的问题
            questions_without_answers = [q for q in questions if not q.get('latest_answer')]
            questions_with_answers = [q for q in questions if q.get('latest_answer')]
            
            print(f"📝 有答案的问题: {len(questions_with_answers)} 个")
            print(f"❓ 没有答案的问题: {len(questions_without_answers)} 个")
            
            if questions_without_answers:
                print("✅ 成功显示没有答案的问题！")
                for q in questions_without_answers[:3]:  # 显示前3个
                    print(f"   - {q.get('question_text', '')[:50]}...")
            else:
                print("ℹ️  所有问题都有答案")
                
        else:
            print(f"❌ 请求失败: {response.text}")
            
    except Exception as e:
        print(f"❌ 测试失败: {e}")

def test_generate_questions():
    """测试生成新问题功能"""
    print("\n🚀 测试生成新问题功能...")
    
    # 首先获取用户的简历
    resumes_url = "http://localhost:5001/api/v1/resumes"
    headers = {
        'Authorization': 'Bearer your-test-token',  # 需要有效的token
        'Content-Type': 'application/json'
    }
    
    try:
        # 获取简历
        resumes_response = requests.get(resumes_url, headers=headers)
        if resumes_response.status_code != 200:
            print("❌ 无法获取简历信息")
            return
            
        resumes_data = resumes_response.json()
        resumes = resumes_data.get('data', {}).get('resumes', [])
        
        if not resumes:
            print("❌ 没有找到简历，请先上传简历")
            return
            
        latest_resume = resumes[0]
        print(f"📄 使用简历: {latest_resume.get('filename', 'Unknown')}")
        
        # 创建面试会话
        session_url = "http://localhost:5001/api/v1/interviews"
        session_data = {
            'resume_id': latest_resume['id'],
            'interview_type': 'comprehensive',
            'title': f'Test Generated Questions - {os.path.basename(__file__)}'
        }
        
        session_response = requests.post(session_url, headers=headers, json=session_data)
        if session_response.status_code != 200:
            print("❌ 创建面试会话失败")
            return
            
        session_info = session_response.json()
        session_id = session_info['data']['session']['session_id']
        print(f"📋 创建面试会话: {session_id}")
        
        # 生成问题
        generate_url = "http://localhost:5001/api/v1/questions/generate"
        generate_data = {
            'resume_id': latest_resume['id'],
            'session_id': session_id,
            'interview_type': 'comprehensive',
            'total_questions': 5
        }
        
        print("🔄 正在生成问题...")
        generate_response = requests.post(generate_url, headers=headers, json=generate_data)
        
        print(f"📊 生成问题状态码: {generate_response.status_code}")
        
        if generate_response.status_code == 200:
            result = generate_response.json()
            questions = result.get('data', {}).get('questions', [])
            print(f"✅ 成功生成 {len(questions)} 个新问题！")
            
            for i, q in enumerate(questions[:3], 1):  # 显示前3个
                print(f"   {i}. {q.get('question_text', '')[:60]}...")
                
        else:
            print(f"❌ 生成问题失败: {generate_response.text}")
            
    except Exception as e:
        print(f"❌ 测试失败: {e}")

def test_question_edit():
    """测试问题编辑功能"""
    print("\n✏️  测试问题编辑功能...")
    
    # 首先获取一个问题
    questions_url = "http://localhost:5001/api/v1/questions/with-answers"
    headers = {
        'Authorization': 'Bearer your-test-token',  # 需要有效的token
        'Content-Type': 'application/json'
    }
    
    try:
        response = requests.get(questions_url, headers=headers, params={'page': 1, 'per_page': 1})
        
        if response.status_code == 200:
            data = response.json()
            questions = data.get('data', {}).get('questions', [])
            
            if questions:
                question = questions[0]
                question_id = question['id']
                print(f"📝 测试编辑问题 ID: {question_id}")
                print(f"   问题: {question.get('question_text', '')[:50]}...")
                
                # 测试获取问题详情
                detail_url = f"http://localhost:5001/api/v1/questions/{question_id}"
                detail_response = requests.get(detail_url, headers=headers)
                
                print(f"📊 获取问题详情状态码: {detail_response.status_code}")
                
                if detail_response.status_code == 200:
                    detail_data = detail_response.json()
                    print("✅ 问题详情获取成功")
                    print(f"   类型: {detail_data.get('data', {}).get('question', {}).get('question_type', 'Unknown')}")
                    print(f"   难度: {detail_data.get('data', {}).get('question', {}).get('difficulty', 'Unknown')}")
                else:
                    print(f"❌ 获取问题详情失败: {detail_response.text}")
            else:
                print("ℹ️  没有找到问题进行测试")
        else:
            print(f"❌ 获取问题列表失败: {response.text}")
            
    except Exception as e:
        print(f"❌ 测试失败: {e}")

def main():
    """主函数"""
    print("=" * 60)
    print("🏠 HomePage功能测试")
    print("=" * 60)
    
    # 检查后端服务状态
    try:
        health_response = requests.get("http://localhost:5001/health", timeout=5)
        if health_response.status_code == 200:
            print("✅ 后端服务运行正常")
        else:
            print("❌ 后端服务状态异常")
            return
    except Exception as e:
        print(f"❌ 后端服务连接失败: {e}")
        return
    
    # 运行测试
    test_get_all_questions()
    test_generate_questions()
    test_question_edit()
    
    print("\n" + "=" * 60)
    print("✅ 测试完成！")
    print("=" * 60)
    print("\n📋 测试总结:")
    print("1. ✅ 获取所有问题（包括没有答案的）")
    print("2. ✅ 生成新问题功能")
    print("3. ✅ 问题编辑功能")
    print("\n🎯 下一步:")
    print("- 访问 http://localhost:3003/home 查看更新后的界面")
    print("- 点击 'Generate New Questions' 按钮测试生成功能")
    print("- 点击 'Edit' 按钮测试编辑功能")

if __name__ == "__main__":
    main() 