#!/usr/bin/env python3
"""
测试问题详情API修复
验证get_question_detail端点是否正确返回latest_answer字段
"""

import sys
import os
import requests
import json

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_question_detail_api():
    """测试问题详情API"""
    print("🔍 测试问题详情API修复...")
    
    # 使用开发API登录获取token
    login_url = "http://localhost:5001/api/v1/dev/login"
    
    try:
        # 登录
        login_response = requests.post(login_url, headers={'Content-Type': 'application/json'})
        print(f"📊 登录状态码: {login_response.status_code}")
        
        if login_response.status_code != 200:
            print("❌ 登录失败，无法获取token")
            return
            
        login_result = login_response.json()
        token = login_result.get('data', {}).get('access_token')
        
        if not token:
            print("❌ 登录成功但未获取到token")
            return
            
        print("✅ 登录成功，获取到token")
        
        # 获取问题列表
        questions_url = "http://localhost:5001/api/v1/questions/with-answers"
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        questions_response = requests.get(questions_url, headers=headers, params={'page': 1, 'per_page': 5})
        
        if questions_response.status_code != 200:
            print("❌ 获取问题列表失败")
            return
            
        questions_data = questions_response.json()
        questions = questions_data.get('data', {}).get('questions', [])
        
        if not questions:
            print("❌ 没有找到问题进行测试")
            return
            
        # 测试第一个问题
        test_question = questions[0]
        question_id = test_question['id']
        
        print(f"📝 测试问题 ID: {question_id}")
        print(f"   问题: {test_question.get('question_text', '')[:50]}...")
        
        # 测试问题详情API
        detail_url = f"http://localhost:5001/api/v1/questions/{question_id}"
        detail_response = requests.get(detail_url, headers=headers)
        
        print(f"📊 问题详情API状态码: {detail_response.status_code}")
        
        if detail_response.status_code == 200:
            detail_data = detail_response.json()
            question_detail = detail_data.get('data', {}).get('question', {})
            
            print("✅ 问题详情API调用成功")
            print(f"   问题ID: {question_detail.get('id')}")
            print(f"   问题类型: {question_detail.get('question_type')}")
            print(f"   难度: {question_detail.get('difficulty')}")
            
            # 检查latest_answer字段
            latest_answer = question_detail.get('latest_answer')
            if latest_answer:
                print("✅ 找到latest_answer字段")
                print(f"   答案ID: {latest_answer.get('id')}")
                print(f"   答案文本: {latest_answer.get('answer_text', '')[:50]}...")
                print(f"   分数: {latest_answer.get('score')}")
                print(f"   回答时间: {latest_answer.get('answered_at')}")
            else:
                print("ℹ️  没有latest_answer字段（这是正常的，如果问题还没有答案）")
                
            # 检查数据结构
            print("\n📋 完整数据结构:")
            print(json.dumps(question_detail, indent=2, ensure_ascii=False))
            
        else:
            print(f"❌ 问题详情API调用失败: {detail_response.text}")
            
    except Exception as e:
        print(f"❌ 测试失败: {e}")

def main():
    """主函数"""
    print("=" * 60)
    print("🔧 问题详情API修复测试")
    print("=" * 60)
    
    # 检查后端服务状态
    try:
        health_response = requests.get("http://localhost:5001/health", timeout=5)
        if health_response.status_code == 200:
            print("✅ 后端服务运行正常")
        else:
            print("❌ 后端服务状态异常")
            return
    except Exception as e:
        print(f"❌ 后端服务连接失败: {e}")
        return
    
    # 运行测试
    test_question_detail_api()
    
    print("\n" + "=" * 60)
    print("✅ 测试完成！")
    print("=" * 60)

if __name__ == "__main__":
    main() 