#!/usr/bin/env python3
"""
测试密码哈希功能
"""
import sys
import os

# 添加backend目录到路径
sys.path.insert(0, 'backend')

try:
    from werkzeug.security import generate_password_hash, check_password_hash
    
    print("测试Werkzeug密码哈希功能:")
    
    # 测试不同的哈希方法
    methods = ['pbkdf2:sha256', 'pbkdf2:sha1', 'pbkdf2:sha512']
    
    for method in methods:
        try:
            print(f"\n尝试方法: {method}")
            password = "test123"
            hash_result = generate_password_hash(password, method=method)
            print(f"哈希成功: {hash_result[:50]}...")
            
            # 验证密码
            is_valid = check_password_hash(hash_result, password)
            print(f"验证结果: {is_valid}")
            
            if is_valid:
                print(f"✅ {method} 方法工作正常")
                break
        except Exception as e:
            print(f"❌ {method} 方法失败: {e}")
    
    # 测试默认方法
    try:
        print(f"\n尝试默认方法:")
        hash_result = generate_password_hash("test123")
        print(f"默认哈希成功: {hash_result[:50]}...")
        is_valid = check_password_hash(hash_result, "test123")
        print(f"验证结果: {is_valid}")
    except Exception as e:
        print(f"❌ 默认方法失败: {e}")
        
except ImportError as e:
    print(f"导入错误: {e}")
except Exception as e:
    print(f"其他错误: {e}") 