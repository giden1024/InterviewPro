#!/usr/bin/env python3
"""
使用内存模拟Redis的缓存功能测试
"""

import sys
import os
import json
import hashlib
from typing import Dict, Any, Optional
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 模拟Redis存储
mock_redis_store = {}

class MockRedisClient:
    """模拟Redis客户端"""
    
    def __init__(self):
        self.store = mock_redis_store
    
    def get(self, key: str) -> Optional[str]:
        """获取值"""
        return self.store.get(key)
    
    def setex(self, key: str, ttl: int, value: str) -> bool:
        """设置值并设置过期时间"""
        self.store[key] = value
        return True
    
    def delete(self, *keys) -> int:
        """删除键"""
        deleted_count = 0
        for key in keys:
            if key in self.store:
                del self.store[key]
                deleted_count += 1
        return deleted_count
    
    def keys(self, pattern: str) -> list:
        """获取匹配模式的键"""
        import fnmatch
        return [key for key in self.store.keys() if fnmatch.fnmatch(key, pattern)]
    
    def memory_usage(self, key: str) -> Optional[int]:
        """获取内存使用量"""
        value = self.store.get(key)
        if value:
            return len(value.encode('utf-8'))
        return None

# 模拟简历模型
class MockResume:
    def __init__(self, id: int, user_id: int, name: str, skills: list, experience: list, education: list, raw_text: str):
        self.id = id
        self.user_id = user_id
        self.name = name
        self.skills = skills
        self.experience = experience
        self.education = education
        self.raw_text = raw_text

class MockQuestionCacheService:
    """模拟的问题缓存服务"""
    
    def __init__(self):
        self.cache_ttl = 3600  # 1小时缓存过期时间
        self.cache_prefix = "questions:cache"
        self.redis_client = MockRedisClient()
    
    def _generate_resume_hash(self, resume: MockResume) -> str:
        """生成简历内容哈希"""
        try:
            # 基于简历的关键信息生成哈希
            resume_content = {
                'skills': sorted(resume.skills or []),
                'experience_count': len(resume.experience or []),
                'education_count': len(resume.education or []),
                'summary_hash': hashlib.md5((resume.raw_text or "").encode()).hexdigest()[:16]
            }
            
            content_string = json.dumps(resume_content, sort_keys=True)
            return hashlib.md5(content_string.encode()).hexdigest()
        except Exception as e:
            print(f"生成简历哈希失败: {e}")
            # 如果生成哈希失败，使用简历ID作为备选
            return f"resume_{resume.id}"
    
    def _generate_cache_key(self, user_id: int, resume: MockResume, 
                           interview_type: str, total_questions: int,
                           difficulty_distribution: Dict[str, int], 
                           type_distribution: Dict[str, int]) -> str:
        """生成改进的缓存键"""
        
        # 生成简历内容哈希
        resume_hash = self._generate_resume_hash(resume)
        
        cache_data = {
            'user_id': user_id,                    # ✅ 用户ID
            'resume_hash': resume_hash,            # ✅ 简历内容哈希
            'interview_type': interview_type,      # ✅ 面试类型
            'total_questions': total_questions,    # ✅ 问题数量
            'difficulty_distribution': difficulty_distribution,
            'type_distribution': type_distribution
        }
        
        # 使用JSON字符串的哈希作为缓存键
        cache_string = json.dumps(cache_data, sort_keys=True)
        cache_hash = hashlib.md5(cache_string.encode()).hexdigest()
        
        return f"{self.cache_prefix}:{cache_hash}"
    
    def get_cached_questions(self, user_id: int, resume: MockResume, 
                           interview_type: str, total_questions: int,
                           difficulty_distribution: Dict[str, int], 
                           type_distribution: Dict[str, int]) -> Optional[list]:
        """从缓存获取问题"""
        try:
            cache_key = self._generate_cache_key(
                user_id, resume, interview_type, total_questions,
                difficulty_distribution, type_distribution
            )
            
            cached_data = self.redis_client.get(cache_key)
            if cached_data:
                cache_info = json.loads(cached_data)
                questions = cache_info.get('questions', [])
                print(f"✅ 用户{user_id}从缓存获取到 {len(questions)} 个问题")
                return questions
            else:
                print(f"❌ 用户{user_id}缓存未命中，需要重新生成")
                return None
                
        except Exception as e:
            print(f"缓存读取失败: {e}")
            return None
    
    def cache_questions(self, user_id: int, resume: MockResume, 
                       interview_type: str, total_questions: int,
                       difficulty_distribution: Dict[str, int], 
                       type_distribution: Dict[str, int], 
                       questions: list) -> bool:
        """缓存问题"""
        try:
            cache_key = self._generate_cache_key(
                user_id, resume, interview_type, total_questions,
                difficulty_distribution, type_distribution
            )
            
            # 将问题序列化为JSON并存储到Redis，包含用户ID信息
            from datetime import datetime
            cache_data = {
                'user_id': user_id,
                'questions': questions,
                'cached_at': datetime.now().isoformat()
            }
            cache_json = json.dumps(cache_data, ensure_ascii=False)
            self.redis_client.setex(cache_key, self.cache_ttl, cache_json)
            
            print(f"✅ 用户{user_id}成功缓存 {len(questions)} 个问题")
            return True
            
        except Exception as e:
            print(f"缓存存储失败: {e}")
            return False
    
    def clear_user_cache(self, user_id: int) -> bool:
        """清除用户的所有缓存"""
        try:
            pattern = f"{self.cache_prefix}:*"
            keys = self.redis_client.keys(pattern)
            cleared_count = 0
            
            for key in keys:
                cached_data = self.redis_client.get(key)
                if cached_data:
                    try:
                        cache_info = json.loads(cached_data)
                        if cache_info.get('user_id') == user_id:
                            self.redis_client.delete(key)
                            cleared_count += 1
                    except:
                        continue
            
            print(f"✅ 清除了用户{user_id}的 {cleared_count} 个缓存项")
            return True
            
        except Exception as e:
            print(f"清除用户缓存失败: {e}")
            return False
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        try:
            pattern = f"{self.cache_prefix}:*"
            keys = self.redis_client.keys(pattern)
            
            total_keys = len(keys)
            total_memory = 0
            
            for key in keys:
                memory_usage = self.redis_client.memory_usage(key)
                if memory_usage:
                    total_memory += memory_usage
            
            return {
                "total_cached_questions": total_keys,
                "total_memory_usage_bytes": total_memory,
                "total_memory_usage_mb": round(total_memory / 1024 / 1024, 2),
                "cache_ttl_seconds": self.cache_ttl
            }
            
        except Exception as e:
            print(f"获取缓存统计失败: {e}")
            return {"error": str(e)}

def test_cache_functionality():
    """测试缓存功能"""
    print("🧪 开始测试改进的缓存功能（使用模拟Redis）...")
    
    # 1. 测试缓存服务
    cache_service = MockQuestionCacheService()
    print("✅ 缓存服务初始化成功")
    
    # 2. 创建测试简历
    test_resume = MockResume(
        id=999,
        user_id=1,
        name="测试候选人",
        skills=["Python", "JavaScript", "React"],
        experience=[{"title": "软件工程师", "company": "测试公司", "duration": "2年"}],
        education=[{"degree": "计算机科学", "school": "测试大学"}],
        raw_text="测试简历内容，包含Python和JavaScript技能"
    )
    print("✅ 测试简历创建成功")
    
    # 3. 测试缓存键生成
    cache_key = cache_service._generate_cache_key(
        user_id=1,
        resume=test_resume,
        interview_type="comprehensive",
        total_questions=8,
        difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
        type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
    )
    print(f"✅ 缓存键生成成功: {cache_key[:20]}...")
    
    # 4. 测试简历哈希生成
    resume_hash = cache_service._generate_resume_hash(test_resume)
    print(f"✅ 简历哈希生成成功: {resume_hash}")
    
    # 5. 测试缓存存储和获取
    test_questions = [
        {
            "question_text": "请介绍一下你的Python开发经验",
            "question_type": "technical",
            "difficulty": "medium",
            "category": "编程技能"
        },
        {
            "question_text": "你在团队协作中遇到过什么挑战？",
            "question_type": "behavioral", 
            "difficulty": "easy",
            "category": "团队合作"
        }
    ]
    
    # 存储到缓存
    cache_success = cache_service.cache_questions(
        user_id=1,
        resume=test_resume,
        interview_type="comprehensive",
        total_questions=8,
        difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
        type_distribution={"technical": 4, "behavioral": 2, "situational": 2},
        questions=test_questions
    )
    print(f"✅ 缓存存储: {'成功' if cache_success else '失败'}")
    
    # 从缓存获取
    cached_questions = cache_service.get_cached_questions(
        user_id=1,
        resume=test_resume,
        interview_type="comprehensive",
        total_questions=8,
        difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
        type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
    )
    
    if cached_questions:
        print(f"✅ 缓存获取成功，获取到 {len(cached_questions)} 个问题")
        for i, q in enumerate(cached_questions):
            print(f"   问题{i+1}: {q['question_text']}")
    else:
        print("❌ 缓存获取失败")
    
    # 6. 测试用户隔离
    print("\n🔍 测试用户隔离...")
    cached_questions_user2 = cache_service.get_cached_questions(
        user_id=2,  # 不同用户
        resume=test_resume,
        interview_type="comprehensive",
        total_questions=8,
        difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
        type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
    )
    
    if cached_questions_user2:
        print("❌ 用户隔离失败：用户2获取到了用户1的缓存")
    else:
        print("✅ 用户隔离成功：用户2无法获取用户1的缓存")
    
    # 7. 测试缓存统计
    stats = cache_service.get_cache_stats()
    print(f"✅ 缓存统计: {stats}")
    
    # 8. 测试用户缓存清除
    clear_success = cache_service.clear_user_cache(1)
    print(f"✅ 用户缓存清除: {'成功' if clear_success else '失败'}")
    
    # 验证清除后无法获取
    cached_questions_after_clear = cache_service.get_cached_questions(
        user_id=1,
        resume=test_resume,
        interview_type="comprehensive",
        total_questions=8,
        difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
        type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
    )
    
    if cached_questions_after_clear:
        print("❌ 缓存清除失败：仍能获取到缓存")
    else:
        print("✅ 缓存清除成功：无法获取到缓存")
    
    # 9. 测试相同内容不同ID的简历
    print("\n🔍 测试相同内容不同ID的简历...")
    test_resume2 = MockResume(
        id=1000,  # 不同ID
        user_id=1,
        name="测试候选人",
        skills=["Python", "JavaScript", "React"],  # 相同内容
        experience=[{"title": "软件工程师", "company": "测试公司", "duration": "2年"}],
        education=[{"degree": "计算机科学", "school": "测试大学"}],
        raw_text="测试简历内容，包含Python和JavaScript技能"
    )
    
    # 重新缓存
    cache_service.cache_questions(
        user_id=1,
        resume=test_resume2,
        interview_type="comprehensive",
        total_questions=8,
        difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
        type_distribution={"technical": 4, "behavioral": 2, "situational": 2},
        questions=test_questions
    )
    
    # 尝试用第一个简历获取缓存
    cached_same_content = cache_service.get_cached_questions(
        user_id=1,
        resume=test_resume,  # 使用第一个简历
        interview_type="comprehensive",
        total_questions=8,
        difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
        type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
    )
    
    if cached_same_content:
        print("✅ 内容识别成功：相同内容的简历可以共享缓存")
    else:
        print("❌ 内容识别失败：相同内容的简历无法共享缓存")
    
    print("\n🎉 缓存功能测试完成！")

if __name__ == "__main__":
    print("🚀 开始缓存功能测试（使用模拟Redis）...")
    
    try:
        test_cache_functionality()
        print("\n✅ 所有测试完成！")
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc() 