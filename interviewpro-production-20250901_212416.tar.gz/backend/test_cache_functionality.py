#!/usr/bin/env python3
"""
测试改进的缓存功能
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app.models.resume import Resume
from app.services.question_cache_service import QuestionCacheService
from app.services.ai_question_generator import AIQuestionGenerator
from app.models.question import InterviewType

def test_cache_functionality():
    """测试缓存功能"""
    app = create_app()
    
    with app.app_context():
        print("🧪 开始测试改进的缓存功能...")
        
        # 1. 测试缓存服务
        cache_service = QuestionCacheService()
        print("✅ 缓存服务初始化成功")
        
        # 2. 创建测试简历
        test_resume = Resume(
            id=999,
            user_id=1,
            name="测试候选人",
            skills=["Python", "JavaScript", "React"],
            experience=[{"title": "软件工程师", "company": "测试公司", "duration": "2年"}],
            education=[{"degree": "计算机科学", "school": "测试大学"}],
            raw_text="测试简历内容，包含Python和JavaScript技能"
        )
        print("✅ 测试简历创建成功")
        
        # 3. 测试缓存键生成
        cache_key = cache_service._generate_cache_key(
            user_id=1,
            resume=test_resume,
            interview_type="comprehensive",
            total_questions=8,
            difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
            type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
        )
        print(f"✅ 缓存键生成成功: {cache_key[:20]}...")
        
        # 4. 测试简历哈希生成
        resume_hash = cache_service._generate_resume_hash(test_resume)
        print(f"✅ 简历哈希生成成功: {resume_hash}")
        
        # 5. 测试缓存存储和获取
        test_questions = [
            {
                "question_text": "请介绍一下你的Python开发经验",
                "question_type": "technical",
                "difficulty": "medium",
                "category": "编程技能"
            },
            {
                "question_text": "你在团队协作中遇到过什么挑战？",
                "question_type": "behavioral", 
                "difficulty": "easy",
                "category": "团队合作"
            }
        ]
        
        # 存储到缓存
        cache_success = cache_service.cache_questions(
            user_id=1,
            resume=test_resume,
            interview_type="comprehensive",
            total_questions=8,
            difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
            type_distribution={"technical": 4, "behavioral": 2, "situational": 2},
            questions=test_questions
        )
        print(f"✅ 缓存存储: {'成功' if cache_success else '失败'}")
        
        # 从缓存获取
        cached_questions = cache_service.get_cached_questions(
            user_id=1,
            resume=test_resume,
            interview_type="comprehensive",
            total_questions=8,
            difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
            type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
        )
        
        if cached_questions:
            print(f"✅ 缓存获取成功，获取到 {len(cached_questions)} 个问题")
            for i, q in enumerate(cached_questions):
                print(f"   问题{i+1}: {q['question_text']}")
        else:
            print("❌ 缓存获取失败")
        
        # 6. 测试用户隔离
        print("\n🔍 测试用户隔离...")
        cached_questions_user2 = cache_service.get_cached_questions(
            user_id=2,  # 不同用户
            resume=test_resume,
            interview_type="comprehensive",
            total_questions=8,
            difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
            type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
        )
        
        if cached_questions_user2:
            print("❌ 用户隔离失败：用户2获取到了用户1的缓存")
        else:
            print("✅ 用户隔离成功：用户2无法获取用户1的缓存")
        
        # 7. 测试缓存统计
        stats = cache_service.get_cache_stats()
        print(f"✅ 缓存统计: {stats}")
        
        # 8. 测试用户缓存清除
        clear_success = cache_service.clear_user_cache(1)
        print(f"✅ 用户缓存清除: {'成功' if clear_success else '失败'}")
        
        # 验证清除后无法获取
        cached_questions_after_clear = cache_service.get_cached_questions(
            user_id=1,
            resume=test_resume,
            interview_type="comprehensive",
            total_questions=8,
            difficulty_distribution={"easy": 3, "medium": 3, "hard": 2},
            type_distribution={"technical": 4, "behavioral": 2, "situational": 2}
        )
        
        if cached_questions_after_clear:
            print("❌ 缓存清除失败：仍能获取到缓存")
        else:
            print("✅ 缓存清除成功：无法获取到缓存")
        
        print("\n🎉 缓存功能测试完成！")

def test_ai_generator_with_cache():
    """测试AI生成器与缓存的集成"""
    app = create_app()
    
    with app.app_context():
        print("\n🤖 开始测试AI生成器与缓存集成...")
        
        # 创建测试简历
        test_resume = Resume(
            id=1000,
            user_id=1,
            name="AI测试候选人",
            skills=["Python", "Machine Learning", "Data Science"],
            experience=[{"title": "数据科学家", "company": "AI公司", "duration": "3年"}],
            education=[{"degree": "人工智能", "school": "AI大学"}],
            raw_text="AI测试简历内容，包含机器学习和数据科学技能"
        )
        
        # 初始化AI生成器
        generator = AIQuestionGenerator()
        
        print("🔄 第一次生成问题（应该调用AI API）...")
        questions1 = generator.generate_questions_for_resume(
            resume=test_resume,
            user_id=1,
            interview_type=InterviewType.COMPREHENSIVE,
            total_questions=5
        )
        print(f"✅ 第一次生成完成，获得 {len(questions1)} 个问题")
        
        print("🔄 第二次生成问题（应该使用缓存）...")
        questions2 = generator.generate_questions_for_resume(
            resume=test_resume,
            user_id=1,
            interview_type=InterviewType.COMPREHENSIVE,
            total_questions=5
        )
        print(f"✅ 第二次生成完成，获得 {len(questions2)} 个问题")
        
        # 验证缓存是否生效
        if questions1 == questions2:
            print("✅ 缓存生效：两次生成的问题相同")
        else:
            print("❌ 缓存可能未生效：两次生成的问题不同")
        
        print("🎉 AI生成器缓存集成测试完成！")

if __name__ == "__main__":
    print("🚀 开始缓存功能测试...")
    
    try:
        test_cache_functionality()
        test_ai_generator_with_cache()
        print("\n✅ 所有测试完成！")
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc() 