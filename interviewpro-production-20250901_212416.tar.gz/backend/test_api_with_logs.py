#!/usr/bin/env python3
"""
带日志的API测试
"""

import requests
import json
import time

def test_api_with_logs():
    """带日志的API测试"""
    base_url = "http://localhost:5001"
    
    # 1. 登录
    print("🔐 登录...")
    login_response = requests.post(f"{base_url}/api/v1/dev/login", json={
        "email": "test@example.com",
        "password": "123456"
    })
    
    if login_response.status_code != 200:
        print(f"❌ 登录失败: {login_response.status_code}")
        return
    
    login_data = login_response.json()
    token = login_data['data']['access_token']
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # 2. 获取面试会话
    print("📋 获取面试会话...")
    sessions_response = requests.get(f"{base_url}/api/v1/interviews", headers=headers)
    
    if sessions_response.status_code != 200:
        print(f"❌ 获取会话失败: {sessions_response.status_code}")
        return
    
    sessions_data = sessions_response.json()
    sessions = sessions_data.get('data', {}).get('sessions', [])
    
    if not sessions:
        print("❌ 没有找到面试会话")
        return
    
    session = sessions[0]
    session_id = session['session_id']
    print(f"✅ 找到会话: {session_id}")
    
    # 3. 获取问题
    print("❓ 获取问题...")
    questions_response = requests.get(f"{base_url}/api/v1/questions/session/{session_id}", headers=headers)
    
    if questions_response.status_code != 200:
        print(f"❌ 获取问题失败: {questions_response.status_code}")
        return
    
    questions_data = questions_response.json()
    questions = questions_data.get('data', {}).get('questions', [])
    
    if not questions:
        print("❌ 没有找到问题")
        return
    
    question = questions[0]
    question_id = question['id']
    print(f"✅ 找到问题: {question_id}")
    
    # 4. 提交答案
    print("📝 提交答案...")
    answer_data = {
        "question_id": question_id,
        "answer_text": "这是一个带日志的测试答案。",
        "response_time": 30
    }
    
    print(f"📤 发送数据: {json.dumps(answer_data, ensure_ascii=False)}")
    print(f"📤 目标URL: {base_url}/api/v1/interviews/{session_id}/answer")
    
    # 记录时间戳
    start_time = time.time()
    
    try:
        answer_response = requests.post(
            f"{base_url}/api/v1/interviews/{session_id}/answer",
            headers=headers,
            json=answer_data,
            timeout=30
        )
        
        end_time = time.time()
        print(f"⏱️ 请求耗时: {end_time - start_time:.2f}秒")
        
        print(f"📊 响应状态: {answer_response.status_code}")
        print(f"📄 响应头: {dict(answer_response.headers)}")
        print(f"📄 响应内容: {answer_response.text}")
        
        if answer_response.status_code == 200:
            print("✅ 答案提交成功！")
            result_data = answer_response.json()
            print(f"📋 提交结果: {json.dumps(result_data, indent=2, ensure_ascii=False)}")
        else:
            print("❌ 答案提交失败！")
            try:
                error_data = answer_response.json()
                print(f"🔍 错误详情: {json.dumps(error_data, indent=2, ensure_ascii=False)}")
            except Exception as e:
                print(f"🔍 JSON解析错误: {e}")
                print(f"🔍 原始响应: {answer_response.text}")
                
    except requests.exceptions.RequestException as e:
        print(f"❌ 请求异常: {e}")
    except Exception as e:
        print(f"❌ 其他异常: {e}")
    
    # 5. 等待一下，然后检查日志
    print("\n⏳ 等待2秒，然后检查后端日志...")
    time.sleep(2)
    
    # 检查最近的日志
    import subprocess
    try:
        log_output = subprocess.check_output(['tail', '-n', '20', 'backend.log'], text=True)
        print("📋 最近的日志:")
        print(log_output)
    except Exception as e:
        print(f"❌ 无法读取日志: {e}")

if __name__ == '__main__':
    test_api_with_logs()
