#!/usr/bin/env python3
"""
测试Flask应用路由注册情况
"""
from app import create_app

def test_routes():
    app = create_app()
    
    print("=== Flask应用路由列表 ===")
    for rule in app.url_map.iter_rules():
        print(f"{rule.rule} -> {rule.endpoint}")
    
    print("\n=== 检查questions蓝图路由 ===")
    questions_routes = [rule for rule in app.url_map.iter_rules() if 'questions' in rule.rule]
    for rule in questions_routes:
        print(f"{rule.rule} -> {rule.endpoint}")
    
    print("\n=== 检查generate-async路由 ===")
    async_routes = [rule for rule in app.url_map.iter_rules() if 'generate-async' in rule.rule]
    for rule in async_routes:
        print(f"{rule.rule} -> {rule.endpoint}")

if __name__ == "__main__":
    test_routes() 