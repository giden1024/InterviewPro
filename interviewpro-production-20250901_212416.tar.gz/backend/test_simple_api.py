#!/usr/bin/env python3
"""
简单API测试
"""

import requests
import json

def test_simple_api():
    """简单API测试"""
    base_url = "http://localhost:5001"
    
    # 1. 登录
    print("🔐 登录...")
    login_response = requests.post(f"{base_url}/api/v1/dev/login", json={
        "email": "test@example.com",
        "password": "123456"
    })
    
    if login_response.status_code != 200:
        print(f"❌ 登录失败: {login_response.status_code}")
        return
    
    login_data = login_response.json()
    token = login_data['data']['access_token']
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # 2. 直接测试一个简单的API
    print("🔍 测试健康检查...")
    health_response = requests.get(f"{base_url}/api/v1/health", headers=headers)
    print(f"健康检查状态: {health_response.status_code}")
    print(f"健康检查响应: {health_response.text}")
    
    # 3. 测试获取面试会话
    print("\n🔍 测试获取面试会话...")
    sessions_response = requests.get(f"{base_url}/api/v1/interviews", headers=headers)
    print(f"获取会话状态: {sessions_response.status_code}")
    
    if sessions_response.status_code == 200:
        sessions_data = sessions_response.json()
        sessions = sessions_data.get('data', {}).get('sessions', [])
        if sessions:
            session = sessions[0]
            session_id = session['session_id']
            print(f"找到会话: {session_id}")
            
            # 4. 测试获取问题
            print(f"\n🔍 测试获取问题...")
            questions_response = requests.get(f"{base_url}/api/v1/questions/session/{session_id}", headers=headers)
            print(f"获取问题状态: {questions_response.status_code}")
            
            if questions_response.status_code == 200:
                questions_data = questions_response.json()
                questions = questions_data.get('data', {}).get('questions', [])
                if questions:
                    question = questions[0]
                    question_id = question['id']
                    print(f"找到问题: {question_id}")
                    
                    # 5. 测试提交答案
                    print(f"\n🔍 测试提交答案...")
                    answer_data = {
                        "question_id": question_id,
                        "answer_text": "测试答案",
                        "response_time": 30
                    }
                    
                    answer_response = requests.post(
                        f"{base_url}/api/v1/interviews/{session_id}/answer",
                        headers=headers,
                        json=answer_data
                    )
                    
                    print(f"提交答案状态: {answer_response.status_code}")
                    print(f"提交答案响应: {answer_response.text}")
                    
                    # 如果失败，尝试获取更多信息
                    if answer_response.status_code != 200:
                        print(f"\n🔍 详细错误信息:")
                        print(f"响应头: {dict(answer_response.headers)}")
                        try:
                            error_json = answer_response.json()
                            print(f"错误JSON: {json.dumps(error_json, indent=2, ensure_ascii=False)}")
                        except:
                            print(f"原始响应: {answer_response.text}")

if __name__ == '__main__':
    test_simple_api()
