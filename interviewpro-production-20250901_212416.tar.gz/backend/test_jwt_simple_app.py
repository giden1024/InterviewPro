#!/usr/bin/env python3
"""
简单的JWT测试应用
"""

from flask import Flask, jsonify
from flask_jwt_extended import JWTManager, jwt_required

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'test-secret-key'

jwt = JWTManager(app)

# 配置JWT错误处理
@jwt.expired_token_loader
def expired_token_callback(jwt_header, jwt_payload):
    return jsonify({
        'success': False,
        'error': {
            'code': 'TOKEN_EXPIRED',
            'message': 'Token has expired'
        }
    }), 401

@jwt.invalid_token_loader
def invalid_token_callback(error):
    return jsonify({
        'success': False,
        'error': {
            'code': 'INVALID_TOKEN',
            'message': 'Invalid token'
        }
    }), 422

@jwt.unauthorized_loader
def missing_token_callback(error):
    return jsonify({
        'success': False,
        'error': {
            'code': 'MISSING_TOKEN',
            'message': 'Missing Authorization Header'
        }
    }), 401

@app.route('/test')
@jwt_required()
def test():
    return jsonify({'message': 'Success'})

if __name__ == '__main__':
    app.run(debug=True, port=5002) 