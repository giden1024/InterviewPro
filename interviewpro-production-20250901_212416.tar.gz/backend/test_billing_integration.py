#!/usr/bin/env python3
"""
Creem.io 付费集成测试脚本
"""
import os
import sys
import json
import requests
from datetime import datetime

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.subscription import Subscription, PaymentHistory

def test_api_endpoints():
    """测试API端点"""
    print("🧪 测试付费API端点...")
    
    app = create_app()
    base_url = 'http://localhost:5001'
    
    with app.test_client() as client:
        # 1. 测试获取付费计划
        print("\n1️⃣ 测试获取付费计划...")
        response = client.get('/api/v1/billing/plans')
        
        if response.status_code == 200:
            data = response.get_json()
            print("✅ 付费计划API正常")
            print(f"   返回计划数量: {len(data.get('data', {}))}")
            
            # 显示计划详情
            for plan_key, plan_info in data.get('data', {}).items():
                print(f"   - {plan_key}: {plan_info['name']} (¥{plan_info['price']})")
        else:
            print(f"❌ 付费计划API失败: {response.status_code}")
            print(f"   响应: {response.get_data(as_text=True)}")
        
        # 2. 测试需要认证的端点（应该返回401）
        protected_endpoints = [
            '/api/v1/billing/subscription',
            '/api/v1/billing/usage', 
            '/api/v1/billing/history',
            '/api/v1/billing/checkout'
        ]
        
        print("\n2️⃣ 测试需要认证的端点...")
        for endpoint in protected_endpoints:
            if endpoint == '/api/v1/billing/checkout':
                response = client.post(endpoint, json={'plan': 'basic'})
            else:
                response = client.get(endpoint)
            
            if response.status_code in [401, 422]:  # 未认证或JWT错误
                print(f"✅ {endpoint} - 正确返回认证错误 ({response.status_code})")
            else:
                print(f"⚠️  {endpoint} - 意外状态码: {response.status_code}")

def test_subscription_utils():
    """测试订阅工具函数"""
    print("\n🔧 测试订阅工具函数...")
    
    from app.utils.subscription_utils import (
        get_pricing_plans, 
        create_user_subscription,
        get_user_subscription_status
    )
    
    app = create_app()
    
    with app.app_context():
        # 1. 测试获取付费计划
        print("1️⃣ 测试获取付费计划...")
        plans = get_pricing_plans()
        
        if plans and isinstance(plans, dict):
            print(f"✅ 成功获取 {len(plans)} 个付费计划")
            for plan_key in plans.keys():
                print(f"   - {plan_key}")
        else:
            print("❌ 获取付费计划失败")
        
        # 2. 测试创建用户订阅
        print("\n2️⃣ 测试创建用户订阅...")
        
        # 创建测试用户
        test_user = User.query.filter_by(email='test_billing@example.com').first()
        if not test_user:
            test_user = User(
                email='test_billing@example.com',
                username='test_billing_user'
            )
            test_user.set_password('test123')
            db.session.add(test_user)
            db.session.commit()
            print("✅ 创建测试用户")
        else:
            print("ℹ️  使用现有测试用户")
        
        # 创建订阅
        try:
            subscription = create_user_subscription(test_user.id, 'free')
            print(f"✅ 创建订阅成功: ID {subscription.id}")
        except Exception as e:
            print(f"ℹ️  订阅可能已存在: {str(e)}")
        
        # 3. 测试获取用户订阅状态
        print("\n3️⃣ 测试获取用户订阅状态...")
        try:
            status = get_user_subscription_status(test_user.id)
            if status:
                print("✅ 获取订阅状态成功")
                print(f"   计划: {status['subscription']['plan']}")
                print(f"   状态: {status['subscription']['status']}")
                print(f"   本月面试使用: {status['usage']['interviews']['used']}/{status['usage']['interviews']['limit']}")
            else:
                print("❌ 获取订阅状态失败")
        except Exception as e:
            print(f"❌ 获取订阅状态错误: {str(e)}")

def test_creem_api_connection():
    """测试Creem.io API连接"""
    print("\n🌐 测试Creem.io API连接...")
    
    app = create_app()
    
    with app.app_context():
        api_key = app.config.get('CREEM_API_KEY')
        product_id = app.config.get('CREEM_TEST_PRODUCT_ID')
        test_mode = app.config.get('CREEM_TEST_MODE', True)
        
        if not api_key:
            print("❌ 未配置CREEM_API_KEY")
            return
        
        if not product_id:
            print("❌ 未配置CREEM_TEST_PRODUCT_ID")
            return
        
        print(f"🔑 API Key: {api_key[:15]}...")
        print(f"📦 Product ID: {product_id}")
        print(f"🧪 测试模式: {test_mode}")
        
        # 测试创建checkout会话
        api_url = 'https://test-api.creem.io/v1/checkouts' if test_mode else 'https://api.creem.io/v1/checkouts'
        
        checkout_data = {
            'product_id': product_id,
            'success_url': 'http://localhost:3000/billing/success',
            'request_id': f'test_{int(datetime.now().timestamp())}'
        }
        
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        
        try:
            print("\n📡 发送测试请求到Creem.io...")
            print(f"URL: {api_url}")
            print(f"Data: {json.dumps(checkout_data, indent=2)}")
            
            response = requests.post(
                api_url,
                json=checkout_data,
                headers=headers,
                timeout=30
            )
            
            print(f"状态码: {response.status_code}")
            print(f"响应: {response.text[:500]}...")
            
            if response.status_code in [200, 201]:
                response_data = response.json()
                checkout_url = response_data.get('checkout_url') or response_data.get('url')
                
                if checkout_url:
                    print("✅ Creem.io API连接成功")
                    print(f"🔗 Checkout URL: {checkout_url[:50]}...")
                else:
                    print("⚠️  API响应成功但未返回checkout_url")
            else:
                print(f"❌ Creem.io API请求失败: {response.status_code}")
                print(f"错误详情: {response.text}")
                
        except requests.RequestException as e:
            print(f"❌ 网络请求失败: {str(e)}")
        except Exception as e:
            print(f"❌ 未知错误: {str(e)}")

def test_database_structure():
    """测试数据库结构"""
    print("\n🗄️ 测试数据库结构...")
    
    app = create_app()
    
    with app.app_context():
        inspector = db.inspect(db.engine)
        tables = inspector.get_table_names()
        
        # 检查必要的表
        required_tables = ['users', 'subscriptions', 'payment_history']
        missing_tables = [table for table in required_tables if table not in tables]
        
        if missing_tables:
            print(f"❌ 缺少必要的表: {', '.join(missing_tables)}")
        else:
            print("✅ 所有必要的表都存在")
        
        # 检查subscriptions表结构
        if 'subscriptions' in tables:
            columns = [col['name'] for col in inspector.get_columns('subscriptions')]
            required_columns = [
                'id', 'user_id', 'plan', 'status', 'creem_customer_id',
                'start_date', 'end_date', 'monthly_interviews_used'
            ]
            
            missing_columns = [col for col in required_columns if col not in columns]
            if missing_columns:
                print(f"⚠️  subscriptions表缺少列: {', '.join(missing_columns)}")
            else:
                print("✅ subscriptions表结构完整")
        
        # 检查数据
        subscription_count = Subscription.query.count()
        payment_count = PaymentHistory.query.count()
        user_count = User.query.count()
        
        print(f"📊 数据统计:")
        print(f"   用户数: {user_count}")
        print(f"   订阅数: {subscription_count}")
        print(f"   支付记录: {payment_count}")

def main():
    """主测试函数"""
    print("🎯 Creem.io 付费集成测试")
    print("=" * 60)
    
    # 测试数据库结构
    test_database_structure()
    
    # 测试API端点
    test_api_endpoints()
    
    # 测试订阅工具函数
    test_subscription_utils()
    
    # 测试Creem.io API连接
    test_creem_api_connection()
    
    print("\n" + "=" * 60)
    print("🎉 测试完成！")
    print("\n📋 如果所有测试都通过，您可以:")
    print("1. 启动前端服务测试付费页面")
    print("2. 在Creem.io测试模式下进行实际支付测试")
    print("3. 检查回调URL是否正确处理")

if __name__ == '__main__':
    main()
