#!/usr/bin/env python3
"""
直接测试service方法
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app.services.interview_service import InterviewService
from app.models.user import User
from app.models.question import Question, InterviewSession

def test_service_direct():
    """直接测试service方法"""
    app = create_app()
    
    with app.app_context():
        try:
            # 获取测试用户
            user = User.query.filter_by(email='test@example.com').first()
            if not user:
                print("❌ 测试用户不存在")
                return
            
            print(f"✅ 找到用户: {user.id}")
            
            # 获取用户的面试会话
            session = InterviewSession.query.filter_by(user_id=user.id).first()
            if not session:
                print("❌ 没有找到面试会话")
                return
            
            print(f"✅ 找到会话: {session.session_id}")
            
            # 获取问题
            question = Question.query.filter_by(user_id=user.id).first()
            if not question:
                print("❌ 没有找到问题")
                return
            
            print(f"✅ 找到问题: {question.id}")
            
            # 直接调用service方法
            service = InterviewService()
            
            print("🔍 调用submit_answer方法...")
            result = service.submit_answer(
                user_id=user.id,
                session_id=session.session_id,
                question_id=question.id,
                answer_text="这是一个直接测试的答案。",
                response_time=30
            )
            
            print(f"✅ 方法调用成功: {result}")
            
        except Exception as e:
            print(f"❌ 方法调用失败: {e}")
            import traceback
            traceback.print_exc()

if __name__ == '__main__':
    test_service_direct()
