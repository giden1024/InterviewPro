#!/usr/bin/env python3
"""
使用文件上传的测试流程
"""

import requests
import json
import time

def test_file_upload_flow():
    """使用文件上传的测试流程"""
    base_url = "http://localhost:5001"
    
    # 1. 创建测试用户并登录
    print("🔐 创建测试用户...")
    login_response = requests.post(f"{base_url}/api/v1/dev/login", json={
        "email": "test@example.com",
        "password": "123456"
    })
    
    if login_response.status_code != 200:
        print(f"❌ 登录失败: {login_response.status_code}")
        print(login_response.text)
        return
    
    login_data = login_response.json()
    token = login_data['data']['access_token']
    user_id = login_data['data']['user']['id']
    
    print(f"✅ 登录成功，用户ID: {user_id}")
    
    headers = {
        "Authorization": f"Bearer {token}"
    }
    
    # 2. 上传简历文件
    print("📄 上传简历文件...")
    with open('test_resume.txt', 'rb') as f:
        files = {'file': ('test_resume.txt', f, 'text/plain')}
        data = {
            'job_title': '前端开发工程师',
            'company': '测试公司'
        }
        
        resume_response = requests.post(
            f"{base_url}/api/v1/resumes",
            headers=headers,
            files=files,
            data=data
        )
    
    if resume_response.status_code != 200:
        print(f"❌ 简历上传失败: {resume_response.status_code}")
        print(resume_response.text)
        return
    
    resume_result = resume_response.json()
    resume_id = resume_result['data']['resume']['id']
    print(f"✅ 简历上传成功，ID: {resume_id}")
    
    # 等待简历处理
    print("⏳ 等待简历处理...")
    time.sleep(3)
    
    # 3. 创建面试会话
    print("🎯 创建面试会话...")
    interview_data = {
        "resume_id": resume_id,
        "interview_type": "mock",
        "total_questions": 5,
        "custom_title": "测试面试"
    }
    
    interview_response = requests.post(
        f"{base_url}/api/v1/interviews",
        headers={**headers, "Content-Type": "application/json"},
        json=interview_data
    )
    
    if interview_response.status_code not in [200, 201]:
        print(f"❌ 创建面试失败: {interview_response.status_code}")
        print(interview_response.text)
        return
    
    interview_result = interview_response.json()
    session_id = interview_result['data']['session']['session_id']
    print(f"✅ 面试会话创建成功，ID: {session_id}")
    
    # 4. 生成问题
    print("❓ 生成面试问题...")
    question_data = {
        "resume_id": resume_id,
        "session_id": session_id,
        "interview_type": "comprehensive",
        "total_questions": 5
    }
    
    question_response = requests.post(
        f"{base_url}/api/v1/questions/generate",
        headers={**headers, "Content-Type": "application/json"},
        json=question_data
    )
    
    if question_response.status_code != 200:
        print(f"❌ 问题生成失败: {question_response.status_code}")
        print(question_response.text)
        return
    
    print("✅ 问题生成成功")
    
    # 5. 获取问题
    print("📋 获取问题列表...")
    questions_response = requests.get(f"{base_url}/api/v1/questions/session/{session_id}", headers=headers)
    
    if questions_response.status_code != 200:
        print(f"❌ 获取问题失败: {questions_response.status_code}")
        print(questions_response.text)
        return
    
    questions_data = questions_response.json()
    questions = questions_data.get('data', {}).get('questions', [])
    
    if not questions:
        print("❌ 没有找到问题")
        return
    
    question = questions[0]  # 使用第一个问题
    question_id = question['id']
    print(f"✅ 找到问题: {question_id}")
    
    # 6. 提交答案
    print("📝 提交答案...")
    answer_data = {
        "question_id": question_id,
        "answer_text": "这是一个测试答案，用于验证answer提交功能是否正常工作。我是一名前端开发工程师，有2年的React开发经验。",
        "response_time": 30
    }
    
    answer_response = requests.post(
        f"{base_url}/api/v1/interviews/{session_id}/answer",
        headers={**headers, "Content-Type": "application/json"},
        json=answer_data
    )
    
    print(f"📊 答案提交响应状态: {answer_response.status_code}")
    print(f"📄 响应内容: {answer_response.text}")
    
    if answer_response.status_code == 200:
        print("✅ 答案提交成功！")
        result_data = answer_response.json()
        print(f"📋 提交结果: {json.dumps(result_data, indent=2, ensure_ascii=False)}")
    else:
        print("❌ 答案提交失败！")
        try:
            error_data = answer_response.json()
            print(f"🔍 错误详情: {json.dumps(error_data, indent=2, ensure_ascii=False)}")
        except:
            print(f"🔍 错误详情: {answer_response.text}")

if __name__ == '__main__':
    test_file_upload_flow()
