#!/usr/bin/env python3
"""
简单的JWT测试脚本
"""

import requests
import json

def test_jwt_errors():
    """测试JWT错误处理"""
    
    base_url = "http://localhost:5001"
    
    print("🔍 测试JWT错误处理...")
    
    # 1. 测试无token访问
    print("\n1. 测试无token访问")
    try:
        response = requests.get(f"{base_url}/api/v1/resumes?page=1&per_page=50")
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.text}")
    except Exception as e:
        print(f"请求失败: {e}")
    
    # 2. 测试无效token访问
    print("\n2. 测试无效token访问")
    try:
        headers = {"Authorization": "Bearer invalid_token"}
        response = requests.get(f"{base_url}/api/v1/resumes?page=1&per_page=50", headers=headers)
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.text}")
    except Exception as e:
        print(f"请求失败: {e}")
    
    # 3. 测试格式错误的token
    print("\n3. 测试格式错误的token")
    try:
        headers = {"Authorization": "Bearer not.a.valid.token"}
        response = requests.get(f"{base_url}/api/v1/resumes?page=1&per_page=50", headers=headers)
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.text}")
    except Exception as e:
        print(f"请求失败: {e}")

if __name__ == "__main__":
    print("🚀 开始JWT错误处理测试...")
    test_jwt_errors()
    print("\n✅ JWT错误处理测试完成！") 