#!/usr/bin/env python3
"""
测试answer提交功能
"""

import requests
import json

def test_answer_submit():
    """测试answer提交"""
    base_url = "http://localhost:5001"
    
    # 1. 创建测试用户并登录
    print("🔐 创建测试用户...")
    login_response = requests.post(f"{base_url}/api/v1/dev/login", json={
        "email": "test@example.com",
        "password": "123456"
    })
    
    if login_response.status_code != 200:
        print(f"❌ 登录失败: {login_response.status_code}")
        print(login_response.text)
        return
    
    login_data = login_response.json()
    token = login_data['data']['access_token']
    user_id = login_data['data']['user']['id']
    
    print(f"✅ 登录成功，用户ID: {user_id}")
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # 2. 获取用户的面试会话
    print("📋 获取面试会话...")
    sessions_response = requests.get(f"{base_url}/api/v1/interviews", headers=headers)
    
    if sessions_response.status_code != 200:
        print(f"❌ 获取会话失败: {sessions_response.status_code}")
        print(sessions_response.text)
        return
    
    sessions_data = sessions_response.json()
    sessions = sessions_data.get('data', {}).get('sessions', [])
    
    if not sessions:
        print("❌ 没有找到面试会话")
        return
    
    session = sessions[0]  # 使用第一个会话
    session_id = session['session_id']
    print(f"✅ 找到会话: {session_id}")
    
    # 3. 获取会话的问题
    print("❓ 获取会话问题...")
    questions_response = requests.get(f"{base_url}/api/v1/questions/session/{session_id}", headers=headers)
    
    if questions_response.status_code != 200:
        print(f"❌ 获取问题失败: {questions_response.status_code}")
        print(questions_response.text)
        return
    
    questions_data = questions_response.json()
    questions = questions_data.get('data', {}).get('questions', [])
    
    if not questions:
        print("❌ 没有找到问题")
        return
    
    question = questions[0]  # 使用第一个问题
    question_id = question['id']
    print(f"✅ 找到问题: {question_id}")
    
    # 4. 提交答案
    print("📝 提交答案...")
    answer_data = {
        "question_id": question_id,
        "answer_text": "这是一个测试答案，用于验证answer提交功能是否正常工作。",
        "response_time": 30
    }
    
    answer_response = requests.post(
        f"{base_url}/api/v1/interviews/{session_id}/answer",
        headers=headers,
        json=answer_data
    )
    
    print(f"📊 答案提交响应状态: {answer_response.status_code}")
    print(f"📄 响应内容: {answer_response.text}")
    
    if answer_response.status_code == 200:
        print("✅ 答案提交成功！")
    else:
        print("❌ 答案提交失败！")
        try:
            error_data = answer_response.json()
            print(f"🔍 错误详情: {json.dumps(error_data, indent=2, ensure_ascii=False)}")
        except:
            print(f"🔍 错误详情: {answer_response.text}")

if __name__ == '__main__':
    test_answer_submit()
