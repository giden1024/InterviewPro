#!/usr/bin/env python3
"""
WebSocket连接测试脚本
"""
import socketio
import time

# 创建Socket.IO客户端
sio = socketio.Client()

@sio.event
def connect():
    print("✅ WebSocket连接成功!")
    print("🔄 发送测试消息...")
    sio.emit('test_message', {
        'message': 'Hello from test client',
        'timestamp': time.time()
    })

@sio.event
def connected(data):
    print(f"📝 服务器响应: {data}")

@sio.event
def test_response(data):
    print(f"🎯 测试响应: {data}")
    sio.disconnect()

@sio.event
def error(data):
    print(f"❌ 错误: {data}")

@sio.event
def disconnect():
    print("🔌 WebSocket连接已断开")

def test_websocket():
    try:
        print("🚀 开始WebSocket连接测试...")
        sio.connect('http://localhost:5000')
        
        # 等待响应
        time.sleep(2)
        
    except Exception as e:
        print(f"❌ 连接失败: {e}")
    finally:
        if sio.connected:
            sio.disconnect()

if __name__ == '__main__':
    test_websocket() 