"""
面试结果分析系统测试
测试面试分析器、报告生成器和API端点的完整功能
"""

import requests
import json
import time
from datetime import datetime
import random

# 配置
BASE_URL = "http://localhost:5000/api/v1"
TEST_USER = {
    "email": "analysis_test@example.com",
    "password": "TestPass123!",
    "username": "analysis_tester"
}

class InterviewAnalysisSystemTest:
    def __init__(self):
        self.base_url = BASE_URL
        self.session = requests.Session()
        self.token = None
        self.user_id = None
        self.test_session_id = None
        
    def setup_test_environment(self):
        """设置测试环境"""
        print("🔧 设置测试环境...")
        
        # 注册测试用户
        register_response = self.session.post(
            f"{self.base_url}/auth/register",
            json=TEST_USER
        )
        
        if register_response.status_code not in [201, 409]:  # 201 创建成功，409 用户已存在
            print(f"❌ 用户注册失败: {register_response.text}")
            return False
        
        # 登录获取token
        login_response = self.session.post(
            f"{self.base_url}/auth/login",
            json={
                "email": TEST_USER["email"],
                "password": TEST_USER["password"]
            }
        )
        
        if login_response.status_code != 200:
            print(f"❌ 登录失败: {login_response.text}")
            return False
        
        login_data = login_response.json()
        self.token = login_data["data"]["access_token"]
        self.user_id = login_data["data"]["user"]["id"]
        
        # 设置认证头
        self.session.headers.update({
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        })
        
        print(f"✅ 测试环境设置完成 - 用户ID: {self.user_id}")
        return True
    
    def create_test_interview_session(self):
        """创建测试面试会话"""
        print("\n📝 创建测试面试会话...")
        
        # 创建面试会话
        session_data = {
            "interview_type": "technical",
            "title": "Python开发工程师面试测试",
            "description": "技术能力评估面试",
            "total_questions": 5
        }
        
        response = self.session.post(
            f"{self.base_url}/interviews/sessions",
            json=session_data
        )
        
        if response.status_code != 201:
            print(f"❌ 面试会话创建失败: {response.text}")
            return False
        
        session_result = response.json()
        self.test_session_id = session_result["data"]["session_id"]
        
        # 生成问题
        generate_response = self.session.post(
            f"{self.base_url}/questions/generate",
            json={
                "session_id": self.test_session_id,
                "count": 5,
                "difficulty": "medium",
                "question_types": ["technical", "behavioral"]
            }
        )
        
        if generate_response.status_code != 201:
            print(f"❌ 问题生成失败: {generate_response.text}")
            return False
        
        print(f"✅ 测试面试会话创建成功 - 会话ID: {self.test_session_id}")
        return True
    
    def simulate_interview_answers(self):
        """模拟面试回答"""
        print("\n💬 模拟面试回答...")
        
        # 获取生成的问题
        questions_response = self.session.get(
            f"{self.base_url}/questions/session/{self.test_session_id}"
        )
        
        if questions_response.status_code != 200:
            print(f"❌ 获取问题失败: {questions_response.text}")
            return False
        
        questions = questions_response.json()["data"]
        
        # 模拟回答
        sample_answers = [
            """在设计一个高并发系统时，我会考虑以下几个关键方面：
            首先是架构设计，采用微服务架构来提高系统的可扩展性和可维护性。
            其次是数据库优化，包括读写分离、分库分表和缓存策略。
            第三是负载均衡，使用Nginx或HAProxy来分发请求。
            最后是监控和日志系统，确保能够及时发现和解决问题。
            具体实现上，我会使用Redis作为缓存层，MySQL作为主数据库，
            并配置主从复制来提高读取性能。""",
            
            """在我之前的项目中，我遇到了一个系统性能瓶颈的挑战。
            当时用户量激增，导致响应时间变慢。我首先通过APM工具定位了问题，
            发现主要是数据库查询导致的。然后我采取了几个措施：
            1. 优化SQL查询，添加必要的索引
            2. 引入Redis缓存热点数据
            3. 使用连接池优化数据库连接
            4. 实施异步处理减少阻塞
            结果系统响应时间从2秒降低到200ms，用户满意度大幅提升。""",
            
            """Python中的装饰器是一个强大的特性，它可以在不修改原函数代码的情况下
            增加额外的功能。装饰器本质上是一个接受函数作为参数并返回函数的函数。
            常见用途包括：日志记录、性能监控、权限检查、缓存等。
            例如，我经常使用@lru_cache来缓存函数结果，使用@retry来实现重试机制。
            在实际项目中，我还会自定义装饰器来处理API认证和参数验证。""",
            
            """团队协作中，我认为沟通是最重要的。我会主动参与团队会议，
            分享自己的想法和进展。当遇到分歧时，我会倾听不同的观点，
            寻求最佳的解决方案。我还会帮助新团队成员快速融入，
            分享经验和最佳实践。在代码审查中，我会给出建设性的反馈，
            同时虚心接受他人的建议。我相信良好的团队合作能够
            创造1+1>2的效果。""",
            
            """我的职业规划是成为一名技术专家和团队领导者。
            短期内，我希望深入掌握云原生技术和大数据处理。
            中期目标是能够设计和实施大型系统架构，
            同时培养团队管理和项目管理能力。
            长期来看，我希望能够在技术创新方面有所贡献，
            可能参与开源项目或技术标准制定。
            我会持续学习新技术，保持技术敏感度，
            同时也注重软技能的提升。"""
        ]
        
        for i, question in enumerate(questions[:5]):  # 限制为5个问题
            answer_text = sample_answers[i % len(sample_answers)]
            response_time = random.randint(60, 300)  # 1-5分钟随机响应时间
            
            answer_data = {
                "session_id": self.test_session_id,
                "question_id": question["id"],
                "answer_text": answer_text,
                "response_time": response_time
            }
            
            answer_response = self.session.post(
                f"{self.base_url}/questions/answers",
                json=answer_data
            )
            
            if answer_response.status_code != 201:
                print(f"❌ 提交答案失败: {answer_response.text}")
                return False
            
            print(f"✅ 提交第{i+1}个答案成功")
            time.sleep(0.5)  # 短暂延迟模拟真实场景
        
        # 完成面试
        complete_response = self.session.patch(
            f"{self.base_url}/interviews/sessions/{self.test_session_id}",
            json={"action": "complete"}
        )
        
        if complete_response.status_code != 200:
            print(f"❌ 完成面试失败: {complete_response.text}")
            return False
        
        print("✅ 面试会话完成")
        return True
    
    def test_session_analysis(self):
        """测试会话分析功能"""
        print("\n📊 测试会话分析功能...")
        
        response = self.session.get(
            f"{self.base_url}/analysis/session/{self.test_session_id}"
        )
        
        if response.status_code != 200:
            print(f"❌ 会话分析失败: {response.text}")
            return False
        
        analysis_data = response.json()["data"]
        
        # 验证分析结果结构
        required_fields = [
            "session_info", "overall_score", "section_scores", 
            "answer_analysis", "performance_metrics", "strengths", 
            "weaknesses", "recommendations", "detailed_feedback", 
            "visualization_data"
        ]
        
        for field in required_fields:
            if field not in analysis_data:
                print(f"❌ 分析结果缺少字段: {field}")
                return False
        
        print(f"✅ 会话分析成功 - 总分: {analysis_data['overall_score']:.1f}")
        print(f"   优势: {', '.join(analysis_data['strengths'][:2])}")
        print(f"   建议: {', '.join(analysis_data['recommendations'][:2])}")
        
        return True
    
    def test_report_generation(self):
        """测试报告生成功能"""
        print("\n📄 测试报告生成功能...")
        
        response = self.session.get(
            f"{self.base_url}/analysis/report/{self.test_session_id}"
        )
        
        if response.status_code != 200:
            print(f"❌ 报告生成失败: {response.text}")
            return False
        
        report_data = response.json()["data"]
        
        # 验证报告结构
        required_sections = [
            "report_id", "generated_at", "session_summary",
            "performance_overview", "section_performance", 
            "key_findings", "detailed_analysis", "next_steps"
        ]
        
        for section in required_sections:
            if section not in report_data:
                print(f"❌ 报告缺少部分: {section}")
                return False
        
        print(f"✅ 报告生成成功 - 报告ID: {report_data['report_id']}")
        print(f"   总分: {report_data['performance_overview']['overall_score']}")
        print(f"   等级: {report_data['performance_overview']['grade']}")
        
        return True
    
    def test_visualization_data(self):
        """测试可视化数据功能"""
        print("\n📈 测试可视化数据功能...")
        
        response = self.session.get(
            f"{self.base_url}/analysis/visualization/{self.test_session_id}"
        )
        
        if response.status_code != 200:
            print(f"❌ 可视化数据获取失败: {response.text}")
            return False
        
        viz_data = response.json()["data"]
        
        # 验证可视化数据结构
        required_charts = [
            "score_radar", "response_time_chart", 
            "completion_progress", "score_distribution"
        ]
        
        for chart in required_charts:
            if chart not in viz_data:
                print(f"❌ 可视化数据缺少图表: {chart}")
                return False
        
        print("✅ 可视化数据获取成功")
        print(f"   雷达图类别: {len(viz_data['score_radar'].get('categories', []))}")
        print(f"   完成进度: {viz_data['completion_progress'].get('percentage', 0):.1f}%")
        
        return True
    
    def test_statistics(self):
        """测试统计数据功能"""
        print("\n📊 测试统计数据功能...")
        
        response = self.session.get(
            f"{self.base_url}/analysis/statistics"
        )
        
        if response.status_code != 200:
            print(f"❌ 统计数据获取失败: {response.text}")
            return False
        
        stats_data = response.json()["data"]
        
        # 验证统计数据结构
        required_fields = [
            "total_interviews", "average_score", "improvement_trend",
            "performance_by_type", "score_distribution"
        ]
        
        for field in required_fields:
            if field not in stats_data:
                print(f"❌ 统计数据缺少字段: {field}")
                return False
        
        print(f"✅ 统计数据获取成功")
        print(f"   总面试次数: {stats_data['total_interviews']}")
        print(f"   平均分: {stats_data['average_score']}")
        
        return True
    
    def test_detailed_insights(self):
        """测试详细洞察功能"""
        print("\n🔍 测试详细洞察功能...")
        
        response = self.session.get(
            f"{self.base_url}/analysis/insights/{self.test_session_id}"
        )
        
        if response.status_code != 200:
            print(f"❌ 详细洞察获取失败: {response.text}")
            return False
        
        insights_data = response.json()["data"]
        
        # 验证洞察数据结构
        required_fields = [
            "performance_insights", "behavioral_patterns",
            "technical_assessment", "time_management",
            "communication_effectiveness", "growth_opportunities"
        ]
        
        for field in required_fields:
            if field not in insights_data:
                print(f"❌ 洞察数据缺少字段: {field}")
                return False
        
        print("✅ 详细洞察获取成功")
        print(f"   表现洞察: {len(insights_data['performance_insights'])}")
        print(f"   行为模式: {len(insights_data['behavioral_patterns'])}")
        
        return True
    
    def test_export_functionality(self):
        """测试导出功能"""
        print("\n💾 测试导出功能...")
        
        # 测试JSON导出
        response = self.session.get(
            f"{self.base_url}/analysis/export/{self.test_session_id}?format=json"
        )
        
        if response.status_code != 200:
            print(f"❌ JSON导出失败: {response.text}")
            return False
        
        export_data = response.json()["data"]
        
        # 验证导出数据结构
        required_fields = ["metadata", "summary", "detailed_results"]
        
        for field in required_fields:
            if field not in export_data:
                print(f"❌ 导出数据缺少字段: {field}")
                return False
        
        print("✅ JSON导出成功")
        
        # 测试CSV导出
        csv_response = self.session.get(
            f"{self.base_url}/analysis/export/{self.test_session_id}?format=csv"
        )
        
        if csv_response.status_code != 200:
            print(f"❌ CSV导出失败: {csv_response.text}")
            return False
        
        csv_data = csv_response.json()["data"]
        
        if "csv_data" not in csv_data:
            print("❌ CSV数据缺少csv_data字段")
            return False
        
        print("✅ CSV导出成功")
        return True
    
    def run_core_tests(self):
        """运行核心测试（不包括比较功能）"""
        print("🚀 开始面试结果分析系统核心测试")
        print("=" * 50)
        
        tests = [
            ("设置测试环境", self.setup_test_environment),
            ("创建测试面试会话", self.create_test_interview_session),
            ("模拟面试回答", self.simulate_interview_answers),
            ("测试会话分析", self.test_session_analysis),
            ("测试报告生成", self.test_report_generation),
            ("测试可视化数据", self.test_visualization_data),
            ("测试统计数据", self.test_statistics),
            ("测试详细洞察", self.test_detailed_insights),
            ("测试导出功能", self.test_export_functionality)
        ]
        
        passed = 0
        failed = 0
        
        for test_name, test_func in tests:
            try:
                if test_func():
                    passed += 1
                else:
                    failed += 1
                    print(f"❌ {test_name} 失败")
            except Exception as e:
                failed += 1
                print(f"❌ {test_name} 异常: {str(e)}")
        
        print("\n" + "=" * 50)
        print(f"📊 测试结果汇总:")
        print(f"   ✅ 通过: {passed}")
        print(f"   ❌ 失败: {failed}")
        print(f"   📈 成功率: {(passed/(passed+failed)*100):.1f}%")
        
        if failed == 0:
            print("\n🎉 所有核心测试通过！面试结果分析系统功能完整！")
        else:
            print("\n⚠️  部分测试失败，请检查相关功能")
        
        return failed == 0

def main():
    """主函数"""
    tester = InterviewAnalysisSystemTest()
    success = tester.run_core_tests()
    
    if success:
        print("\n✨ 面试结果分析系统测试完成 - 系统运行正常")
    else:
        print("\n🔧 面试结果分析系统需要进一步调试")

if __name__ == "__main__":
    main() 