#!/usr/bin/env python3
"""
测试最小化认证API
"""
import requests
import json
import time

BASE_URL = "http://localhost:5001"

def test_minimal_auth():
    """测试最小化认证API"""
    print("🧪 测试最小化认证API")
    print("=" * 50)
    
    # 等待服务启动
    print("等待服务启动...")
    time.sleep(2)
    
    # 测试健康检查
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=5)
        if response.status_code == 200:
            print("✅ 服务健康检查通过")
        else:
            print("❌ 服务健康检查失败")
            return
    except Exception as e:
        print(f"❌ 无法连接到服务: {e}")
        return
    
    # 测试注册
    print("\n📝 测试用户注册:")
    register_data = {
        "email": "minimal_test@example.com",
        "password": "password123",
        "username": "Minimal Test User"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/test-register", json=register_data, timeout=10)
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.text}")
        
        if response.status_code == 201:
            print("✅ 注册成功!")
            
            # 测试登录
            print("\n🔐 测试用户登录:")
            login_data = {
                "email": "minimal_test@example.com",
                "password": "password123"
            }
            
            login_response = requests.post(f"{BASE_URL}/test-login", json=login_data, timeout=10)
            print(f"状态码: {login_response.status_code}")
            print(f"响应: {login_response.text}")
            
            if login_response.status_code == 200:
                print("✅ 登录成功!")
            else:
                print("❌ 登录失败")
        else:
            print("❌ 注册失败")
            
    except Exception as e:
        print(f"❌ 请求异常: {e}")

if __name__ == '__main__':
    test_minimal_auth() 