第一优先级（1-2周内）：
修复认证API的小问题
实现简历上传和解析功能
集成DeepSeek AI问题生成
第二优先级（2-4周内）：
完善面试会话管理
实现语音转文本功能
开始前端界面开发



后端功能完成之后，开始在 cursor 中添加mcp。
并且使用 browsertools 以及 gomaster

确认如何安装browser tools
https://zhuanlan.zhihu.com/p/1901976336110708019

