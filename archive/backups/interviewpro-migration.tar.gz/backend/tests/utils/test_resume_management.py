#!/usr/bin/env python3
"""
简历管理模块完整测试脚本
测试所有简历管理功能：上传、预览、分析、搜索、批量操作、导出等
"""

import requests
import json
import time
import os
from datetime import datetime

class ResumeManagementTester:
    def __init__(self):
        self.base_url = "http://localhost:5000"
        self.session = requests.Session()
        self.access_token = None
        self.user_id = None
        self.test_resume_id = None
        
    def log(self, message, level="INFO"):
        """日志输出"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] {level}: {message}")
        
    def login(self):
        """登录测试用户"""
        try:
            login_data = {
                "email": "test_ai_questions@example.com",
                "password": "testpass123"
            }
            
            response = self.session.post(
                f"{self.base_url}/api/v1/auth/login",
                json=login_data
            )
            
            if response.status_code == 200:
                data = response.json()
                self.access_token = data['data']['access_token']
                self.user_id = data['data']['user']['id']
                self.session.headers.update({
                    "Authorization": f"Bearer {self.access_token}"
                })
                self.log("✅ 登录成功")
                return True
            else:
                self.log(f"❌ 登录失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ 登录错误: {e}", "ERROR")
            return False
    
    def test_resume_list(self):
        """测试简历列表获取"""
        try:
            self.log("🔍 测试简历列表获取...")
            
            response = self.session.get(f"{self.base_url}/api/v1/resumes")
            
            if response.status_code == 200:
                data = response.json()
                resumes = data['data']['resumes']
                pagination = data['data']['pagination']
                
                self.log(f"✅ 获取到 {len(resumes)} 个简历")
                self.log(f"   分页信息: 第{pagination['page']}页，共{pagination['total']}个")
                
                if resumes:
                    self.test_resume_id = resumes[0]['id']
                    self.log(f"   使用简历ID {self.test_resume_id} 进行后续测试")
                
                return True
            else:
                self.log(f"❌ 获取简历列表失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ 简历列表测试错误: {e}", "ERROR")
            return False
    
    def test_resume_details(self):
        """测试获取简历详情"""
        if not self.test_resume_id:
            self.log("⚠️  跳过简历详情测试，无可用简历ID", "WARN")
            return True
            
        try:
            self.log("📄 测试简历详情获取...")
            
            response = self.session.get(f"{self.base_url}/api/v1/resumes/{self.test_resume_id}")
            
            if response.status_code == 200:
                data = response.json()
                resume = data['data']['resume']
                
                self.log("✅ 简历详情获取成功")
                self.log(f"   简历名称: {resume['filename']}")
                self.log(f"   处理状态: {resume['status']}")
                self.log(f"   技能数量: {len(resume['skills'])}")
                self.log(f"   工作经历: {len(resume['experience'])}")
                
                return True
            else:
                self.log(f"❌ 获取简历详情失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ 简历详情测试错误: {e}", "ERROR")
            return False
    
    def test_resume_preview(self):
        """测试简历预览功能"""
        if not self.test_resume_id:
            self.log("⚠️  跳过简历预览测试，无可用简历ID", "WARN")
            return True
            
        try:
            self.log("👀 测试简历预览功能...")
            
            response = self.session.get(f"{self.base_url}/api/v1/resumes/{self.test_resume_id}/preview")
            
            if response.status_code == 200:
                data = response.json()
                preview = data['data']['preview']
                
                self.log("✅ 简历预览成功")
                self.log(f"   基本信息: {preview['basic_info']}")
                self.log(f"   技能: {len(preview['skills'])} 项")
                self.log(f"   工作经历: {len(preview['experience'])} 项")
                self.log(f"   教育背景: {len(preview['education'])} 项")
                
                return True
            elif response.status_code == 400:
                self.log("⚠️  简历尚未处理完成，无法预览", "WARN")
                return True
            else:
                self.log(f"❌ 简历预览失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ 简历预览测试错误: {e}", "ERROR")
            return False
    
    def test_resume_analysis(self):
        """测试智能简历分析"""
        if not self.test_resume_id:
            self.log("⚠️  跳过简历分析测试，无可用简历ID", "WARN")
            return True
            
        try:
            self.log("🧠 测试智能简历分析...")
            
            response = self.session.post(f"{self.base_url}/api/v1/resumes/{self.test_resume_id}/analyze")
            
            if response.status_code == 200:
                data = response.json()
                analysis = data['data']['analysis']
                
                self.log("✅ 简历分析成功")
                self.log(f"   总体评分: {analysis['overall_score']}/100")
                self.log(f"   优势: {', '.join(analysis['strengths'][:3])}")
                self.log(f"   改进建议: {len(analysis['suggestions'])} 条")
                
                # 显示详细分析
                sections = analysis['sections']
                for section, data in sections.items():
                    percentage = data.get('percentage', 0)
                    self.log(f"   {section}: {percentage}%")
                
                return True
            elif response.status_code == 400:
                self.log("⚠️  简历尚未处理完成，无法分析", "WARN")
                return True
            else:
                self.log(f"❌ 简历分析失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ 简历分析测试错误: {e}", "ERROR")
            return False
    
    def test_resume_search(self):
        """测试高级搜索功能"""
        try:
            self.log("🔍 测试高级搜索功能...")
            
            search_data = {
                "status": "processed",
                "skills": ["Python", "JavaScript"],
                "page": 1,
                "per_page": 10
            }
            
            response = self.session.post(f"{self.base_url}/api/v1/resumes/search", json=search_data)
            
            if response.status_code == 200:
                data = response.json()
                resumes = data['data']['resumes']
                pagination = data['data']['pagination']
                
                self.log("✅ 高级搜索成功")
                self.log(f"   搜索到 {len(resumes)} 个匹配简历")
                self.log(f"   总计: {pagination['total']} 个结果")
                
                return True
            else:
                self.log(f"❌ 高级搜索失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ 高级搜索测试错误: {e}", "ERROR")
            return False
    
    def test_resume_stats(self):
        """测试简历统计功能"""
        try:
            self.log("📊 测试简历统计功能...")
            
            response = self.session.get(f"{self.base_url}/api/v1/resumes/stats")
            
            if response.status_code == 200:
                data = response.json()
                stats = data['data']['stats']
                recent = data['data']['recent_resumes']
                
                self.log("✅ 简历统计获取成功")
                self.log(f"   总计: {stats['total']} 个简历")
                self.log(f"   已处理: {stats['processed']} 个")
                self.log(f"   处理中: {stats['processing']} 个")
                self.log(f"   失败: {stats['failed']} 个")
                self.log(f"   最近上传: {len(recent)} 个")
                
                return True
            else:
                self.log(f"❌ 简历统计失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ 简历统计测试错误: {e}", "ERROR")
            return False
    
    def test_batch_operations(self):
        """测试批量操作"""
        if not self.test_resume_id:
            self.log("⚠️  跳过批量操作测试，无可用简历ID", "WARN")
            return True
            
        try:
            self.log("🔧 测试批量重新解析...")
            
            batch_data = {
                "resume_ids": [self.test_resume_id],
                "operation": "reparse"
            }
            
            response = self.session.post(f"{self.base_url}/api/v1/resumes/batch", json=batch_data)
            
            if response.status_code == 200:
                data = response.json()
                results = data['data']['results']
                summary = data['data']['summary']
                
                self.log("✅ 批量操作成功")
                self.log(f"   操作类型: {data['data']['operation']}")
                self.log(f"   总数: {summary['total']}")
                self.log(f"   成功: {summary['success']}")
                self.log(f"   失败: {summary['failed']}")
                
                return True
            else:
                self.log(f"❌ 批量操作失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ 批量操作测试错误: {e}", "ERROR")
            return False
    
    def test_export_json(self):
        """测试JSON导出"""
        try:
            self.log("📁 测试JSON导出...")
            
            export_data = {
                "format": "json"
            }
            
            response = self.session.post(f"{self.base_url}/api/v1/resumes/export", json=export_data)
            
            if response.status_code == 200:
                data = response.json()
                
                self.log("✅ JSON导出成功")
                self.log(f"   导出时间: {data['export_date']}")
                self.log(f"   简历数量: {data['total_resumes']}")
                
                return True
            else:
                self.log(f"❌ JSON导出失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ JSON导出测试错误: {e}", "ERROR")
            return False
    
    def test_export_csv(self):
        """测试CSV导出"""
        try:
            self.log("📄 测试CSV导出...")
            
            export_data = {
                "format": "csv"
            }
            
            response = self.session.post(f"{self.base_url}/api/v1/resumes/export", json=export_data)
            
            if response.status_code == 200:
                csv_content = response.text
                lines = csv_content.split('\n')
                
                self.log("✅ CSV导出成功")
                self.log(f"   CSV行数: {len(lines)}")
                self.log(f"   包含头部: {'ID' in lines[0] if lines else False}")
                
                return True
            else:
                self.log(f"❌ CSV导出失败: {response.text}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"❌ CSV导出测试错误: {e}", "ERROR")
            return False
    
    def run_all_tests(self):
        """运行所有测试"""
        self.log("🚀 开始简历管理模块完整测试")
        self.log("=" * 60)
        
        tests = [
            ("用户登录", self.login),
            ("简历列表", self.test_resume_list),
            ("简历详情", self.test_resume_details),
            ("简历预览", self.test_resume_preview),
            ("智能分析", self.test_resume_analysis),
            ("高级搜索", self.test_resume_search),
            ("统计信息", self.test_resume_stats),
            ("批量操作", self.test_batch_operations),
            ("JSON导出", self.test_export_json),
            ("CSV导出", self.test_export_csv)
        ]
        
        results = []
        for test_name, test_func in tests:
            self.log(f"\n🧪 运行测试: {test_name}")
            self.log("-" * 40)
            
            start_time = time.time()
            try:
                success = test_func()
                results.append((test_name, success, time.time() - start_time))
            except Exception as e:
                self.log(f"❌ 测试异常: {e}", "ERROR")
                results.append((test_name, False, time.time() - start_time))
        
        # 测试结果汇总
        self.log("\n" + "=" * 60)
        self.log("📊 测试结果汇总")
        self.log("=" * 60)
        
        passed = 0
        failed = 0
        
        for test_name, success, duration in results:
            status = "✅ 通过" if success else "❌ 失败"
            self.log(f"{test_name:<15} {status} ({duration:.2f}s)")
            
            if success:
                passed += 1
            else:
                failed += 1
        
        self.log("-" * 60)
        self.log(f"总计: {len(results)} 个测试")
        self.log(f"通过: {passed} 个")
        self.log(f"失败: {failed} 个")
        self.log(f"成功率: {(passed / len(results) * 100):.1f}%")
        
        if failed == 0:
            self.log("\n🎉 所有测试通过！简历管理模块功能完整！")
        else:
            self.log(f"\n⚠️  有 {failed} 个测试失败，请检查相关功能")
        
        return failed == 0

def main():
    """主函数"""
    print("🤖 InterviewGenius AI - Resume Management Module Test")
    print("🔧 Testing complete resume management functionality...")
    print()
    
    tester = ResumeManagementTester()
    success = tester.run_all_tests()
    
    if success:
        print("\n🎊 简历管理模块测试成功完成！")
        exit(0)
    else:
        print("\n❌ 部分测试失败，需要检查功能实现")
        exit(1)

if __name__ == "__main__":
    main() 