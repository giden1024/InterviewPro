#!/usr/bin/env python3
"""
测试PDF文件解析功能
"""
import os
import sys

# 添加backend目录到路径
sys.path.insert(0, 'backend')

from backend.app.services.resume_parser import ResumeParser

def test_pdf_parsing():
    """测试PDF解析功能"""
    pdf_path = 'backend/testfiles/app_cv.pdf'
    
    print('🔍 PDF 解析测试')
    print('=' * 50)
    
    if not os.path.exists(pdf_path):
        print(f'❌ PDF文件不存在: {pdf_path}')
        return
    
    file_size = os.path.getsize(pdf_path)
    print(f'📁 文件: {pdf_path}')
    print(f'📏 大小: {file_size} bytes ({file_size/1024:.1f} KB)')
    
    # 创建解析器
    parser = ResumeParser()
    
    print('\n🚀 开始解析...')
    result = parser.parse_resume(pdf_path, 'pdf')
    
    if result['success']:
        print('✅ 解析成功!')
        
        raw_text = result['raw_text']
        parsed_data = result['parsed_data']
        
        print(f'\n📄 原始文本信息:')
        print(f'  总长度: {len(raw_text)} 字符')
        lines = raw_text.split('\n')
        print(f'  行数: {len(lines)} 行')
        
        print(f'\n📋 提取的结构化信息:')
        print(f'  姓名: {parsed_data.get("name", "未识别")}')
        print(f'  邮箱: {parsed_data.get("email", "未识别")}')
        print(f'  电话: {parsed_data.get("phone", "未识别")}')
        
        skills = parsed_data.get('skills', [])
        if skills:
            print(f'  技能 ({len(skills)}个): {", ".join(skills[:10])}')
            if len(skills) > 10:
                print(f'    ... 及其他 {len(skills) - 10} 项技能')
        else:
            print('  技能: 未识别')
        
        experience = parsed_data.get('experience', [])
        if experience:
            print(f'  工作经历 ({len(experience)}条):')
            for i, exp in enumerate(experience[:3]):
                print(f'    {i+1}. 公司: {exp.get("company", "未识别")}')
                print(f'       职位: {exp.get("position", "未识别")}')
                print(f'       时间: {exp.get("duration", "未识别")}')
        else:
            print('  工作经历: 未识别')
        
        education = parsed_data.get('education', [])
        if education:
            print(f'  教育背景 ({len(education)}条):')
            for i, edu in enumerate(education[:3]):
                print(f'    {i+1}. 学校: {edu.get("school", "未识别")}')
                print(f'       学位: {edu.get("degree", "未识别")}')
        else:
            print('  教育背景: 未识别')
        
        # 显示文本预览
        print(f'\n📄 文档内容预览 (前10行):')
        for i, line in enumerate(lines[:10]):
            if line.strip():
                print(f'  {i+1:2d}. {line.strip()[:80]}')
        
        print(f'\n🎯 解析效果评估:')
        score = 0
        total = 5
        
        if parsed_data.get('name'): score += 1
        if parsed_data.get('email'): score += 1  
        if parsed_data.get('phone'): score += 1
        if skills: score += 1
        if experience or education: score += 1
        
        print(f'  信息提取完整度: {score}/{total} ({score/total*100:.1f}%)')
        
        if score >= 3:
            print('  ✅ 解析效果良好')
        elif score >= 2:
            print('  ⚠️  解析效果一般，可优化')
        else:
            print('  ❌ 解析效果较差，需要改进')
            
    else:
        print(f'❌ 解析失败: {result["error"]}')

if __name__ == '__main__':
    test_pdf_parsing() 