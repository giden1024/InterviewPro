#!/usr/bin/env python3
"""
PDF 简历上传和解析测试脚本
"""
import requests
import json
import time
import os

# 配置
BASE_URL = "http://localhost:5000"
API_BASE = f"{BASE_URL}/api/v1"
PDF_FILE_PATH = "backend/testfiles/app_cv.pdf"

def print_status(status, message):
    """打印状态信息"""
    status_icon = "✅" if status else "❌"
    print(f"{status_icon} {message}")
    return status

def register_and_login():
    """注册用户并登录获取token"""
    print("👤 注册测试用户并登录:")
    
    # 使用时间戳创建唯一用户
    test_email = f"pdf_test_{int(time.time())}@example.com"
    user_data = {
        "email": test_email,
        "password": "password123",
        "username": "PDF Test User"
    }
    
    # 注册用户
    try:
        response = requests.post(f"{API_BASE}/auth/register", json=user_data, timeout=10)
        if response.status_code == 201:
            print_status(True, f"用户注册成功: {test_email}")
        else:
            print_status(False, f"用户注册失败: {response.text}")
            return None
    except Exception as e:
        print_status(False, f"注册请求失败: {e}")
        return None
    
    # 登录获取token
    login_data = {
        "email": test_email,
        "password": "password123"
    }
    
    try:
        response = requests.post(f"{API_BASE}/auth/login", json=login_data, timeout=10)
        if response.status_code == 200:
            result = response.json()
            token = result.get('data', {}).get('access_token')
            if token:
                print_status(True, "登录成功，获取到token")
                return token
            else:
                print_status(False, "登录成功但未获取到token")
                return None
        else:
            print_status(False, f"登录失败: {response.text}")
            return None
    except Exception as e:
        print_status(False, f"登录请求失败: {e}")
        return None

def upload_pdf_file(token):
    """上传PDF文件"""
    print(f"\n📄 上传PDF文件: {PDF_FILE_PATH}")
    
    if not os.path.exists(PDF_FILE_PATH):
        print_status(False, f"PDF文件不存在: {PDF_FILE_PATH}")
        return None
    
    headers = {'Authorization': f'Bearer {token}'}
    
    try:
        with open(PDF_FILE_PATH, 'rb') as file:
            files = {'file': ('app_cv.pdf', file, 'application/pdf')}
            
            print("正在上传文件...")
            response = requests.post(f"{API_BASE}/resumes", headers=headers, files=files, timeout=30)
            
            if response.status_code == 201:
                result = response.json()
                resume_data = result.get('data', {}).get('resume', {})
                resume_id = resume_data.get('id')
                
                print_status(True, f"文件上传成功! 简历ID: {resume_id}")
                print(f"  文件名: {resume_data.get('filename')}")
                print(f"  文件大小: {resume_data.get('file_size')} bytes")
                print(f"  处理状态: {resume_data.get('status')}")
                
                return resume_id
            else:
                print_status(False, f"文件上传失败: {response.text}")
                return None
                
    except Exception as e:
        print_status(False, f"上传请求失败: {e}")
        return None

def check_parsing_result(token, resume_id):
    """检查解析结果"""
    print(f"\n🔍 检查解析结果 (简历ID: {resume_id}):")
    
    headers = {'Authorization': f'Bearer {token}'}
    
    # 等待解析完成（最多等待30秒）
    max_wait = 30
    wait_interval = 2
    
    for i in range(max_wait // wait_interval):
        try:
            response = requests.get(f"{API_BASE}/resumes/{resume_id}", headers=headers, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                resume = result.get('data', {}).get('resume', {})
                status = resume.get('status')
                
                print(f"第 {i+1} 次检查 - 状态: {status}")
                
                if status == 'processed':
                    print_status(True, "简历解析完成!")
                    
                    # 显示解析结果
                    print("\n📋 解析结果:")
                    print(f"  姓名: {resume.get('name', '未识别')}")
                    print(f"  邮箱: {resume.get('email', '未识别')}")
                    print(f"  电话: {resume.get('phone', '未识别')}")
                    
                    skills = resume.get('skills', [])
                    if skills:
                        print(f"  技能 ({len(skills)}个): {', '.join(skills[:10])}")
                        if len(skills) > 10:
                            print(f"    ... 及其他 {len(skills) - 10} 项技能")
                    else:
                        print("  技能: 未识别")
                    
                    experience = resume.get('experience', [])
                    if experience:
                        print(f"  工作经历 ({len(experience)}条):")
                        for idx, exp in enumerate(experience[:3]):
                            print(f"    {idx+1}. 公司: {exp.get('company', '未识别')}")
                            print(f"       职位: {exp.get('position', '未识别')}")
                            print(f"       时间: {exp.get('duration', '未识别')}")
                    else:
                        print("  工作经历: 未识别")
                    
                    education = resume.get('education', [])
                    if education:
                        print(f"  教育背景 ({len(education)}条):")
                        for idx, edu in enumerate(education[:3]):
                            print(f"    {idx+1}. 学校: {edu.get('school', '未识别')}")
                            print(f"       学位: {edu.get('degree', '未识别')}")
                    else:
                        print("  教育背景: 未识别")
                    
                    return True
                    
                elif status == 'failed':
                    error_msg = resume.get('error_message', '未知错误')
                    print_status(False, f"简历解析失败: {error_msg}")
                    return False
                
                elif status in ['uploaded', 'processing']:
                    if i < (max_wait // wait_interval) - 1:
                        print(f"  等待解析完成... ({wait_interval}秒后重试)")
                        time.sleep(wait_interval)
                    else:
                        print_status(False, "解析超时")
                        return False
                        
            else:
                print_status(False, f"获取简历详情失败: {response.text}")
                return False
                
        except Exception as e:
            print_status(False, f"检查解析结果失败: {e}")
            return False
    
    return False

def test_resume_list(token):
    """测试简历列表功能"""
    print("\n📋 测试简历列表:")
    
    headers = {'Authorization': f'Bearer {token}'}
    
    try:
        response = requests.get(f"{API_BASE}/resumes", headers=headers, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            resumes = result.get('data', {}).get('resumes', [])
            pagination = result.get('data', {}).get('pagination', {})
            
            print_status(True, f"获取简历列表成功")
            print(f"  总数: {pagination.get('total', 0)} 个简历")
            print(f"  当前页: {pagination.get('page', 1)}")
            
            for idx, resume in enumerate(resumes[:3]):
                print(f"  {idx+1}. {resume.get('filename')} - {resume.get('status')}")
                
            return True
        else:
            print_status(False, f"获取简历列表失败: {response.text}")
            return False
            
    except Exception as e:
        print_status(False, f"获取简历列表请求失败: {e}")
        return False

def test_resume_stats(token):
    """测试简历统计功能"""
    print("\n📊 测试简历统计:")
    
    headers = {'Authorization': f'Bearer {token}'}
    
    try:
        response = requests.get(f"{API_BASE}/resumes/stats", headers=headers, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            stats = result.get('data', {}).get('stats', {})
            
            print_status(True, f"获取简历统计成功")
            print(f"  总计: {stats.get('total', 0)}")
            print(f"  已处理: {stats.get('processed', 0)}")
            print(f"  处理中: {stats.get('processing', 0)}")
            print(f"  失败: {stats.get('failed', 0)}")
            
            return True
        else:
            print_status(False, f"获取简历统计失败: {response.text}")
            return False
            
    except Exception as e:
        print_status(False, f"获取简历统计请求失败: {e}")
        return False

def main():
    """主测试函数"""
    print("🚀 PDF 简历上传和解析功能测试")
    print("=" * 60)
    
    # 检查PDF文件
    if not os.path.exists(PDF_FILE_PATH):
        print_status(False, f"测试文件不存在: {PDF_FILE_PATH}")
        return
    
    file_size = os.path.getsize(PDF_FILE_PATH)
    print(f"📁 测试文件: {PDF_FILE_PATH}")
    print(f"📏 文件大小: {file_size} bytes ({file_size/1024:.1f} KB)")
    
    # 1. 注册用户并登录
    token = register_and_login()
    if not token:
        print("❌ 无法获取认证token，终止测试")
        return
    
    # 2. 上传PDF文件
    resume_id = upload_pdf_file(token)
    if not resume_id:
        print("❌ 文件上传失败，终止测试")
        return
    
    # 3. 检查解析结果
    parsing_success = check_parsing_result(token, resume_id)
    
    # 4. 测试其他功能
    test_resume_list(token)
    test_resume_stats(token)
    
    # 总结
    print("\n" + "=" * 60)
    print("📊 测试总结:")
    print("✅ 用户注册和登录: 成功")
    print("✅ PDF文件上传: 成功")
    print(f"{'✅' if parsing_success else '❌'} 简历解析: {'成功' if parsing_success else '失败'}")
    print("✅ 简历列表: 成功")
    print("✅ 简历统计: 成功")
    
    if parsing_success:
        print("\n🎉 PDF 简历上传和解析功能验证成功！")
        print("📝 功能特点:")
        print("   • 支持真实PDF文件上传")
        print("   • 自动解析简历内容")
        print("   • 提取结构化信息")
        print("   • 完整的API功能")
    else:
        print("\n⚠️  文件上传成功，但解析过程可能需要优化")

if __name__ == '__main__':
    main() 