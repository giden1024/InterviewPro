#!/usr/bin/env python3
"""
DeepSeek API集成测试脚本
"""

import os
import sys
import openai
import json
from datetime import datetime

# 设置项目路径
sys.path.append('backend')

def test_deepseek_api():
    """测试DeepSeek API连接和基本功能"""
    print("🚀 开始测试DeepSeek API集成...")
    print(f"⏰ 测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 配置DeepSeek客户端
    api_key = 'sk-f33bab4e7cef421e8739c295670cb15c'
    base_url = "https://api.deepseek.com"
    
    print(f"🔑 API密钥: {api_key[:10]}...")
    print(f"🌐 API地址: {base_url}")
    
    try:
        # 初始化客户端
        client = openai.OpenAI(
            api_key=api_key,
            base_url=base_url
        )
        
        print("✅ DeepSeek客户端初始化成功")
        
        # 测试基本聊天功能
        print("\n📞 测试基本聊天功能...")
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": "你是一个专业的面试官AI助手。"},
                {"role": "user", "content": "你好，请简单介绍一下你自己。"}
            ],
            temperature=0.7,
            max_tokens=200
        )
        
        print("✅ 基本聊天测试成功")
        print(f"📝 响应内容: {response.choices[0].message.content}")
        
        # 测试面试问题生成
        print("\n🎯 测试面试问题生成...")
        
        prompt = """
请为一位Python后端开发工程师候选人生成2个技术面试问题。
候选人技能包括：Python、Flask、Django、MySQL、Redis、Docker。

请以JSON格式返回，每个问题包含：
- question_text: 问题内容
- category: 问题分类
- difficulty: 难度（easy/medium/hard）
- expected_answer: 期望答案要点

格式示例：
{
  "questions": [
    {
      "question_text": "问题内容",
      "category": "Python",
      "difficulty": "medium",
      "expected_answer": "期望答案要点"
    }
  ]
}
"""
        
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": "你是一个专业的面试官AI助手，专门生成个性化的面试问题。"},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1000
        )
        
        print("✅ 面试问题生成测试成功")
        print(f"📝 生成的问题:")
        print(response.choices[0].message.content)
        
        # 尝试解析JSON
        try:
            content = response.choices[0].message.content
            # 提取JSON部分
            start_idx = content.find('{')
            end_idx = content.rfind('}') + 1
            if start_idx != -1 and end_idx != 0:
                json_content = content[start_idx:end_idx]
                parsed_data = json.loads(json_content)
                print("✅ JSON解析成功")
                print(f"📊 生成问题数量: {len(parsed_data.get('questions', []))}")
            else:
                print("⚠️ 响应中未找到JSON格式内容")
        except json.JSONDecodeError as e:
            print(f"⚠️ JSON解析失败: {e}")
        
        print("\n🎉 DeepSeek API集成测试完成！")
        print("✅ 所有基本功能测试通过")
        
        return True
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        print(f"❌ 错误类型: {type(e).__name__}")
        return False

def test_compatibility():
    """测试与现有系统的兼容性"""
    print("\n🔧 测试系统兼容性...")
    
    try:
        # 模拟现有的AI问题生成器初始化
        from app.models.question import QuestionType, QuestionDifficulty, InterviewType
        print("✅ 模型导入成功")
        
        # 测试枚举类型
        print(f"📋 问题类型: {[t.value for t in QuestionType]}")
        print(f"📊 难度级别: {[d.value for d in QuestionDifficulty]}")
        print(f"🎯 面试类型: {[i.value for i in InterviewType]}")
        
        print("✅ 系统兼容性测试通过")
        
    except Exception as e:
        print(f"❌ 兼容性测试失败: {e}")

if __name__ == "__main__":
    print("🧪 DeepSeek API集成测试脚本")
    print("=" * 60)
    
    # 运行API测试
    api_success = test_deepseek_api()
    
    # 运行兼容性测试
    test_compatibility()
    
    if api_success:
        print("\n🎉 恭喜！DeepSeek API已成功替换OpenAI！")
        print("✅ 现在可以使用DeepSeek进行AI面试问题生成了")
    else:
        print("\n❌ 测试失败，请检查API配置")
    
    print("=" * 60) 