#!/usr/bin/env python3
"""
WebSocket高级功能测试
测试完整的面试WebSocket功能，包括实时通信、语音处理、状态同步等
"""

import socketio
import time
import json
import threading
import logging
import requests
from typing import Dict, Any

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WebSocketTester:
    def __init__(self, server_url='http://localhost:5000'):
        self.server_url = server_url
        self.clients = {}
        self.test_results = {}
        
    def setup_test_environment(self):
        """设置测试环境"""
        try:
            logger.info("🔧 设置WebSocket测试环境...")
            
            # 检查服务器状态
            response = requests.get(f"{self.server_url}/health")
            if response.status_code != 200:
                raise Exception("服务器不可用")
            
            # 创建测试用户并获取token
            self.test_user = self.create_test_user()
            self.test_token = self.login_user()
            
            logger.info(f"✅ 测试环境设置完成 - 用户ID: {self.test_user['id']}")
            return True
            
        except Exception as e:
            logger.error(f"❌ 测试环境设置失败: {e}")
            return False
    
    def create_test_user(self):
        """创建测试用户"""
        try:
            user_data = {
                'email': f'websocket_test_{int(time.time())}@example.com',
                'password': 'test123456',
                'full_name': 'WebSocket Test User'
            }
            
            response = requests.post(f"{self.server_url}/api/v1/auth/register", json=user_data)
            if response.status_code in [200, 201]:
                return response.json()['data']['user']
            else:
                raise Exception(f"创建用户失败: {response.text}")
                
        except Exception as e:
            logger.error(f"创建测试用户失败: {e}")
            raise
    
    def login_user(self):
        """用户登录获取token"""
        try:
            login_data = {
                'email': self.test_user['email'],
                'password': 'test123456'
            }
            
            response = requests.post(f"{self.server_url}/api/v1/auth/login", json=login_data)
            if response.status_code == 200:
                return response.json()['data']['access_token']
            else:
                raise Exception(f"登录失败: {response.text}")
                
        except Exception as e:
            logger.error(f"用户登录失败: {e}")
            raise
    
    def create_websocket_client(self, client_name: str, with_auth: bool = True) -> socketio.SimpleClient:
        """创建WebSocket客户端"""
        try:
            client = socketio.SimpleClient()
            
            # 连接参数
            auth_data = {'token': self.test_token} if with_auth else None
            
            # 连接到服务器
            client.connect(self.server_url, auth=auth_data)
            
            # 等待连接响应
            response = client.receive()
            logger.info(f"📡 客户端 {client_name} 连接响应: {response}")
            
            self.clients[client_name] = client
            return client
            
        except Exception as e:
            logger.error(f"创建WebSocket客户端 {client_name} 失败: {e}")
            raise
    
    def test_basic_connection(self):
        """测试基础连接功能"""
        logger.info("\n🔌 测试基础WebSocket连接...")
        
        try:
            # 创建认证客户端
            auth_client = self.create_websocket_client("auth_client", with_auth=True)
            
            # 创建匿名客户端
            anon_client = self.create_websocket_client("anon_client", with_auth=False)
            
            # 测试ping-pong
            auth_client.emit('ping', {'timestamp': time.time()})
            pong_response = auth_client.receive()
            
            if pong_response[0] == 'pong':
                logger.info("✅ Ping-Pong 测试通过")
                self.test_results['ping_pong'] = True
            else:
                logger.error("❌ Ping-Pong 测试失败")
                self.test_results['ping_pong'] = False
            
            # 测试消息发送
            test_message = "Hello WebSocket!"
            auth_client.emit('test_message', {'message': test_message})
            test_response = auth_client.receive()
            
            if test_response[0] == 'test_response' and test_response[1]['original_message'] == test_message:
                logger.info("✅ 测试消息发送通过")
                self.test_results['test_message'] = True
            else:
                logger.error("❌ 测试消息发送失败")
                self.test_results['test_message'] = False
            
        except Exception as e:
            logger.error(f"❌ 基础连接测试失败: {e}")
            self.test_results['basic_connection'] = False
    
    def test_interview_room_functionality(self):
        """测试面试房间功能"""
        logger.info("\n🏠 测试面试房间功能...")
        
        try:
            client1 = self.clients.get('auth_client')
            client2 = self.create_websocket_client("participant2", with_auth=True)
            
            interview_id = f"test_interview_{int(time.time())}"
            user_id = self.test_user['id']
            
            # 用户1加入面试房间
            client1.emit('join_interview', {
                'interview_id': interview_id,
                'user_id': user_id
            })
            
            join_response1 = client1.receive()
            logger.info(f"用户1加入房间响应: {join_response1}")
            
            # 用户2加入同一面试房间
            client2.emit('join_interview', {
                'interview_id': interview_id,
                'user_id': user_id + 1000  # 模拟不同用户
            })
            
            join_response2 = client2.receive()
            logger.info(f"用户2加入房间响应: {join_response2}")
            
            # 检查是否有participant_joined事件
            try:
                participant_event = client1.receive(timeout=2)
                logger.info(f"参与者加入事件: {participant_event}")
            except:
                logger.warning("未收到参与者加入事件")
            
            # 测试房间内消息发送
            test_message = "Hello from interview room!"
            client1.emit('send_message', {
                'interview_id': interview_id,
                'user_id': user_id,
                'message': test_message,
                'type': 'text'
            })
            
            # 接收消息
            message_event1 = client1.receive()
            message_event2 = client2.receive()
            
            logger.info(f"客户端1收到消息: {message_event1}")
            logger.info(f"客户端2收到消息: {message_event2}")
            
            # 用户离开房间
            client2.emit('leave_interview', {
                'interview_id': interview_id,
                'user_id': user_id + 1000
            })
            
            leave_response = client2.receive()
            logger.info(f"离开房间响应: {leave_response}")
            
            self.test_results['interview_room'] = True
            logger.info("✅ 面试房间功能测试通过")
            
        except Exception as e:
            logger.error(f"❌ 面试房间功能测试失败: {e}")
            self.test_results['interview_room'] = False
    
    def test_interview_flow(self):
        """测试完整面试流程"""
        logger.info("\n📋 测试完整面试流程...")
        
        try:
            client = self.clients.get('auth_client')
            interview_id = f"test_flow_{int(time.time())}"
            user_id = self.test_user['id']
            question_id = 1
            
            # 1. 开始问题
            client.emit('start_question', {
                'interview_id': interview_id,
                'question_id': question_id,
                'question_text': '请介绍一下您的编程经验。'
            })
            
            start_response = client.receive()
            logger.info(f"开始问题响应: {start_response}")
            
            # 2. 模拟打字状态
            client.emit('typing_indicator', {
                'interview_id': interview_id,
                'user_id': user_id,
                'is_typing': True
            })
            
            time.sleep(1)  # 模拟思考时间
            
            # 3. 提交答案
            answer_text = "我有3年的Python开发经验，熟悉Django和Flask框架..."
            client.emit('submit_answer', {
                'interview_id': interview_id,
                'question_id': question_id,
                'answer_text': answer_text,
                'user_id': user_id,
                'response_time': 30
            })
            
            # 接收答案提交响应
            answer_response = client.receive()
            logger.info(f"答案提交响应: {answer_response}")
            
            # 4. 获取面试状态
            client.emit('interview_status', {
                'interview_id': interview_id
            })
            
            status_response = client.receive()
            logger.info(f"面试状态响应: {status_response}")
            
            # 5. 结束面试
            client.emit('end_interview', {
                'interview_id': interview_id,
                'user_id': user_id
            })
            
            end_response = client.receive()
            logger.info(f"结束面试响应: {end_response}")
            
            self.test_results['interview_flow'] = True
            logger.info("✅ 完整面试流程测试通过")
            
        except Exception as e:
            logger.error(f"❌ 完整面试流程测试失败: {e}")
            self.test_results['interview_flow'] = False
    
    def test_voice_functionality(self):
        """测试语音功能"""
        logger.info("\n🎤 测试语音功能...")
        
        try:
            client = self.clients.get('auth_client')
            interview_id = f"test_voice_{int(time.time())}"
            user_id = self.test_user['id']
            
            # 模拟音频数据
            mock_audio_data = b"mock_audio_data_" + b"0" * 1000  # 模拟1KB音频数据
            
            # 发送语音数据块
            for chunk_id in range(3):
                is_final = (chunk_id == 2)
                
                client.emit('voice_data', {
                    'interview_id': interview_id,
                    'audio_data': mock_audio_data,
                    'user_id': user_id,
                    'chunk_id': chunk_id,
                    'is_final': is_final
                })
                
                voice_response = client.receive()
                logger.info(f"语音处理响应 (块 {chunk_id}): {voice_response}")
                
                time.sleep(0.5)  # 模拟语音流
            
            self.test_results['voice_functionality'] = True
            logger.info("✅ 语音功能测试通过")
            
        except Exception as e:
            logger.error(f"❌ 语音功能测试失败: {e}")
            self.test_results['voice_functionality'] = False
    
    def test_help_and_emergency(self):
        """测试帮助和紧急功能"""
        logger.info("\n🆘 测试帮助和紧急功能...")
        
        try:
            client = self.clients.get('auth_client')
            interview_id = f"test_help_{int(time.time())}"
            user_id = self.test_user['id']
            
            # 测试请求帮助
            client.emit('request_help', {
                'interview_id': interview_id,
                'user_id': user_id,
                'help_type': 'clarification',
                'question_id': 1
            })
            
            help_response = client.receive()
            logger.info(f"帮助请求响应: {help_response}")
            
            self.test_results['help_emergency'] = True
            logger.info("✅ 帮助和紧急功能测试通过")
            
        except Exception as e:
            logger.error(f"❌ 帮助和紧急功能测试失败: {e}")
            self.test_results['help_emergency'] = False
    
    def test_concurrent_users(self):
        """测试并发用户"""
        logger.info("\n👥 测试并发用户功能...")
        
        try:
            interview_id = f"test_concurrent_{int(time.time())}"
            
            # 创建多个客户端
            clients = []
            for i in range(3):
                client = self.create_websocket_client(f"concurrent_client_{i}", with_auth=True)
                clients.append(client)
                
                # 加入同一面试房间
                client.emit('join_interview', {
                    'interview_id': interview_id,
                    'user_id': self.test_user['id'] + i
                })
                
                join_response = client.receive()
                logger.info(f"并发客户端 {i} 加入响应: {join_response}")
                
                time.sleep(0.5)
            
            # 测试并发消息发送
            for i, client in enumerate(clients):
                client.emit('send_message', {
                    'interview_id': interview_id,
                    'user_id': self.test_user['id'] + i,
                    'message': f'并发消息来自客户端 {i}',
                    'type': 'text'
                })
            
            # 接收所有消息
            for i, client in enumerate(clients):
                try:
                    while True:
                        message = client.receive(timeout=2)
                        logger.info(f"客户端 {i} 收到: {message}")
                except:
                    break
            
            # 清理
            for client in clients:
                client.disconnect()
            
            self.test_results['concurrent_users'] = True
            logger.info("✅ 并发用户功能测试通过")
            
        except Exception as e:
            logger.error(f"❌ 并发用户功能测试失败: {e}")
            self.test_results['concurrent_users'] = False
    
    def run_performance_test(self):
        """运行性能测试"""
        logger.info("\n⚡ 运行性能测试...")
        
        try:
            client = self.clients.get('auth_client')
            
            # 测试消息发送性能
            start_time = time.time()
            message_count = 50
            
            for i in range(message_count):
                client.emit('test_message', {
                    'message': f'性能测试消息 {i}',
                    'timestamp': time.time()
                })
                
                try:
                    response = client.receive(timeout=1)
                except:
                    logger.warning(f"消息 {i} 未收到响应")
            
            end_time = time.time()
            total_time = end_time - start_time
            messages_per_second = message_count / total_time
            
            logger.info(f"📈 性能测试结果:")
            logger.info(f"   总消息数: {message_count}")
            logger.info(f"   总耗时: {total_time:.2f}秒")
            logger.info(f"   平均每秒: {messages_per_second:.2f}消息")
            
            self.test_results['performance'] = {
                'messages_per_second': messages_per_second,
                'total_time': total_time,
                'success': messages_per_second > 10  # 期望每秒处理10条以上消息
            }
            
        except Exception as e:
            logger.error(f"❌ 性能测试失败: {e}")
            self.test_results['performance'] = {'success': False, 'error': str(e)}
    
    def cleanup(self):
        """清理测试环境"""
        logger.info("\n🧹 清理测试环境...")
        
        try:
            # 断开所有WebSocket连接
            for client_name, client in self.clients.items():
                try:
                    client.disconnect()
                    logger.info(f"   断开客户端: {client_name}")
                except:
                    pass
            
            self.clients.clear()
            logger.info("✅ 测试环境清理完成")
            
        except Exception as e:
            logger.error(f"❌ 清理测试环境失败: {e}")
    
    def generate_test_report(self):
        """生成测试报告"""
        logger.info("\n📊 WebSocket高级功能测试报告")
        logger.info("=" * 50)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results.values() 
                          if (isinstance(result, bool) and result) or 
                             (isinstance(result, dict) and result.get('success', False)))
        
        logger.info(f"总测试数: {total_tests}")
        logger.info(f"通过测试: {passed_tests}")
        logger.info(f"失败测试: {total_tests - passed_tests}")
        logger.info(f"成功率: {(passed_tests / total_tests) * 100:.1f}%")
        
        logger.info("\n详细结果:")
        for test_name, result in self.test_results.items():
            if isinstance(result, bool):
                status = "✅ 通过" if result else "❌ 失败"
            elif isinstance(result, dict):
                if 'success' in result:
                    status = "✅ 通过" if result['success'] else "❌ 失败"
                    if 'messages_per_second' in result:
                        status += f" ({result['messages_per_second']:.1f} msg/s)"
                else:
                    status = "❓ 未知"
            else:
                status = "❓ 未知"
            
            logger.info(f"   {test_name}: {status}")
        
        return passed_tests == total_tests

def main():
    """运行WebSocket测试"""
    logger.info("🚀 开始WebSocket高级功能测试")
    logger.info("=" * 50)
    
    tester = WebSocketTester()
    
    try:
        # 设置测试环境
        if not tester.setup_test_environment():
            logger.error("❌ 无法设置测试环境，退出测试")
            return False
        
        # 运行各项测试
        tester.test_basic_connection()
        tester.test_interview_room_functionality()
        tester.test_interview_flow()
        tester.test_voice_functionality()
        tester.test_help_and_emergency()
        tester.test_concurrent_users()
        tester.run_performance_test()
        
        # 生成测试报告
        success = tester.generate_test_report()
        
        if success:
            logger.info("\n🎉 所有WebSocket功能测试通过！")
            logger.info("💡 WebSocket服务已准备好用于生产环境")
        else:
            logger.info("\n⚠️  部分WebSocket功能测试失败")
            logger.info("🔧 请检查相关功能实现")
        
        return success
        
    except Exception as e:
        logger.error(f"❌ 测试过程中出现错误: {e}")
        return False
        
    finally:
        tester.cleanup()

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1) 