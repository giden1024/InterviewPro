#!/usr/bin/env python3
"""
Complete API Testing Script for InterviewPro
Tests all business APIs to identify missing endpoints
"""

import requests
import json
import sys
from typing import Dict, Any, Optional

BASE_URL = "http://localhost:5001/api/v1"

class APITester:
    def __init__(self):
        self.token = None
        self.user_id = None
        self.session = requests.Session()
        self.results = {
            'passed': [],
            'failed': [],
            'missing': []
        }
    
    def login(self) -> bool:
        """Login and get access token"""
        try:
            response = self.session.post(
                f"{BASE_URL}/auth/login",
                json={
                    "email": "developer@interviewgenius.ai",
                    "password": "dev123"
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('success'):
                    self.token = data['data']['access_token']
                    self.user_id = data['data']['user']['id']
                    self.session.headers.update({
                        'Authorization': f'Bearer {self.token}'
                    })
                    print("✅ Login successful")
                    return True
            
            print(f"❌ Login failed: {response.text}")
            return False
            
        except Exception as e:
            print(f"❌ Login error: {e}")
            return False
    
    def test_endpoint(self, method: str, endpoint: str, data: Optional[Dict] = None, 
                     expected_status: int = 200, description: str = "") -> bool:
        """Test a single API endpoint"""
        try:
            url = f"{BASE_URL}{endpoint}"
            
            if method.upper() == 'GET':
                response = self.session.get(url)
            elif method.upper() == 'POST':
                response = self.session.post(url, json=data)
            elif method.upper() == 'PUT':
                response = self.session.put(url, json=data)
            elif method.upper() == 'DELETE':
                response = self.session.delete(url)
            else:
                print(f"❌ Unsupported method: {method}")
                return False
            
            success = response.status_code == expected_status
            status_icon = "✅" if success else "❌"
            
            print(f"{status_icon} {method.upper()} {endpoint} - {description}")
            print(f"   Status: {response.status_code}, Expected: {expected_status}")
            
            if not success:
                print(f"   Response: {response.text[:200]}...")
                self.results['failed'].append({
                    'endpoint': f"{method.upper()} {endpoint}",
                    'description': description,
                    'status': response.status_code,
                    'expected': expected_status,
                    'response': response.text[:200]
                })
            else:
                self.results['passed'].append({
                    'endpoint': f"{method.upper()} {endpoint}",
                    'description': description
                })
            
            return success
            
        except Exception as e:
            print(f"❌ {method.upper()} {endpoint} - Error: {e}")
            self.results['failed'].append({
                'endpoint': f"{method.upper()} {endpoint}",
                'description': description,
                'error': str(e)
            })
            return False
    
    def test_auth_apis(self):
        """Test authentication APIs"""
        print("\n🔐 Testing Authentication APIs")
        print("-" * 40)
        
        # Test user info
        self.test_endpoint('GET', '/auth/info', description="Get user info")
        
        # Test profile
        self.test_endpoint('GET', '/auth/profile', description="Get user profile")
        
        # Test logout
        self.test_endpoint('POST', '/auth/logout', description="User logout")
    
    def test_jobs_apis(self):
        """Test jobs APIs"""
        print("\n💼 Testing Jobs APIs")
        print("-" * 40)
        
        # Test get jobs
        self.test_endpoint('GET', '/jobs', description="Get jobs list")
        
        # Test get job templates
        self.test_endpoint('GET', '/jobs/templates', description="Get job templates")
        
        # Test create job
        job_data = {
            "title": "Test Software Engineer",
            "company": "Test Company",
            "description": "Test job description",
            "location": "Remote",
            "job_type": "full-time",
            "skills_required": ["Python", "React"]
        }
        self.test_endpoint('POST', '/jobs', job_data, 201, "Create job")
        
        # Test job stats
        self.test_endpoint('GET', '/jobs/stats', description="Get job statistics")
        
        # Test analyze URL (will fail without valid URL, but should return proper error)
        self.test_endpoint('POST', '/jobs/analyze-url', 
                          {"url": "https://example.com"}, 
                          expected_status=400, 
                          description="Analyze job URL")
        
        # Test parse text
        self.test_endpoint('POST', '/jobs/parse-text', 
                          {"job_text": "Software Engineer position"}, 
                          expected_status=200, 
                          description="Parse job text")
    
    def test_resumes_apis(self):
        """Test resumes APIs"""
        print("\n📄 Testing Resumes APIs")
        print("-" * 40)
        
        # Test get resumes
        self.test_endpoint('GET', '/resumes', description="Get resumes list")
        
        # Test resume stats
        self.test_endpoint('GET', '/resumes/stats', description="Get resume statistics")
        
        # Test search resumes
        self.test_endpoint('POST', '/resumes/search', 
                          {"query": "python"}, 
                          description="Search resumes")
    
    def test_questions_apis(self):
        """Test questions APIs"""
        print("\n❓ Testing Questions APIs")
        print("-" * 40)
        
        # Test get questions
        self.test_endpoint('GET', '/questions', description="Get questions list")
        
        # Test get sessions
        self.test_endpoint('GET', '/questions/sessions', description="Get question sessions")
        
        # Test question stats
        self.test_endpoint('GET', '/questions/stats', description="Get question statistics")
    
    def test_interviews_apis(self):
        """Test interviews APIs"""
        print("\n🎤 Testing Interviews APIs")
        print("-" * 40)
        
        # Test get interviews
        self.test_endpoint('GET', '/interviews', description="Get interviews list")
        
        # Test interview statistics
        self.test_endpoint('GET', '/interviews/statistics', description="Get interview statistics")
        
        # Test interview types
        self.test_endpoint('GET', '/interviews/types', description="Get interview types")
    
    def test_analysis_apis(self):
        """Test analysis APIs"""
        print("\n📊 Testing Analysis APIs")
        print("-" * 40)
        
        # Test analysis statistics
        self.test_endpoint('GET', '/analysis/statistics', description="Get analysis statistics")
    
    def check_missing_services(self):
        """Check for missing service files in frontend"""
        print("\n🔍 Checking for Missing Frontend Services")
        print("-" * 40)
        
        import os
        frontend_services_dir = "../frontend/src/services"
        
        expected_services = [
            'authService.ts',
            'jobService.ts',
            'resumeService.ts',
            'interviewService.ts',
            'questionService.ts',
            'analysisService.ts'
        ]
        
        if os.path.exists(frontend_services_dir):
            existing_services = os.listdir(frontend_services_dir)
            
            for service in expected_services:
                if service in existing_services:
                    print(f"✅ {service} - Found")
                else:
                    print(f"❌ {service} - Missing")
                    self.results['missing'].append(f"Frontend service: {service}")
        else:
            print(f"❌ Frontend services directory not found: {frontend_services_dir}")
    
    def run_all_tests(self):
        """Run all API tests"""
        print("🚀 InterviewPro API Testing Suite")
        print("=" * 50)
        
        # Login first
        if not self.login():
            print("❌ Cannot proceed without authentication")
            return False
        
        # Run all tests
        self.test_auth_apis()
        self.test_jobs_apis()
        self.test_resumes_apis()
        self.test_questions_apis()
        self.test_interviews_apis()
        self.test_analysis_apis()
        self.check_missing_services()
        
        # Print summary
        self.print_summary()
        
        return len(self.results['failed']) == 0
    
    def print_summary(self):
        """Print test results summary"""
        print("\n📋 Test Results Summary")
        print("=" * 50)
        
        total_tests = len(self.results['passed']) + len(self.results['failed'])
        passed = len(self.results['passed'])
        failed = len(self.results['failed'])
        missing = len(self.results['missing'])
        
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed}")
        print(f"❌ Failed: {failed}")
        print(f"🔍 Missing: {missing}")
        
        if failed > 0:
            print(f"\n❌ Failed Tests ({failed}):")
            for test in self.results['failed']:
                print(f"   • {test['endpoint']} - {test['description']}")
                if 'error' in test:
                    print(f"     Error: {test['error']}")
                else:
                    print(f"     Status: {test['status']}, Expected: {test['expected']}")
        
        if missing > 0:
            print(f"\n🔍 Missing Components ({missing}):")
            for item in self.results['missing']:
                print(f"   • {item}")
        
        success_rate = (passed / total_tests * 100) if total_tests > 0 else 0
        print(f"\n🎯 Success Rate: {success_rate:.1f}%")

def main():
    """Main function"""
    tester = APITester()
    success = tester.run_all_tests()
    
    if success:
        print("\n🎉 All tests passed!")
        sys.exit(0)
    else:
        print("\n⚠️  Some tests failed. Check the summary above.")
        sys.exit(1)

if __name__ == "__main__":
    main() 