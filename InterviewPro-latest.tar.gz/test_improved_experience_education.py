#!/usr/bin/env python3
"""
测试改进后的工作经历和教育经历提取功能
专门测试刘婧哲 Ven.docx文件
"""

import requests
import json
import os
from pathlib import Path

def test_improved_extraction():
    """测试改进后的提取功能"""
    
    # 测试文件路径
    test_file = 'docs/testfile/刘婧哲 Ven.docx'
    
    if not os.path.exists(test_file):
        print(f"❌ 测试文件不存在: {test_file}")
        return
    
    print(f"📁 测试文件: {test_file}")
    print("="*80)
    
    # 测试端点URLs
    test_server_url = "http://localhost:5002"
    main_server_url = "http://localhost:5001"
    
    # 1. 测试端口5002的测试服务器
    print("1. 测试端口5002的测试服务器")
    print("-" * 40)
    
    try:
        # 健康检查
        response = requests.get(f"{test_server_url}/health", timeout=5)
        if response.status_code == 200:
            print("✅ 测试服务器在线")
            
            # 测试文件提取
            response = requests.post(f"{test_server_url}/test-file/刘婧哲 Ven.docx", timeout=30)
                                      if response.status_code == 200:
                 data = response.json()
                 parsed_data = data.get('parsed_data', {})
                 
                 print(f"✅ 文件解析成功")
                 print(f"📝 姓名: {parsed_data.get('name', '未识别')}")
                 print(f"📧 邮箱: {parsed_data.get('email', '未识别')}")
                 print(f"📱 电话: {parsed_data.get('phone', '未识别')}")
                 
                 # 教育经历
                 education = parsed_data.get('education', [])
                 print(f"\n🎓 教育经历 ({len(education)} 条):")
                 for i, edu in enumerate(education, 1):
                     if isinstance(edu, dict):
                         print(f"  {i}. 学校: {edu.get('school', '未识别')}")
                         print(f"     学位: {edu.get('degree', '未识别')}")
                         print(f"     时间: {edu.get('duration', '未识别')}")
                         print(f"     地点: {edu.get('location', '未识别')}")
                         if edu.get('gpa'):
                             print(f"     GPA: {edu.get('gpa')}")
                     else:
                         print(f"  {i}. {edu}")
                     print()
                 
                 # 工作经历
                 experience = parsed_data.get('experience', [])
                 print(f"💼 工作经历 ({len(experience)} 条):")
                 for i, exp in enumerate(experience, 1):
                     if isinstance(exp, dict):
                         print(f"  {i}. 公司: {exp.get('company', '未识别')}")
                         print(f"     职位: {exp.get('position', '未识别')}")
                         print(f"     时间: {exp.get('duration', '未识别')}")
                         print(f"     地点: {exp.get('location', '未识别')}")
                         print(f"     描述: {exp.get('description', '未识别')[:100]}...")
                     else:
                         print(f"  {i}. {exp}")
                     print()
                 
                 # 项目经验
                 projects = parsed_data.get('projects', [])
                 print(f"🚀 项目经验 ({len(projects)} 条):")
                 for i, proj in enumerate(projects, 1):
                     if isinstance(proj, dict):
                         print(f"  {i}. 项目: {proj.get('name', '未识别')}")
                         print(f"     描述: {proj.get('description', '未识别')[:100]}...")
                     else:
                         print(f"  {i}. {proj}")
                     print()
                
            else:
                print(f"❌ 测试失败: {response.status_code}")
                print(response.text)
        else:
            print("❌ 测试服务器不可用")
    
    except Exception as e:
        print(f"❌ 测试服务器连接失败: {e}")
    
    print("\n" + "="*80)
    
    # 2. 测试端口5001的主服务器（需要认证）
    print("2. 测试端口5001的主服务器")
    print("-" * 40)
    
    try:
        # 健康检查
        response = requests.get(f"{main_server_url}/health", timeout=5)
        if response.status_code == 200:
            print("✅ 主服务器在线")
            
            # 创建测试用户
            try:
                response = requests.post(f"{main_server_url}/api/v1/dev/create-test-user", 
                                       json={}, timeout=10)
                if response.status_code == 200:
                    print("✅ 测试用户创建成功")
                    
                    # 获取token
                    login_response = requests.post(f"{main_server_url}/api/v1/dev/login",
                                                 json={}, timeout=10)
                    if login_response.status_code == 200:
                        token = login_response.json().get('data', {}).get('access_token')
                        print("✅ 获取认证token成功")
                        
                        # 上传测试文件
                        headers = {'Authorization': f'Bearer {token}'}
                        
                        with open(test_file, 'rb') as f:
                            files = {'file': (os.path.basename(test_file), f, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')}
                            
                            upload_response = requests.post(f"{main_server_url}/api/v1/resumes",
                                                          files=files, headers=headers, timeout=30)
                            
                            if upload_response.status_code in [200, 201]:
                                data = upload_response.json()
                                resume_data = data.get('data', {}).get('resume', {})
                                
                                print("✅ 简历上传成功")
                                print(f"📝 姓名: {resume_data.get('name', '未识别')}")
                                print(f"📧 邮箱: {resume_data.get('email', '未识别')}")
                                print(f"📱 电话: {resume_data.get('phone', '未识别')}")
                                
                                # 教育经历
                                education = resume_data.get('education', [])
                                print(f"\n🎓 教育经历 ({len(education)} 条):")
                                for i, edu in enumerate(education, 1):
                                    print(f"  {i}. {edu}")
                                
                                # 工作经历
                                experience = resume_data.get('experience', [])
                                print(f"\n💼 工作经历 ({len(experience)} 条):")
                                for i, exp in enumerate(experience, 1):
                                    print(f"  {i}. {exp}")
                                
                                # 项目经验
                                projects = resume_data.get('projects', [])
                                print(f"\n🚀 项目经验 ({len(projects)} 条):")
                                for i, proj in enumerate(projects, 1):
                                    print(f"  {i}. {proj}")
                                    
                            else:
                                print(f"❌ 文件上传失败: {upload_response.status_code}")
                                print(upload_response.text)
                    else:
                        print(f"❌ 登录失败: {login_response.status_code}")
                else:
                    print(f"❌ 测试用户创建失败: {response.status_code}")
            except Exception as e:
                print(f"❌ 认证流程失败: {e}")
        else:
            print("❌ 主服务器不可用")
    
    except Exception as e:
        print(f"❌ 主服务器连接失败: {e}")

if __name__ == "__main__":
    test_improved_extraction() 