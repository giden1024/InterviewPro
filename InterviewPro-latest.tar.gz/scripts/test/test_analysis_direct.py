#!/usr/bin/env python3
"""
直接测试面试分析API
"""

import requests
import json

# 配置
BASE_URL = "http://localhost:5001"
SESSION_ID = "test-session-001"

# 获取token
def get_token():
    response = requests.post(f"{BASE_URL}/api/v1/dev/login", json={
        "username": "test",
        "password": "test"
    })
    if response.status_code == 200:
        return response.json()["data"]["access_token"]
    else:
        print(f"登录失败: {response.text}")
        return None

# 测试分析API
def test_analysis_api(token):
    headers = {"Authorization": f"Bearer {token}"}
    
    print(f"测试分析API: {BASE_URL}/api/v1/analysis/session/{SESSION_ID}")
    
    response = requests.get(f"{BASE_URL}/api/v1/analysis/session/{SESSION_ID}", headers=headers)
    
    print(f"状态码: {response.status_code}")
    print(f"响应头: {dict(response.headers)}")
    print(f"响应内容: {response.text}")
    
    if response.status_code == 200:
        data = response.json()
        if data.get("success"):
            print("✅ 分析API测试成功!")
            analysis_data = data.get("data", {})
            print(f"分析结果包含: {list(analysis_data.keys())}")
        else:
            print(f"❌ 分析失败: {data.get('message')}")
    else:
        print(f"❌ API调用失败: {response.status_code}")

if __name__ == "__main__":
    print("🚀 开始测试面试分析API...")
    
    token = get_token()
    if token:
        print(f"✅ 获取token成功: {token[:20]}...")
        test_analysis_api(token)
    else:
        print("❌ 无法获取token") 