#!/usr/bin/env python3
"""
职位管理API测试脚本
"""

import requests
import json

BASE_URL = "http://localhost:5001/api/v1"

def test_jobs_api():
    """测试职位API"""
    
    # 1. 登录获取token
    print("🔐 登录获取token...")
    login_data = {
        "email": "testinfo@example.com",
        "password": "test123"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/auth/login", json=login_data)
        if response.status_code == 200:
            token = response.json()['data']['access_token']
            print(f"✅ 登录成功，token: {token[:20]}...")
        else:
            print(f"❌ 登录失败: {response.text}")
            return
    except Exception as e:
        print(f"❌ 登录请求失败: {e}")
        return
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # 2. 创建职位
    print("\n📝 创建职位...")
    job_data = {
        "title": "Python后端工程师",
        "company": "科技公司",
        "description": "负责后端系统开发和维护",
        "requirements": ["Python", "Flask", "数据库"],
        "location": "北京",
        "job_type": "full-time",
        "skills_required": ["Python", "Flask", "MySQL"],
        "experience_level": "mid"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/jobs", json=job_data, headers=headers)
        if response.status_code == 201:
            job = response.json()['data']['job']
            job_id = job['id']
            print(f"✅ 职位创建成功，ID: {job_id}")
            print(f"   标题: {job['title']}")
            print(f"   公司: {job['company']}")
        else:
            print(f"❌ 创建职位失败: {response.text}")
            return
    except Exception as e:
        print(f"❌ 创建职位请求失败: {e}")
        return
    
    # 3. 获取职位列表
    print("\n📋 获取职位列表...")
    try:
        response = requests.get(f"{BASE_URL}/jobs", headers=headers)
        if response.status_code == 200:
            jobs = response.json()['data']['jobs']
            print(f"✅ 获取到 {len(jobs)} 个职位")
            for job in jobs:
                print(f"   - {job['title']} @ {job['company']}")
        else:
            print(f"❌ 获取职位列表失败: {response.text}")
    except Exception as e:
        print(f"❌ 获取职位列表请求失败: {e}")
    
    # 4. 获取职位模板
    print("\n📄 获取职位模板...")
    try:
        response = requests.get(f"{BASE_URL}/jobs/templates", headers=headers)
        if response.status_code == 200:
            templates = response.json()['data']['templates']
            print(f"✅ 获取到 {len(templates)} 个模板")
            for template in templates[:3]:  # 只显示前3个
                print(f"   - {template['title']} ({template['category']})")
        else:
            print(f"❌ 获取职位模板失败: {response.text}")
    except Exception as e:
        print(f"❌ 获取职位模板请求失败: {e}")
    
    # 5. 测试URL解析（使用一个示例URL）
    print("\n🔗 测试URL解析...")
    url_data = {
        "url": "https://example.com/job/123"  # 示例URL
    }
    
    try:
        response = requests.post(f"{BASE_URL}/jobs/analyze-url", json=url_data, headers=headers)
        if response.status_code == 201:
            print("✅ URL解析成功")
        else:
            print(f"⚠️  URL解析失败（预期的，因为是示例URL）: {response.status_code}")
    except Exception as e:
        print(f"⚠️  URL解析请求失败（预期的）: {e}")
    
    print("\n🎉 职位API测试完成！")

if __name__ == "__main__":
    test_jobs_api() 