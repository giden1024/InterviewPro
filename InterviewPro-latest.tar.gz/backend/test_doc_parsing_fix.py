#!/usr/bin/env python3
"""
Test .doc file parsing fix
"""
import os
import sys
import traceback
import logging
from app.services.resume_parser import ResumeParser

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_doc_parsing_fix():
    """测试.doc文件解析修复"""
    
    # 查找最新的.doc文件
    uploads_dir = "uploads"
    doc_files = []
    
    if os.path.exists(uploads_dir):
        for root, dirs, files in os.walk(uploads_dir):
            for file in files:
                if file.endswith('.doc'):
                    file_path = os.path.join(root, file)
                    doc_files.append(file_path)
    
    if not doc_files:
        print("❌ No .doc files found in uploads directory")
        return
    
    # 测试最新的.doc文件
    doc_file = doc_files[-1]  # 最新的文件
    print(f"🧪 Testing .doc file: {doc_file}")
    print(f"📄 File size: {os.path.getsize(doc_file)} bytes")
    
    try:
        parser = ResumeParser()
        
        # 测试文本提取
        print("\n=== Testing Text Extraction ===")
        raw_text = parser._extract_text(doc_file, 'doc')
        print(f"✅ Text extraction successful!")
        print(f"📝 Raw text length: {len(raw_text)} characters")
        print(f"🔍 First 200 chars: {raw_text[:200]}...")
        
        # 测试完整解析
        print("\n=== Testing Full Resume Parsing ===")
        result = parser.parse_resume(doc_file, 'doc')
        
        if result.get('success'):
            print("✅ Resume parsing successful!")
            
            # 显示解析结果
            parsed_data = result.get('data', {})
            print(f"👤 Name: {parsed_data.get('name', 'N/A')}")
            print(f"📧 Email: {parsed_data.get('email', 'N/A')}")
            print(f"📱 Phone: {parsed_data.get('phone', 'N/A')}")
            print(f"💼 Work Experience: {len(parsed_data.get('experience', []))} entries")
            print(f"🎓 Education: {len(parsed_data.get('education', []))} entries")
            print(f"🛠️ Skills: {len(parsed_data.get('skills', []))} items")
            
            if parsed_data.get('experience'):
                print("\n=== Work Experience (First Entry) ===")
                first_exp = parsed_data['experience'][0]
                print(f"  Position: {first_exp.get('position', 'N/A')}")
                print(f"  Company: {first_exp.get('company', 'N/A')}")
                print(f"  Duration: {first_exp.get('duration', 'N/A')}")
            
            if parsed_data.get('skills'):
                print(f"\n=== Skills ===")
                print(f"  {', '.join(parsed_data['skills'][:5])}...")
            
        else:
            print("❌ Resume parsing failed!")
            print(f"Error: {result.get('error', 'Unknown error')}")
        
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        print(f"Exception type: {type(e).__name__}")
        print("📋 Full traceback:")
        traceback.print_exc()

if __name__ == "__main__":
    test_doc_parsing_fix() 