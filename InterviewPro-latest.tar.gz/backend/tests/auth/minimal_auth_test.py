#!/usr/bin/env python3
"""
最小化认证API测试
"""
import sys
import os

# 添加backend目录到路径
sys.path.insert(0, 'backend')

from flask import Flask, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import json

app = Flask(__name__)
app.config['SECRET_KEY'] = 'test-secret'

# 内存中的用户存储
users = {}

@app.route('/test-register', methods=['POST'])
def test_register():
    """测试注册端点"""
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'error': '缺少邮箱或密码'}), 400
        
        if email in users:
            return jsonify({'error': '邮箱已存在'}), 400
        
        # 使用指定的哈希方法
        password_hash = generate_password_hash(password, method='pbkdf2:sha256')
        
        users[email] = {
            'email': email,
            'password_hash': password_hash,
            'username': data.get('username', 'Test User')
        }
        
        return jsonify({
            'success': True,
            'message': '注册成功',
            'user': {
                'email': email,
                'username': users[email]['username']
            }
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/test-login', methods=['POST'])
def test_login():
    """测试登录端点"""
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'error': '缺少邮箱或密码'}), 400
        
        user = users.get(email)
        if not user:
            return jsonify({'error': '用户不存在'}), 400
        
        if not check_password_hash(user['password_hash'], password):
            return jsonify({'error': '密码错误'}), 400
        
        return jsonify({
            'success': True,
            'message': '登录成功',
            'user': {
                'email': email,
                'username': user['username']
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health')
def health():
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    print("启动最小化认证测试服务...")
    print("端口: 5001")
    app.run(host='0.0.0.0', port=5001, debug=True) 