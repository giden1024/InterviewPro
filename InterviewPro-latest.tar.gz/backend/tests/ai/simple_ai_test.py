#!/usr/bin/env python3
"""
Simple AI Question Generation Test
"""

import requests
import json
import time

def test_ai_system():
    """Test the AI question generation system"""
    base_url = "http://localhost:5000"
    
    print("🧪 Simple AI Question Generation Test")
    print("=" * 50)
    
    # 1. Login
    print("1. Testing login...")
    login_data = {
        "email": "test_ai_questions@example.com",
        "password": "testpass123"
    }
    
    response = requests.post(f"{base_url}/api/v1/auth/login", json=login_data)
    if response.status_code != 200:
        print(f"❌ Login failed: {response.text}")
        return False
    
    token = response.json()['data']['access_token']
    headers = {"Authorization": f"Bearer {token}"}
    print("✅ Login successful")
    
    # 2. Generate questions
    print("2. Testing question generation...")
    gen_data = {
        "resume_id": 1,
        "interview_type": "technical",
        "total_questions": 5
    }
    
    response = requests.post(f"{base_url}/api/v1/questions/generate", json=gen_data, headers=headers)
    if response.status_code != 200:
        print(f"❌ Question generation failed: {response.text}")
        return False
    
    result = response.json()
    print(f"✅ Generated {len(result['data']['questions'])} questions")
    session_id = result['data'].get('session_id', result['data'].get('session', {}).get('session_id', 'N/A'))
    print(f"   Session ID: {session_id}")
    
    # 3. Get questions
    print("3. Testing question retrieval...")
    response = requests.get(f"{base_url}/api/v1/questions", headers=headers)
    if response.status_code != 200:
        print(f"❌ Question retrieval failed: {response.text}")
        return False
    
    questions = response.json()['data']['questions']
    print(f"✅ Retrieved {len(questions)} total questions")
    
    # 4. Get statistics
    print("4. Testing statistics...")
    response = requests.get(f"{base_url}/api/v1/questions/stats", headers=headers)
    if response.status_code != 200:
        print(f"❌ Statistics failed: {response.text}")
        return False
    
    stats = response.json()['data']
    print(f"✅ Statistics: {stats['total_questions']} questions, {stats['total_sessions']} sessions")
    
    print("\n🎉 All tests passed! AI Question Generation System is working correctly.")
    return True

if __name__ == "__main__":
    success = test_ai_system()
    if not success:
        exit(1) 