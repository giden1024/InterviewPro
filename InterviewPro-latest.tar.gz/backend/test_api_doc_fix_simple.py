#!/usr/bin/env python3
"""
Simple API test for .doc file parsing fix
"""
import os
import requests
import json

def test_api_doc_fix_simple():
    """简化版API测试.doc文件解析修复"""
    
    # API配置
    base_url = "http://localhost:5001"
    
    # 查找最新的.doc文件
    uploads_dir = "uploads"
    doc_files = []
    
    if os.path.exists(uploads_dir):
        for root, dirs, files in os.walk(uploads_dir):
            for file in files:
                if file.endswith('.doc'):
                    file_path = os.path.join(root, file)
                    doc_files.append(file_path)
    
    if not doc_files:
        print("❌ No .doc files found for testing")
        return
    
    doc_file = doc_files[-1]  # 最新的文件
    print(f"🧪 Testing .doc file via API: {doc_file}")
    print(f"📄 File size: {os.path.getsize(doc_file)} bytes")
    
    try:
        # 1. 使用开发API创建用户
        print("\n=== Creating dev user ===")
        dev_user_response = requests.post(f"{base_url}/api/v1/dev/create-test-user")
        print(f"Dev user creation status: {dev_user_response.status_code}")
        
        # 2. 使用开发API登录
        print("\n=== Dev login ===")
        dev_login_response = requests.post(f"{base_url}/api/v1/dev/login")
        
        if dev_login_response.status_code != 200:
            print(f"❌ Dev login failed: {dev_login_response.status_code}")
            print(f"Response: {dev_login_response.text}")
            return
        
        token = dev_login_response.json().get('access_token')
        if not token:
            print("❌ No access token received")
            return
            
        headers = {"Authorization": f"Bearer {token}"}
        print("✅ Dev authentication successful")
        
        # 3. 上传.doc文件
        print("\n=== Uploading .doc file ===")
        with open(doc_file, 'rb') as f:
            files = {'file': ('test_resume.doc', f, 'application/msword')}
            
            upload_response = requests.post(
                f"{base_url}/api/v1/resumes",
                files=files,
                headers=headers
            )
        
        print(f"Upload response status: {upload_response.status_code}")
        
        if upload_response.status_code == 200:
            result = upload_response.json()
            print("✅ Upload successful!")
            
            # 打印完整响应以便调试
            print("\n=== Full Response ===")
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
            # 分析响应
            if result.get('success'):
                print("\n✅ Resume parsing successful!")
                
                parsed_data = result.get('parsed_data', {})
                print(f"👤 Name: {parsed_data.get('name', 'N/A')}")
                print(f"📧 Email: {parsed_data.get('email', 'N/A')}")
                print(f"📱 Phone: {parsed_data.get('phone', 'N/A')}")
                print(f"💼 Experience: {len(parsed_data.get('experience', []))} entries")
                print(f"🎓 Education: {len(parsed_data.get('education', []))} entries") 
                print(f"🛠️ Skills: {len(parsed_data.get('skills', []))} items")
                
                # 检查是否成功提取个人信息
                if parsed_data.get('name') and parsed_data.get('email'):
                    print("\n🎉 .doc file parsing fix is working correctly!")
                    print("✅ Personal information successfully extracted!")
                elif parsed_data.get('name') or parsed_data.get('email'):
                    print("\n⚠️ Partial success - some personal info extracted")
                else:
                    print("\n⚠️ File parsed but personal info extraction may need improvement")
                    
            else:
                print(f"\n❌ Parsing failed: {result.get('error', 'Unknown error')}")
                if 'Package not found' in str(result.get('error', '')):
                    print("❌ THE FIX HAS NOT BEEN APPLIED - still getting Package not found error")
                
        else:
            print(f"❌ Upload failed: {upload_response.status_code}")
            try:
                error_response = upload_response.json()
                print(f"Error details: {json.dumps(error_response, indent=2)}")
            except:
                print(f"Raw response: {upload_response.text}")
                
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_api_doc_fix_simple() 