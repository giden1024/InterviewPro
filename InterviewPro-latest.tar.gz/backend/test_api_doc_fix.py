#!/usr/bin/env python3
"""
Test .doc file parsing fix via API
"""
import os
import requests
import json

def test_api_doc_fix():
    """通过API测试.doc文件解析修复"""
    
    # API配置
    base_url = "http://localhost:5001"
    
    # 查找最新的.doc文件
    uploads_dir = "uploads"
    doc_files = []
    
    if os.path.exists(uploads_dir):
        for root, dirs, files in os.walk(uploads_dir):
            for file in files:
                if file.endswith('.doc'):
                    file_path = os.path.join(root, file)
                    doc_files.append(file_path)
    
    if not doc_files:
        print("❌ No .doc files found for testing")
        return
    
    doc_file = doc_files[-1]  # 最新的文件
    print(f"🧪 Testing .doc file via API: {doc_file}")
    print(f"📄 File size: {os.path.getsize(doc_file)} bytes")
    
    try:
        # 1. 创建测试用户
        print("\n=== Creating test user ===")
        auth_data = {
            "username": "test_doc_user",
            "email": "test@example.com", 
            "password": "test123456"
        }
        
        auth_response = requests.post(f"{base_url}/api/v1/auth/register", json=auth_data)
        if auth_response.status_code not in [201, 400]:  # 400可能是用户已存在
            print(f"❌ Auth failed: {auth_response.status_code}")
            return
        
        # 2. 登录获取token
        login_response = requests.post(f"{base_url}/api/v1/auth/login", json={
            "email": "test@example.com",
            "password": "test123456"
        })
        
        if login_response.status_code != 200:
            print(f"❌ Login failed: {login_response.status_code}")
            return
        
        token = login_response.json().get('access_token')
        headers = {"Authorization": f"Bearer {token}"}
        
        print("✅ Authentication successful")
        
        # 3. 上传.doc文件
        print("\n=== Uploading .doc file ===")
        with open(doc_file, 'rb') as f:
            files = {'file': ('test_resume.doc', f, 'application/msword')}
            
            upload_response = requests.post(
                f"{base_url}/api/v1/resumes",
                files=files,
                headers=headers
            )
        
        print(f"Upload response status: {upload_response.status_code}")
        
        if upload_response.status_code == 200:
            result = upload_response.json()
            print("✅ Upload successful!")
            
            # 分析响应
            if result.get('success'):
                print("✅ Resume parsing successful!")
                
                parsed_data = result.get('parsed_data', {})
                print(f"👤 Name: {parsed_data.get('name', 'N/A')}")
                print(f"📧 Email: {parsed_data.get('email', 'N/A')}")
                print(f"📱 Phone: {parsed_data.get('phone', 'N/A')}")
                print(f"💼 Experience: {len(parsed_data.get('experience', []))} entries")
                print(f"🎓 Education: {len(parsed_data.get('education', []))} entries")
                print(f"🛠️ Skills: {len(parsed_data.get('skills', []))} items")
                
                if parsed_data.get('name'):
                    print("🎉 .doc file parsing fix is working correctly!")
                else:
                    print("⚠️ File parsed but personal info extraction may need improvement")
                    
            else:
                print(f"❌ Parsing failed: {result.get('error', 'Unknown error')}")
                if 'Package not found' in str(result.get('error', '')):
                    print("❌ The fix has not been applied yet - still getting Package not found error")
                
        else:
            print(f"❌ Upload failed: {upload_response.status_code}")
            try:
                error_response = upload_response.json()
                print(f"Error details: {error_response}")
            except:
                print(f"Raw response: {upload_response.text}")
                
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")

if __name__ == "__main__":
    test_api_doc_fix() 