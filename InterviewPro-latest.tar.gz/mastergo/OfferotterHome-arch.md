# OfferotterHome Component Architecture Document

## Component Overview

**Component Name**: OfferotterHome  
**Description**: Main landing page for Offerotter - AI-powered interview platform  
**Type**: Page Component  
**Framework**: React with TypeScript  

## Component Structure Analysis

The Offerotter home page is a comprehensive landing page with the following main sections:

### 1. Navigation Header
- Logo with brand name "Offerotter"
- Navigation menu (Home, Pricing, Contact Us)
- "Get Start for Free" button

### 2. Hero Section
- Main headline: "OfferOtter Master Your Dream Job Interview"
- Statistics display: "380,000+ resumes have been analyzed, and the number of participants in simulated interviews has exceeded 1,200,000"
- Three key features with icons:
  - Resume Diagnosis
  - Multi-Scenario Interview Simulation  
  - Real-Time Interview Plug-in Assistance

### 3. Core Features Section
- Section title: "Core Features"
- Three feature cards with detailed descriptions
- Interactive UI elements and icons

### 4. Why Choose OfferOtter Section
- Four key statistics with visual emphasis:
  - 89% Interview Success Rate
  - 95% User Satisfaction
  - 1.2M+ Mock Interviews Conducted
  - 380,000 Resumes Professionally Optimized
- Feature details with icons and descriptions

### 5. User Testimonials Section
- Title: "Real Stories from Users"
- Three testimonial cards with user avatars and role descriptions:
  - Product Manager
  - Marketing Manager
  - Data Analyst

### 6. FAQ Section
- Title: "Any Questions? And we have got answers to all of them"
- Expandable FAQ items with questions about platform features

### 7. CTA Section
- Final call-to-action with button
- "Get Start for Free" and "Watch The Demo" buttons

### 8. Footer
- Links: Privacy Policy, Terms of Use
- Copyright notice

## Properties Interface

```typescript
interface OfferotterHomeProps {
  // Theme and styling
  className?: string;
  theme?: 'light' | 'dark';
  
  // Content customization
  heroTitle?: string;
  heroSubtitle?: string;
  statistics?: {
    resumesAnalyzed: string;
    interviewParticipants: string;
  };
  
  // Feature sections
  coreFeatures?: CoreFeature[];
  whyChooseStats?: Statistic[];
  testimonials?: Testimonial[];
  faqItems?: FAQItem[];
  
  // Interactive callbacks
  onGetStarted?: () => void;
  onWatchDemo?: () => void;
  onContactUs?: () => void;
}

interface CoreFeature {
  id: string;
  title: string;
  description: string;
  icon: string;
}

interface Statistic {
  id: string;
  value: string;
  description: string;
  icon?: string;
}

interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  avatar: string;
}

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  isExpanded?: boolean;
}
```

## Component States

### Interactive States
- **Navigation**: Active menu item highlighting
- **Buttons**: Hover, focus, active, disabled states
- **FAQ Items**: Expanded/collapsed states
- **Cards**: Hover effects with shadows and transforms

### Responsive States
- **Desktop**: Full layout with side-by-side content
- **Tablet**: Adapted layout with smaller spacing
- **Mobile**: Stacked layout, collapsed navigation

## Slots Analysis

### Header Slot
- **Purpose**: Custom navigation or logo area
- **Default**: Standard Offerotter branding
- **Optional**: Yes

### Hero Content Slot
- **Purpose**: Custom hero section content
- **Default**: Standard title and statistics
- **Optional**: Yes

### Features Slot
- **Purpose**: Custom feature cards
- **Default**: Three core features
- **Optional**: Yes

### Testimonials Slot
- **Purpose**: Custom testimonial content
- **Default**: Three user testimonials
- **Optional**: Yes

### Footer Slot
- **Purpose**: Custom footer content
- **Default**: Standard links and copyright
- **Optional**: Yes

## Image Resources

### Resource List and Paths

| Icon Description | Original Path | Target Path | Icon Color Control |
|------------------|---------------|-------------|-------------------|
| Logo Icon | `.mastergo/images/21:*-*.svg` | `src/components/OfferotterHome/images/logo-icon.svg` | Brand color #A07161 |
| Resume Icon | `.mastergo/images/21:*-*.svg` | `src/components/OfferotterHome/images/icon-resume.svg` | Dynamic, defaults to #282828 |
| Interview Icon | `.mastergo/images/21:*-*.svg` | `src/components/OfferotterHome/images/icon-interview.svg` | Dynamic, defaults to #282828 |
| Assistant Icon | `.mastergo/images/21:*-*.svg` | `src/components/OfferotterHome/images/icon-assistant.svg` | Dynamic, defaults to #282828 |
| Play Button Icon | `.mastergo/images/21:*-*.svg` | `src/components/OfferotterHome/images/icon-play.svg` | Dynamic, defaults to #363636 |
| Arrow Icon | `.mastergo/images/21:*-*.svg` | `src/components/OfferotterHome/images/icon-arrow.svg` | Dynamic, defaults to currentColor |
| User Avatars | `.mastergo/images/21:*-*.svg` | `src/components/OfferotterHome/images/avatar-*.svg` | Fixed colors as designed |
| Background Elements | `.mastergo/images/21:*-*.svg` | `src/components/OfferotterHome/images/bg-*.svg` | Fixed colors as designed |

### Icon Import and Usage Method

```typescript
// In OfferotterHome.tsx, import icons
import LogoIcon from "./images/logo-icon.svg?raw";
import ResumeIcon from "./images/icon-resume.svg?raw";
import InterviewIcon from "./images/icon-interview.svg?raw";
```

Using SVGs in React components:

```tsx
const IconComponent: React.FC<{ icon: string; className?: string }> = ({ icon, className }) => (
  <div 
    className={className}
    dangerouslySetInnerHTML={{ __html: icon }}
  />
);

// Usage
<IconComponent 
  icon={ResumeIcon} 
  className="text-gray-800 w-6 h-6" 
/>
```

## Styling Approach

### CSS Framework
- **Tailwind CSS**: For utility-first styling
- **Custom CSS**: For complex animations and brand-specific designs

### Color Palette
- **Primary Blue**: #0097DC
- **Light Blue**: #EFF9FF, #E2F2FC, #ECF9FF
- **Text Colors**: #262626, #282828, #363636
- **Background**: #FFFFFF, gradients as specified
- **Accent**: #A5E2FF, #75A6FF

### Typography
- **Font Family**: Poppins
- **Weights**: Regular (400), Medium (500), SemiBold (600), Bold (700)
- **Sizes**: Responsive scale from 14px to 66px

### Animation and Interactions
- **Hover Effects**: Subtle transforms and shadow changes
- **Scroll Animations**: Fade-in effects for sections
- **Button States**: Smooth transitions for all interactive elements

## Responsive Design

### Breakpoints
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

### Layout Adaptations
- **Mobile**: Single column, stacked sections, hamburger menu
- **Tablet**: Two-column layouts where appropriate
- **Desktop**: Full multi-column layouts as designed

## Accessibility Considerations

- **ARIA Labels**: All interactive elements properly labeled
- **Keyboard Navigation**: Full keyboard accessibility
- **Color Contrast**: WCAG AA compliance
- **Screen Readers**: Semantic HTML structure
- **Focus Management**: Clear focus indicators

## Performance Considerations

- **Image Optimization**: SVG icons, optimized images
- **Code Splitting**: Lazy loading for non-critical sections
- **Bundle Size**: Minimal dependencies, tree-shaking
- **Loading States**: Skeleton screens for dynamic content

## Dependencies

```json
{
  "dependencies": {
    "react": "^18.0.0",
    "@types/react": "^18.0.0",
    "tailwindcss": "^3.0.0",
    "framer-motion": "^10.0.0"
  }
}
```

## File Structure

```
src/components/OfferotterHome/
├── index.ts
├── OfferotterHome.tsx
├── types.ts
├── images/
│   ├── logo-icon.svg
│   ├── icon-resume.svg
│   ├── icon-interview.svg
│   ├── icon-assistant.svg
│   ├── icon-play.svg
│   ├── icon-arrow.svg
│   ├── avatar-pm.svg
│   ├── avatar-marketing.svg
│   ├── avatar-data.svg
│   └── bg-elements.svg
└── styles.css
``` 