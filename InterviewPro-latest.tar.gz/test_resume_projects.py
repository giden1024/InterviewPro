#!/usr/bin/env python3
"""
测试简历解析功能，特别是项目经验提取
"""

import os
import sys
import json
from pathlib import Path

# 添加backend模块路径
backend_path = Path(__file__).parent / 'backend'
sys.path.insert(0, str(backend_path))

from app.services.resume_parser import ResumeParser

def test_resume_parsing():
    """测试简历解析功能"""
    parser = ResumeParser()
    test_files = [
        'docs/testfile/app_cv.pdf',
        'docs/testfile/resume.docx',
        'docs/testfile/陈熙蕾.docx',
        'docs/testfile/刘婧哲 Ven.docx'
    ]
    
    for file_path in test_files:
        if not os.path.exists(file_path):
            print(f"文件不存在: {file_path}")
            continue
            
        print(f"\n{'='*50}")
        print(f"解析文件: {file_path}")
        print(f"{'='*50}")
        
        # 获取文件类型
        file_type = file_path.split('.')[-1].lower()
        
        try:
            # 解析简历
            result = parser.parse_resume(file_path, file_type)
            
            if result['success']:
                print("✅ 解析成功")
                parsed_data = result['parsed_data']
                
                print(f"\n📝 基本信息:")
                print(f"姓名: {parsed_data.get('name', 'N/A')}")
                print(f"邮箱: {parsed_data.get('email', 'N/A')}")
                print(f"电话: {parsed_data.get('phone', 'N/A')}")
                
                print(f"\n💼 工作经历 ({len(parsed_data.get('experience', []))}):")
                for i, exp in enumerate(parsed_data.get('experience', [])[:3]):  # 只显示前3个
                    print(f"  {i+1}. {exp.get('position', 'N/A')} @ {exp.get('company', 'N/A')}")
                
                print(f"\n🎓 教育背景 ({len(parsed_data.get('education', []))}):")
                for i, edu in enumerate(parsed_data.get('education', [])):
                    print(f"  {i+1}. {edu.get('degree', 'N/A')} @ {edu.get('school', 'N/A')}")
                
                print(f"\n🛠️ 技能 ({len(parsed_data.get('skills', []))}):")
                skills = parsed_data.get('skills', [])
                if skills:
                    print(f"  {', '.join(skills[:10])}")  # 只显示前10个技能
                
                print(f"\n🚀 项目经验:")
                projects = parsed_data.get('projects', [])
                if projects:
                    print(f"  找到 {len(projects)} 个项目")
                    for i, proj in enumerate(projects[:3]):  # 只显示前3个
                        print(f"  {i+1}. {proj.get('name', 'N/A')}")
                else:
                    print("  ❌ 未找到项目经验")
                
                # 在原始文本中搜索项目相关关键词
                raw_text = result.get('raw_text', '').lower()
                project_keywords = ['project', '项目', 'projects', '作品', '项目经验', 'portfolio']
                found_keywords = [kw for kw in project_keywords if kw in raw_text]
                
                if found_keywords:
                    print(f"\n🔍 在原始文本中发现项目相关关键词: {found_keywords}")
                    # 查找包含这些关键词的行
                    lines = result.get('raw_text', '').split('\n')
                    project_lines = []
                    for line in lines:
                        if any(kw in line.lower() for kw in project_keywords):
                            project_lines.append(line.strip())
                    
                    if project_lines:
                        print("  相关文本行:")
                        for line in project_lines[:5]:  # 只显示前5行
                            if line:
                                print(f"    '{line[:80]}...' " if len(line) > 80 else f"    '{line}'")
                
            else:
                print(f"❌ 解析失败: {result['error']}")
                
        except Exception as e:
            print(f"❌ 异常: {str(e)}")

if __name__ == "__main__":
    test_resume_parsing() 