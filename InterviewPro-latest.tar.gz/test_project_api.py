#!/usr/bin/env python3
"""
测试项目提取API功能
"""

import requests
import json

def test_project_extraction_api():
    """测试项目提取API"""
    base_url = "http://localhost:5002"
    
    print("🚀 测试项目提取API功能")
    print("="*60)
    
    # 首先测试健康检查
    try:
        health_response = requests.get(f"{base_url}/health")
        if health_response.status_code == 200:
            print("✅ 测试服务健康检查通过")
            print(f"   响应: {health_response.json()}")
        else:
            print("❌ 健康检查失败")
            return
    except Exception as e:
        print(f"❌ 无法连接到测试服务: {e}")
        print("💡 请先运行: python test_projects_endpoint.py")
        return
    
    print()
    
    # 测试预定义文件
    test_files = [
        '陈熙蕾.docx',
        'app_cv.pdf',
        'resume.docx',
        '刘婧哲 Ven.docx'
    ]
    
    for filename in test_files:
        print(f"📄 测试文件: {filename}")
        print("-" * 40)
        
        try:
            response = requests.post(f"{base_url}/test-file/{filename}")
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get('success'):
                    parsed_data = data.get('parsed_data', {})
                    projects = parsed_data.get('projects', [])
                    
                    print(f"✅ 解析成功")
                    print(f"   📝 姓名: {parsed_data.get('name', 'N/A')}")
                    print(f"   📧 邮箱: {parsed_data.get('email', 'N/A')}")
                    print(f"   📞 电话: {parsed_data.get('phone', 'N/A')}")
                    print(f"   🛠️  技能数量: {parsed_data.get('skills_count', 0)}")
                    print(f"   💼 工作经历: {parsed_data.get('experience_count', 0)}")
                    print(f"   🎓 教育背景: {parsed_data.get('education_count', 0)}")
                    print(f"   🚀 项目经验: {parsed_data.get('projects_count', 0)}")
                    
                    if projects:
                        print(f"\n   📋 项目详情:")
                        for i, project in enumerate(projects, 1):
                            print(f"     {i}. 📌 {project.get('name', '未命名项目')}")
                            print(f"        🏷️  类型: {project.get('type', 'N/A')}")
                            
                            if project.get('technologies'):
                                techs = project['technologies'][:5]  # 只显示前5个技术
                                print(f"        🛠️  技术: {', '.join(techs)}")
                            
                            if project.get('duration'):
                                print(f"        ⏰ 时间: {project['duration']}")
                            
                            if project.get('description'):
                                desc = project['description']
                                if len(desc) > 100:
                                    desc = desc[:100] + "..."
                                print(f"        📝 描述: {desc}")
                            print()
                            
                        # 总结
                        project_types = [p.get('type', 'unknown') for p in projects]
                        type_counts = {}
                        for ptype in project_types:
                            type_counts[ptype] = type_counts.get(ptype, 0) + 1
                            
                        print(f"   📊 项目类型分布: {dict(type_counts)}")
                        
                        all_techs = []
                        for p in projects:
                            all_techs.extend(p.get('technologies', []))
                        unique_techs = list(set(all_techs))
                        if unique_techs:
                            print(f"   🛠️  涉及技术: {', '.join(unique_techs[:8])}")
                            if len(unique_techs) > 8:
                                print(f"            ... 等{len(unique_techs)}种技术")
                    else:
                        print(f"   ⚠️  未找到项目经验")
                        
                    # 显示技能信息
                    skills = parsed_data.get('skills', [])
                    if skills:
                        print(f"\n   🛠️  技能列表: {', '.join(skills)}")
                else:
                    print(f"❌ 解析失败: {data.get('error', '未知错误')}")
                    
            else:
                print(f"❌ HTTP错误: {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   错误信息: {error_data}")
                except:
                    print(f"   错误信息: {response.text}")
                    
        except Exception as e:
            print(f"❌ 请求异常: {e}")
        
        print()

if __name__ == "__main__":
    test_project_extraction_api() 