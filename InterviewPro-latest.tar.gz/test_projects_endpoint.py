#!/usr/bin/env python3
"""
简单的Flask测试服务，专门用于测试项目提取功能
"""

import os
import sys
from pathlib import Path
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename

# 添加backend模块路径
backend_path = Path(__file__).parent / 'backend'
sys.path.insert(0, str(backend_path))

from app.services.resume_parser import ResumeParser

app = Flask(__name__)

# 添加CORS支持
@app.after_request
def after_request(response):
    """添加CORS头部"""
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# 支持的文件格式
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'doc', 'txt'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

def allowed_file(filename):
    """检查文件格式是否支持"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/health', methods=['GET'])
def health_check():
    """健康检查"""
    return jsonify({
        'status': 'healthy',
        'service': 'project-extraction-test',
        'version': '1.0.0'
    })

@app.route('/test-project-extraction', methods=['POST'])
def test_project_extraction():
    """测试项目提取功能"""
    try:
        # 检查请求中是否有文件
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'error': '请选择要上传的文件'
            }), 400
        
        file = request.files['file']
        
        # 检查文件是否为空
        if file.filename == '':
            return jsonify({
                'success': False,
                'error': '请选择要上传的文件'
            }), 400
        
        # 检查文件格式
        if not allowed_file(file.filename):
            return jsonify({
                'success': False,
                'error': f'不支持的文件格式，请上传 {", ".join(ALLOWED_EXTENSIONS)} 格式的文件'
            }), 400
        
        # 获取文件扩展名
        file_extension = file.filename.rsplit('.', 1)[1].lower()
        
        # 创建临时文件
        temp_filename = f"temp_{secure_filename(file.filename)}"
        temp_path = os.path.join('/tmp', temp_filename)
        
        # 保存临时文件
        file.save(temp_path)
        
        try:
            # 使用解析器解析文件
            parser = ResumeParser()
            result = parser.parse_resume(temp_path, file_extension)
            
            if result['success']:
                parsed_data = result['parsed_data']
                projects = parsed_data.get('projects', [])
                
                return jsonify({
                    'success': True,
                    'filename': file.filename,
                    'file_type': file_extension,
                    'parsed_data': {
                        'name': parsed_data.get('name'),
                        'email': parsed_data.get('email'),
                        'phone': parsed_data.get('phone'),
                        'skills_count': len(parsed_data.get('skills', [])),
                        'experience_count': len(parsed_data.get('experience', [])),
                        'education_count': len(parsed_data.get('education', [])),
                        'projects_count': len(projects),
                        'projects': projects,
                        'skills': parsed_data.get('skills', [])[:10],  # 只返回前10个技能
                        'experience': parsed_data.get('experience', []),  # 添加工作经历
                        'education': parsed_data.get('education', [])  # 添加教育经历
                    }
                })
            else:
                return jsonify({
                    'success': False,
                    'error': result.get('error', '解析失败')
                }), 500
                
        finally:
            # 清理临时文件
            if os.path.exists(temp_path):
                os.remove(temp_path)
                
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'服务器错误: {str(e)}'
        }), 500

@app.route('/test-file/<filename>', methods=['POST'])
def test_predefined_file(filename):
    """测试预定义的测试文件"""
    try:
        print(f"[DEBUG] 测试文件: {filename}")
        
        # 构建文件路径
        test_file_path = os.path.join('docs', 'testfile', filename)
        print(f"[DEBUG] 文件路径: {test_file_path}")
        
        if not os.path.exists(test_file_path):
            return jsonify({
                'success': False,
                'error': f'测试文件不存在: {filename}'
            }), 404
        
        # 获取文件扩展名
        file_extension = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
        print(f"[DEBUG] 文件类型: {file_extension}")
        
        if file_extension not in ALLOWED_EXTENSIONS:
            return jsonify({
                'success': False,
                'error': f'不支持的文件格式: {file_extension}'
            }), 400
        
        # 使用解析器解析文件
        parser = ResumeParser()
        result = parser.parse_resume(test_file_path, file_extension)
        
        # 添加调试信息
        print(f"[DEBUG] 解析结果: success={result.get('success')}")
        
        if result.get('success'):
            parsed_data = result.get('parsed_data', {})
            print(f"[DEBUG] parsed_data keys: {list(parsed_data.keys())}")
            projects = parsed_data.get('projects', [])
            print(f"[DEBUG] 找到项目数量: {len(projects)}")
            
            # 如果没有项目，尝试直接调用项目提取方法
            if len(projects) == 0 and result.get('raw_text'):
                print(f"[DEBUG] 尝试直接调用项目提取方法...")
                direct_projects = parser._extract_projects(result['raw_text'])
                print(f"[DEBUG] 直接调用结果: {len(direct_projects)} 个项目")
                # 更新parsed_data
                parsed_data['projects'] = direct_projects
                projects = direct_projects
            
            return jsonify({
                'success': True,
                'filename': filename,
                'file_type': file_extension,
                'parsed_data': {
                    'name': parsed_data.get('name'),
                    'email': parsed_data.get('email'),
                    'phone': parsed_data.get('phone'),
                    'skills_count': len(parsed_data.get('skills', [])),
                    'experience_count': len(parsed_data.get('experience', [])),
                    'education_count': len(parsed_data.get('education', [])),
                    'projects_count': len(projects),
                    'projects': projects,
                    'skills': parsed_data.get('skills', [])[:10],
                    'experience': parsed_data.get('experience', []),  # 添加工作经历
                    'education': parsed_data.get('education', [])  # 添加教育经历
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': result.get('error', '解析失败')
            }), 500
            
    except Exception as e:
        print(f"[ERROR] 异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': f'服务器错误: {str(e)}'
        }), 500

if __name__ == '__main__':
    print("🚀 启动项目提取测试服务...")
    print("📡 服务地址: http://localhost:5002")
    print("🔗 测试端点:")
    print("   POST /test-project-extraction - 上传文件测试")
    print("   POST /test-file/<filename> - 测试预定义文件")
    print("   GET  /health - 健康检查")
    
    app.run(host='0.0.0.0', port=5002, debug=True) 