#!/usr/bin/env python3
"""
测试本地服务的项目提取功能
"""

import requests
import json
import os

def test_local_project_extraction():
    """测试本地服务的项目提取功能"""
    base_url = "http://localhost:5001"
    
    # 测试文件列表
    test_files = [
        'docs/testfile/app_cv.pdf',
        'docs/testfile/resume.docx', 
        'docs/testfile/陈熙蕾.docx',
        'docs/testfile/刘婧哲 Ven.docx'
    ]
    
    print("🚀 测试本地服务项目提取功能")
    print("="*60)
    
    # 首先测试健康检查
    try:
        health_response = requests.get(f"{base_url}/health")
        if health_response.status_code == 200:
            print("✅ 本地服务健康检查通过")
            print(f"   响应: {health_response.json()}")
        else:
            print("❌ 健康检查失败")
            return
    except Exception as e:
        print(f"❌ 无法连接到本地服务: {e}")
        return
    
    print()
    
    for test_file in test_files:
        if not os.path.exists(test_file):
            print(f"⚠️  文件不存在: {test_file}")
            continue
            
        print(f"📄 测试文件: {test_file}")
        print("-" * 40)
        
        try:
            # 上传文件
            with open(test_file, 'rb') as f:
                files = {'file': f}
                response = requests.post(f"{base_url}/resume/parse", files=files)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get('success'):
                    parsed_data = data.get('parsed_data', {})
                    projects = parsed_data.get('projects', [])
                    
                    print(f"✅ 解析成功")
                    print(f"   📝 姓名: {parsed_data.get('name', 'N/A')}")
                    print(f"   📧 邮箱: {parsed_data.get('email', 'N/A')}")
                    print(f"   🛠️  技能数量: {len(parsed_data.get('skills', []))}")
                    print(f"   💼 工作经历: {len(parsed_data.get('experience', []))}")
                    print(f"   🎓 教育背景: {len(parsed_data.get('education', []))}")
                    print(f"   🚀 项目经验: {len(projects)}")
                    
                    if projects:
                        print(f"\n   📋 项目详情:")
                        for i, project in enumerate(projects, 1):
                            print(f"     {i}. {project.get('name', '未命名项目')}")
                            print(f"        类型: {project.get('type', 'N/A')}")
                            if project.get('technologies'):
                                print(f"        技术: {', '.join(project['technologies'][:5])}")
                            if project.get('duration'):
                                print(f"        时间: {project['duration']}")
                            if project.get('description'):
                                desc = project['description'][:100] + "..." if len(project['description']) > 100 else project['description']
                                print(f"        描述: {desc}")
                            print()
                    else:
                        print(f"   ⚠️  未找到项目经验")
                else:
                    print(f"❌ 解析失败: {data.get('error', '未知错误')}")
                    
            else:
                print(f"❌ HTTP错误: {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   错误信息: {error_data}")
                except:
                    print(f"   错误信息: {response.text}")
                    
        except Exception as e:
            print(f"❌ 请求异常: {e}")
        
        print()

if __name__ == "__main__":
    test_local_project_extraction() 