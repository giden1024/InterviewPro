#!/usr/bin/env python3
"""
测试API中的projects处理流程
"""

import sys
sys.path.append('backend')

from backend.app.services.resume_parser import ResumeParser
from backend.app.models.resume import Resume

def test_api_projects_flow():
    """测试API中的projects处理流程"""
    print("🔍 测试API中的projects处理流程...")
    
    # 创建解析器实例
    parser = ResumeParser()
    
    # 测试文件
    test_file = "docs/testfile/app_cv.pdf"
    
    try:
        # 模拟API中的解析流程
        print("📄 步骤1: 解析简历...")
        result = parser.parse_resume(test_file, "pdf")
        
        if result['success']:
            parsed_data = result['parsed_data']
            print(f"✅ 解析成功，数据键: {list(parsed_data.keys())}")
            
            # 检查projects
            projects = parsed_data.get('projects', [])
            print(f"🎯 parsed_data中的项目数量: {len(projects)}")
            
            # 模拟API中的Resume对象创建和赋值
            print("\n📄 步骤2: 模拟Resume对象赋值...")
            
            # 创建一个临时Resume对象（不保存到数据库）
            resume = Resume()
            
            # 模拟API中的赋值逻辑
            resume.name = parsed_data.get('name')
            resume.email = parsed_data.get('email')
            resume.phone = parsed_data.get('phone')
            resume.skills = parsed_data.get('skills', [])
            resume.experience = parsed_data.get('experience', [])
            resume.education = parsed_data.get('education', [])
            resume.projects = parsed_data.get('projects', [])
            
            print(f"✅ Resume对象赋值完成")
            print(f"   - name: {resume.name}")
            print(f"   - email: {resume.email}")
            print(f"   - projects: {len(resume.projects) if resume.projects else 0} 个项目")
            
            # 测试to_dict方法
            print("\n📄 步骤3: 测试to_dict方法...")
            resume_dict = resume.to_dict()
            print(f"✅ to_dict结果键: {list(resume_dict.keys())}")
            
            if 'projects' in resume_dict:
                projects_in_dict = resume_dict['projects']
                print(f"🎯 to_dict中的项目数量: {len(projects_in_dict) if projects_in_dict else 0}")
                if projects_in_dict:
                    print(f"📝 第一个项目: {projects_in_dict[0]}")
            else:
                print("❌ to_dict中没有projects字段")
                
        else:
            print(f"❌ 解析失败: {result.get('error')}")
            
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_api_projects_flow()
