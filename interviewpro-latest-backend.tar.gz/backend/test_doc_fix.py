#!/usr/bin/env python3
"""
Test .doc file parsing fix
"""
import os
import sys
import json
from app.services.resume_parser import ResumeParser

def test_doc_parsing_fix():
    """测试修复后的.doc文件解析"""
    
    # 查找最近的.doc文件
    uploads_dir = "uploads"
    doc_file = None
    
    if os.path.exists(uploads_dir):
        for root, dirs, files in os.walk(uploads_dir):
            for file in files:
                if file.endswith('.doc'):
                    doc_file = os.path.join(root, file)
                    break
            if doc_file:
                break
    
    if not doc_file:
        print("No .doc file found in uploads directory")
        return
    
    print(f"Testing .doc file: {doc_file}")
    print(f"File size: {os.path.getsize(doc_file)} bytes")
    
    try:
        # 测试解析器
        parser = ResumeParser()
        result = parser.parse_resume(doc_file, 'doc')
        
        if not result.get('success'):
            print(f"\n=== PARSING FAILED ===")
            print(f"Error: {result.get('error', 'Unknown error')}")
            return
        
        parsed_data = result.get('parsed_data', {})
        raw_text = result.get('raw_text', '')
        
        print("\n=== PARSING SUCCESSFUL ===")
        print(f"Success: {result.get('success', False)}")
        print(f"Name: {parsed_data.get('name', 'N/A')}")
        print(f"Email: {parsed_data.get('email', 'N/A')}")  
        print(f"Phone: {parsed_data.get('phone', 'N/A')}")
        print(f"Raw text length: {len(raw_text)}")
        print(f"Work experiences count: {len(parsed_data.get('experience', []))}")
        print(f"Skills count: {len(parsed_data.get('skills', []))}")
        print(f"Education count: {len(parsed_data.get('education', []))}")
        
        if parsed_data.get('experience'):
            print("\n=== WORK EXPERIENCE ===")
            for i, exp in enumerate(parsed_data['experience'][:2]):  # 显示前2个
                print(f"  {i+1}. {exp.get('position', 'N/A')} at {exp.get('company', 'N/A')}")
                print(f"     Duration: {exp.get('duration', 'N/A')}")
        
        if parsed_data.get('skills'):
            print(f"\n=== SKILLS ===")
            print(f"  {', '.join(parsed_data['skills'][:5])}")  # 显示前5个技能
            
        print(f"\n=== FIRST 300 CHARS OF RAW TEXT ===")
        print(raw_text[:300])
        
    except Exception as e:
        print(f"\n=== PARSING FAILED ===")
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_doc_parsing_fix() 