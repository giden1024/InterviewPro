#!/usr/bin/env python3
"""
AI问题生成功能测试脚本
测试基于简历信息生成个性化面试问题
"""

import sys
import os
import json
import requests
from datetime import datetime
import logging

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 测试配置
BASE_URL = "http://localhost:5000/api/v1"
TEST_EMAIL = "test_interview@example.com"
TEST_PASSWORD = "TestPassword123!"

def print_status(status, message):
    """打印状态信息"""
    status_icon = "✅" if status == "SUCCESS" else "❌" if status == "ERROR" else "ℹ️"
    print(f"{status_icon} {message}")

def test_user_registration():
    """测试用户注册"""
    try:
        url = f"{BASE_URL}/auth/register"
        data = {
            "email": TEST_EMAIL,
            "password": TEST_PASSWORD,
            "username": "AI面试测试用户"
        }
        
        response = requests.post(url, json=data)
        
        if response.status_code == 201:
            print_status("SUCCESS", "用户注册成功")
            return response.json()
        elif response.status_code == 409:
            print_status("INFO", "用户已存在，直接登录")
            return {"success": True, "message": "用户已存在"}
        else:
            print_status("ERROR", f"用户注册失败: {response.text}")
            return None
            
    except Exception as e:
        print_status("ERROR", f"用户注册异常: {e}")
        return None

def test_user_login():
    """测试用户登录"""
    try:
        url = f"{BASE_URL}/auth/login"
        data = {
            "email": TEST_EMAIL,
            "password": TEST_PASSWORD
        }
        
        response = requests.post(url, json=data)
        
        if response.status_code == 200:
            result = response.json()
            print_status("SUCCESS", "用户登录成功")
            return result['data']['access_token']
        else:
            print_status("ERROR", f"用户登录失败: {response.text}")
            return None
            
    except Exception as e:
        print_status("ERROR", f"用户登录异常: {e}")
        return None

def test_resume_upload(token):
    """测试简历上传"""
    try:
        url = f"{BASE_URL}/resumes/upload"
        headers = {"Authorization": f"Bearer {token}"}
        
        # 使用测试简历文件
        test_file = "backend/testfiles/app_cv.pdf"
        if not os.path.exists(test_file):
            print_status("ERROR", f"测试文件不存在: {test_file}")
            return None
        
        with open(test_file, 'rb') as f:
            files = {"file": (os.path.basename(test_file), f, "application/pdf")}
            response = requests.post(url, headers=headers, files=files)
        
        if response.status_code == 201:
            result = response.json()
            print_status("SUCCESS", f"简历上传成功，ID: {result['data']['resume']['id']}")
            return result['data']['resume']['id']
        else:
            print_status("ERROR", f"简历上传失败: {response.text}")
            return None
            
    except Exception as e:
        print_status("ERROR", f"简历上传异常: {e}")
        return None

def test_wait_for_processing(token, resume_id, max_wait=30):
    """等待简历处理完成"""
    try:
        url = f"{BASE_URL}/resumes/{resume_id}"
        headers = {"Authorization": f"Bearer {token}"}
        
        for i in range(max_wait):
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                status = result['data']['status']
                
                if status == 'processed':
                    print_status("SUCCESS", "简历处理完成")
                    return True
                elif status == 'failed':
                    print_status("ERROR", "简历处理失败")
                    return False
                else:
                    print(f"⏳ 简历处理中... ({i+1}/{max_wait})")
                    
            import time
            time.sleep(1)
        
        print_status("ERROR", "简历处理超时")
        return False
        
    except Exception as e:
        print_status("ERROR", f"等待简历处理异常: {e}")
        return False

def test_get_interview_types():
    """测试获取面试类型"""
    try:
        url = f"{BASE_URL}/interviews/types"
        response = requests.get(url)
        
        if response.status_code == 200:
            result = response.json()
            print_status("SUCCESS", "获取面试类型成功")
            
            print("\n📋 可用的面试类型:")
            for interview_type in result['data']['types']:
                print(f"  • {interview_type['label']}: {interview_type['description']}")
            
            return result['data']
        else:
            print_status("ERROR", f"获取面试类型失败: {response.text}")
            return None
            
    except Exception as e:
        print_status("ERROR", f"获取面试类型异常: {e}")
        return None

def test_create_interview_session(token, resume_id, interview_type="comprehensive"):
    """测试创建面试会话"""
    try:
        url = f"{BASE_URL}/interviews"
        headers = {"Authorization": f"Bearer {token}"}
        data = {
            "resume_id": resume_id,
            "interview_type": interview_type,
            "total_questions": 8,
            "custom_title": f"AI自动生成面试 - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        }
        
        print(f"🚀 开始创建{interview_type}面试会话...")
        response = requests.post(url, headers=headers, json=data)
        
        if response.status_code == 201:
            result = response.json()
            session_id = result['data']['session_id']
            print_status("SUCCESS", f"面试会话创建成功，ID: {session_id}")
            return session_id
        else:
            print_status("ERROR", f"创建面试会话失败: {response.text}")
            return None
            
    except Exception as e:
        print_status("ERROR", f"创建面试会话异常: {e}")
        return None

def test_get_interview_session(token, session_id):
    """测试获取面试会话详情"""
    try:
        url = f"{BASE_URL}/interviews/{session_id}"
        headers = {"Authorization": f"Bearer {token}"}
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            result = response.json()
            session = result['data']['session']
            questions = result['data']['questions']
            
            print_status("SUCCESS", f"获取面试详情成功")
            print(f"\n📊 面试会话信息:")
            print(f"  • 标题: {session['title']}")
            print(f"  • 类型: {session['interview_type']}")
            print(f"  • 状态: {session['status']}")
            print(f"  • 问题总数: {len(questions)}")
            
            print(f"\n📝 生成的问题列表:")
            for i, question in enumerate(questions, 1):
                print(f"  {i}. [{question['question_type']}/{question['difficulty']}] {question['question_text'][:100]}...")
                if question.get('category'):
                    print(f"     分类: {question['category']}")
                if question.get('tags'):
                    print(f"     标签: {', '.join(question['tags'])}")
                print()
            
            return result['data']
        else:
            print_status("ERROR", f"获取面试详情失败: {response.text}")
            return None
            
    except Exception as e:
        print_status("ERROR", f"获取面试详情异常: {e}")
        return None

def test_start_interview_session(token, session_id):
    """测试开始面试会话"""
    try:
        url = f"{BASE_URL}/interviews/{session_id}/start"
        headers = {"Authorization": f"Bearer {token}"}
        
        response = requests.post(url, headers=headers)
        
        if response.status_code == 200:
            result = response.json()
            print_status("SUCCESS", "面试会话开始成功")
            
            if result['data'].get('next_question'):
                next_q = result['data']['next_question']
                print(f"\n🎯 第一个问题:")
                print(f"  问题: {next_q['question']['question_text']}")
                print(f"  类型: {next_q['question']['question_type']}")
                print(f"  难度: {next_q['question']['difficulty']}")
                print(f"  进度: {next_q['current_index']+1}/{next_q['total_questions']}")
            
            return result['data']
        else:
            print_status("ERROR", f"开始面试失败: {response.text}")
            return None
            
    except Exception as e:
        print_status("ERROR", f"开始面试异常: {e}")
        return None

def test_simulate_interview(token, session_id, num_answers=3):
    """模拟面试过程"""
    try:
        print(f"\n🎭 模拟回答前{num_answers}个问题...")
        
        for i in range(num_answers):
            # 获取下一个问题
            url = f"{BASE_URL}/interviews/{session_id}/next"
            headers = {"Authorization": f"Bearer {token}"}
            
            response = requests.get(url, headers=headers)
            if response.status_code != 200:
                print_status("ERROR", f"获取问题失败: {response.text}")
                break
            
            result = response.json()
            if result['data'].get('completed'):
                print_status("INFO", "所有问题已完成")
                break
            
            question = result['data']['question']
            print(f"\n📝 问题 {i+1}: {question['question_text']}")
            
            # 模拟回答
            sample_answers = [
                "这是一个很好的问题。基于我的经验，我认为...",
                "在我之前的项目中，我遇到过类似的情况。我的做法是...",
                "我觉得这个问题的关键在于...根据我的理解..."
            ]
            
            answer_data = {
                "question_id": question['id'],
                "answer_text": sample_answers[i % len(sample_answers)],
                "response_time": 60 + i * 30  # 模拟不同的回答时间
            }
            
            # 提交答案
            submit_url = f"{BASE_URL}/interviews/{session_id}/answer"
            submit_response = requests.post(submit_url, headers=headers, json=answer_data)
            
            if submit_response.status_code == 200:
                submit_result = submit_response.json()
                print(f"✅ 答案提交成功")
                
                if submit_result['data'].get('session_completed'):
                    print_status("SUCCESS", "面试已完成！")
                    break
            else:
                print_status("ERROR", f"提交答案失败: {submit_response.text}")
                break
        
        return True
        
    except Exception as e:
        print_status("ERROR", f"模拟面试异常: {e}")
        return False

def test_get_statistics(token):
    """测试获取统计信息"""
    try:
        url = f"{BASE_URL}/interviews/statistics"
        headers = {"Authorization": f"Bearer {token}"}
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            result = response.json()
            stats = result['data']
            
            print_status("SUCCESS", "获取统计信息成功")
            print(f"\n📈 面试统计:")
            print(f"  • 总面试次数: {stats['total_sessions']}")
            print(f"  • 已完成面试: {stats['completed_sessions']}")
            print(f"  • 进行中面试: {stats['in_progress_sessions']}")
            print(f"  • 完成率: {stats['completion_rate']:.1f}%")
            
            return stats
        else:
            print_status("ERROR", f"获取统计信息失败: {response.text}")
            return None
            
    except Exception as e:
        print_status("ERROR", f"获取统计信息异常: {e}")
        return None

def main():
    """主测试流程"""
    print("🤖 InterviewGenius AI - 问题生成功能测试")
    print("=" * 60)
    
    # 1. 用户注册和登录
    print("\n1️⃣ 用户认证测试")
    test_user_registration()
    token = test_user_login()
    if not token:
        print_status("ERROR", "无法获取访问令牌，终止测试")
        return
    
    # 2. 简历上传
    print("\n2️⃣ 简历上传测试")
    resume_id = test_resume_upload(token)
    if not resume_id:
        print_status("ERROR", "简历上传失败，终止测试")
        return
    
    # 3. 等待简历处理
    print("\n3️⃣ 简历处理等待")
    if not test_wait_for_processing(token, resume_id):
        print_status("ERROR", "简历处理失败，终止测试")
        return
    
    # 4. 获取面试类型
    print("\n4️⃣ 面试类型查询")
    types_data = test_get_interview_types()
    if not types_data:
        print_status("ERROR", "无法获取面试类型")
        return
    
    # 5. 创建不同类型的面试会话
    print("\n5️⃣ AI问题生成测试")
    interview_types = ['technical', 'hr', 'comprehensive']
    
    for interview_type in interview_types:
        print(f"\n🔄 测试{interview_type}面试类型...")
        
        # 创建面试会话
        session_id = test_create_interview_session(token, resume_id, interview_type)
        if not session_id:
            continue
        
        # 获取面试详情
        session_data = test_get_interview_session(token, session_id)
        if not session_data:
            continue
        
        # 开始面试
        start_data = test_start_interview_session(token, session_id)
        if not start_data:
            continue
        
        # 模拟面试过程
        test_simulate_interview(token, session_id, 2)
    
    # 6. 获取统计信息
    print("\n6️⃣ 统计信息测试")
    test_get_statistics(token)
    
    print("\n" + "=" * 60)
    print("🎉 AI问题生成功能测试完成！")
    print("\n💡 测试要点:")
    print("  • 基于简历技能生成个性化问题")
    print("  • 支持多种面试类型和难度")
    print("  • 完整的面试流程管理")
    print("  • 实时进度跟踪和统计")

if __name__ == "__main__":
    main() 