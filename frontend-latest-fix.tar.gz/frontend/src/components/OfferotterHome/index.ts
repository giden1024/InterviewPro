export { OfferotterHome } from './OfferotterHome';
export type { 
  OfferotterHomeProps, 
  CoreFeature, 
  Statistic, 
  Testimonial, 
  FAQItem 
} from './types'; 